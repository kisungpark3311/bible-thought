import sys
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import os
import re
import json
import html
import shutil
import hashlib
import argparse
import subprocess
from pathlib import Path

# ==============================================================================
# 본문 내용 연동형 컷 일러스트 라이브러리 (674x160 A4 에디토리얼 와이드 배너)
# 각 페이지(지면)의 문단 핵심 어휘·메타포·성경 본문과 자동 매칭됩니다.
# ==============================================================================
SCENE_LIBRARY = [
    {
        "id": "amos5_two_imperatives_vav",
        "label": "‘그리하면’이라는 거래의 칸을 지우고 접속사 וְ(그리고) 한 글자로 나란히 선 두 줄의 명령(암 5:4·6)",
        "default_sub": "아모스 5:4·6 · 조건 표지 0개, 똑같은 칼 명령형 2인칭 남성 복수로 나란히 선 ‘찾으라(다라시)’와 ‘살라(하야)’",
        "keywords": {
            "디르슈니": 15, "비흐유": 15, "그리하면": 12, "칼 명령형": 13,
            "다라시": 12, "하야": 11, "사업자 등록": 11, "거래의 장부": 12
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="그리하면의 조건 거래식을 지우고 접속사 브 한 글자로 나란히 선 디르슈니 비흐유 두 명령">
        <defs>
          <linearGradient id="gAmos5Bg1" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#1c252c"/>
            <stop offset="0.55" stop-color="#2b3842"/>
            <stop offset="1" stop-color="#192126"/>
          </linearGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gAmos5Bg1)"/>
        <!-- 좌측: 흐릿하게 취소선이 그어진 인간의 조건 거래 장부 -->
        <g transform="translate(22, 22)">
          <rect width="192" height="116" rx="6" fill="#26313a" stroke="#475569" stroke-width="1"/>
          <text x="96" y="22" font-family="serif" font-size="10.5" fill="#94a3b8" text-anchor="middle">인간의 거래 장부 (조건문 오독)</text>
          <rect x="18" y="34" width="156" height="22" rx="3" fill="#1e293b"/>
          <text x="96" y="49" font-family="serif" font-size="10" fill="#cbd5e1" text-anchor="middle">1. 찾으라 (내가 치를 값)</text>
          <text x="96" y="72" font-family="serif" font-size="11" fill="#f87171" text-anchor="middle" font-weight="bold">➔ [그리하면 : 조건 표지 0] ➔</text>
          <rect x="18" y="82" width="156" height="22" rx="3" fill="#1e293b"/>
          <text x="96" y="97" font-family="serif" font-size="10" fill="#cbd5e1" text-anchor="middle">2. 살리라 (미래의 보상)</text>
          <line x1="14" y1="68" x2="178" y2="68" stroke="#ef4444" stroke-width="2"/>
        </g>
        <!-- 중앙: 두 명령을 동등하게 이어 주는 히브리어 접속사 וְ(브, 그리고) -->
        <g transform="translate(234, 20)">
          <circle cx="52" cy="60" r="34" fill="#3b2f1e" stroke="#f59e0b" stroke-width="2"/>
          <text x="52" y="64" font-family="serif" font-size="24" fill="#fde68a" text-anchor="middle" font-weight="bold">וְ</text>
          <text x="52" y="82" font-family="serif" font-size="10" fill="#fcd34d" text-anchor="middle">‘그리고’ (1글자)</text>
          <text x="52" y="112" font-family="serif" font-size="9.5" fill="#e2e8f0" text-anchor="middle">79단어 · 105형태소</text>
          <text x="52" y="126" font-family="serif" font-size="9.5" fill="#fbbf24" text-anchor="middle">조건 접속사 = 0개</text>
        </g>
        <!-- 우측: 똑같은 높이와 굵기로 나란히 선 두 개의 칼 명령형 카드 -->
        <g transform="translate(356, 20)">
          <rect x="0" y="0" width="142" height="120" rx="6" fill="#f8fafc" stroke="#f59e0b" stroke-width="2"/>
          <rect x="0" y="0" width="142" height="24" rx="6" fill="#b45309"/>
          <text x="71" y="16" font-family="serif" font-size="10" fill="#fffbeb" text-anchor="middle" font-weight="bold">첫째 분부 (칼 명령 2mp)</text>
          <text x="71" y="54" font-family="serif" font-size="17" fill="#1e293b" text-anchor="middle" font-weight="bold">דִּרְשׁוּנִי</text>
          <text x="71" y="76" font-family="serif" font-size="12" fill="#7c2d12" text-anchor="middle" font-weight="bold">“나를 찾으라”</text>
          <text x="71" y="98" font-family="serif" font-size="9.5" fill="#475569" text-anchor="middle">목적어: 주님 자신(5:4·6)</text>

          <rect x="156" y="0" width="142" height="120" rx="6" fill="#f8fafc" stroke="#f59e0b" stroke-width="2"/>
          <rect x="156" y="0" width="142" height="24" rx="6" fill="#b45309"/>
          <text x="227" y="16" font-family="serif" font-size="10" fill="#fffbeb" text-anchor="middle" font-weight="bold">둘째 분부 (칼 명령 2mp)</text>
          <text x="227" y="54" font-family="serif" font-size="17" fill="#1e293b" text-anchor="middle" font-weight="bold">וִחְיוּ</text>
          <text x="227" y="76" font-family="serif" font-size="12" fill="#7c2d12" text-anchor="middle" font-weight="bold">“그리고 살라!”</text>
          <text x="227" y="98" font-family="serif" font-size="9.5" fill="#475569" text-anchor="middle">보상이 아닌 오늘의 분부</text>
        </g>
        </svg>""",
    },
    {
        "id": "amos5_turn_from_bethel_breathe",
        "label": "세 성소(벧엘·길갈·브엘세바)로 기울던 발을 멈추어 정면의 여호와께 고개를 들고 내쉬는 생명의 호흡",
        "default_sub": "아모스 5:5-6 · 장소와 업적(베트엘)에서 몸을 돌려 살아 계신 주님 자신(에트-여호와) 앞에서 쉬는 들숨과 날숨",
        "keywords": {
            "벧엘": 14, "길갈": 13, "브엘세바": 13, "베알-티드레슈": 15,
            "목적어": 13, "발바닥": 10, "날숨": 12, "이중 은혜": 12, "애가": 10
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="벧엘 길갈 브엘세바로 기울던 발을 멈추고 정면의 여호와를 향해 고개를 들어 숨을 내쉬는 신체 묵상">
        <defs>
          <linearGradient id="gAmos5Bg2" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#172a24"/>
            <stop offset="0.5" stop-color="#213c34"/>
            <stop offset="1" stop-color="#12211c"/>
          </linearGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gAmos5Bg2)"/>
        <!-- 좌·우·하단: 금지된 세 성소 방향과 발을 떼기 직전의 정지선 -->
        <g transform="translate(30, 18)">
          <!-- 왼쪽: 길갈 -->
          <rect x="0" y="44" width="108" height="40" rx="5" fill="#1e293b" stroke="#64748b" stroke-dasharray="3,3"/>
          <text x="54" y="62" font-family="serif" font-size="11" fill="#94a3b8" text-anchor="middle">← 길갈 (5:5)</text>
          <text x="54" y="77" font-family="serif" font-size="9.5" fill="#f87171" text-anchor="middle">들어가지 말라 (לֹא)</text>
          <!-- 오른쪽: 벧엘 -->
          <rect x="276" y="44" width="118" height="40" rx="5" fill="#1e293b" stroke="#ef4444" stroke-dasharray="3,3"/>
          <text x="335" y="62" font-family="serif" font-size="11" fill="#fca5a5" text-anchor="middle">벧엘 (בֵּית־אֵל) →</text>
          <text x="335" y="77" font-family="serif" font-size="9.5" fill="#f87171" text-anchor="middle">찾지 말라 (אַל 지시형)</text>
          <!-- 아래쪽: 브엘세바 -->
          <rect x="132" y="96" width="124" height="32" rx="5" fill="#1e293b" stroke="#64748b" stroke-dasharray="3,3"/>
          <text x="194" y="116" font-family="serif" font-size="10" fill="#94a3b8" text-anchor="middle">↓ 브엘세바 (나아가지 말라)</text>
          <!-- 중앙 정면: 여호와 자신을 향한 회전과 고개 듦 -->
          <circle cx="194" cy="64" r="24" fill="#2d4f43" stroke="#fbbf24" stroke-width="2"/>
          <path d="M194 40 L194 12" stroke="#fbbf24" stroke-width="3"/>
          <polygon points="194,4 187,15 201,15" fill="#fbbf24"/>
          <rect x="118" y="-10" width="152" height="22" rx="4" fill="#b45309"/>
          <text x="194" y="5" font-family="serif" font-size="10.5" fill="#fffbeb" text-anchor="middle" font-weight="bold">정면 목적어: אֶת־יְהוָה (주님 자신)</text>
          <text x="194" y="68" font-family="serif" font-size="10" fill="#fef3c7" text-anchor="middle" font-weight="bold">몸의 회전</text>
        </g>
        <!-- 우측 패널: 고개를 들고 쉬는 들숨과 날숨, 칼뱅의 이중 은혜 -->
        <g transform="translate(448, 22)">
          <rect width="202" height="116" rx="6" fill="#1d352e" stroke="#d97706" stroke-width="1.4"/>
          <text x="101" y="24" font-family="serif" font-size="11.5" fill="#fde68a" text-anchor="middle" font-weight="bold">“여호와를 찾으라, 그리고 살라”</text>
          <path d="M24 54 Q62 34 101 54 T178 54" fill="none" stroke="#6ee7b7" stroke-width="2.2"/>
          <path d="M24 68 Q62 48 101 68 T178 68" fill="none" stroke="#fbbf24" stroke-width="1.6" opacity="0.85"/>
          <text x="101" y="90" font-family="serif" font-size="10" fill="#e2e8f0" text-anchor="middle">숨은 고개를 든 보상이 아니라</text>
          <text x="101" y="105" font-family="serif" font-size="10" fill="#fcd34d" text-anchor="middle" font-weight="bold">분부를 받아 내쉬는 생명의 동작</text>
        </g>
        </svg>""",
    },
    {
        "id": "amos5_counseling_and_diary_two_lines",
        "label": "세무 상담실·목회 공지·아침 다이어리에서 ‘그러면’을 지우고 ‘그리고’로 나란히 적는 두 줄의 분부",
        "default_sub": "아모스 5:3-6 실무 적용 · 장부를 정리하십시오, 그리고 내일 아침 가게 문을 여십시오",
        "keywords": {
            "세무 상담실": 15, "폐업 위기": 14, "가게 문을 여십시오": 15, "장부를 정직하게": 14,
            "새벽기도회": 12, "공지 문안": 13, "다이어리 맨 윗줄": 14, "보상 계획표": 12
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="세무 상담실과 교회 공지 문안과 아침 다이어리에 나란히 적힌 그리고의 두 줄 분부">
        <defs>
          <linearGradient id="gAmos5Bg3" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#231f20"/>
            <stop offset="0.5" stop-color="#362f2d"/>
            <stop offset="1" stop-color="#1f1b1a"/>
          </linearGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gAmos5Bg3)"/>
        <!-- 카드 1: 세무 상담실의 두 줄 -->
        <g transform="translate(18, 20)">
          <rect width="204" height="120" rx="6" fill="#faf8f5" stroke="#d97706" stroke-width="1.5"/>
          <rect width="204" height="25" rx="6" fill="#78350f"/>
          <text x="102" y="17" font-family="serif" font-size="10.5" fill="#fef3c7" text-anchor="middle" font-weight="bold">1. 세무 상담실의 두 줄 (암 5:3-4)</text>
          <text x="14" y="48" font-family="serif" font-size="10.5" fill="#1e293b" font-weight="bold">① 오늘 장부를 정직히 정리하십시오.</text>
          <text x="14" y="70" font-family="serif" font-size="11" fill="#b45309" font-weight="bold">② 그리고 내일 가게 문을 여십시오.</text>
          <line x1="14" y1="84" x2="190" y2="84" stroke="#cbd5e1" stroke-width="1"/>
          <text x="102" y="104" font-family="serif" font-size="9.5" fill="#475569" text-anchor="middle">섣부른 조건문 대신 오늘의 분부</text>
        </g>
        <!-- 카드 2: 교회 공지 문안의 두 줄 -->
        <g transform="translate(235, 20)">
          <rect width="204" height="120" rx="6" fill="#faf8f5" stroke="#0f766e" stroke-width="1.5"/>
          <rect width="204" height="25" rx="6" fill="#115e59"/>
          <text x="102" y="17" font-family="serif" font-size="10.5" fill="#ccfbf1" text-anchor="middle" font-weight="bold">2. 목회 공지 문안의 두 줄 (암 5:5-6)</text>
          <text x="14" y="48" font-family="serif" font-size="10.5" fill="#1e293b" font-weight="bold">① 장소가 아닌 주님을 찾읍시다.</text>
          <text x="14" y="70" font-family="serif" font-size="11" fill="#0f766e" font-weight="bold">② 그리고 한 주간을 살아냅시다.</text>
          <line x1="14" y1="84" x2="190" y2="84" stroke="#cbd5e1" stroke-width="1"/>
          <text x="102" y="104" font-family="serif" font-size="9.5" fill="#475569" text-anchor="middle">도덕주의 우월감과 정죄감 해소</text>
        </g>
        <!-- 카드 3: 아침 다이어리 맨 윗줄 -->
        <g transform="translate(452, 20)">
          <rect width="204" height="120" rx="6" fill="#fffbeb" stroke="#b45309" stroke-width="1.8"/>
          <rect width="204" height="25" rx="6" fill="#92400e"/>
          <text x="102" y="17" font-family="serif" font-size="10.5" fill="#fef3c7" text-anchor="middle" font-weight="bold">3. 아침 다이어리 첫 줄 (오늘의 숨)</text>
          <text x="14" y="48" font-family="serif" font-size="10.5" fill="#1e293b" font-weight="bold">1. 오늘도 주님 자신을 찾는다.</text>
          <text x="14" y="70" font-family="serif" font-size="11" fill="#b45309" font-weight="bold">2. 그리고 오늘 하루를 살아낸다.</text>
          <line x1="14" y1="84" x2="190" y2="84" stroke="#fcd34d" stroke-width="1"/>
          <text x="102" y="104" font-family="serif" font-size="9.5" fill="#78350f" text-anchor="middle" font-weight="bold">보수가 아닌 거룩한 분부로 출발</text>
        </g>
        </svg>""",
    },
    {
        "id": "cheongpungho_pine_needles_morning",
        "label": "청풍호 아침 산책로에 수북이 내려앉은 갈색 솔잎들과 밑동이 하나로 묶인 솔잎 두 바늘",
        "default_sub": "제천 청풍호 아침 산책길 · 어쩌다 한 번이 아니라 계절 내내 쉼 없이 건네진 부르심의 흔적",
        "keywords": {
            "솔잎": 14, "두 바늘": 15, "갈색 솔잎": 14, "양탄자": 10,
            "건우": 10, "서른한 번째 생일": 12, "물안개": 8, "산책로": 8
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="청풍호 아침 물안개와 산책로 데크 위에 수북이 내려앉은 갈색 솔잎 두 바늘">
        <defs>
          <linearGradient id="gPineSky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#223843"/>
            <stop offset="0.55" stop-color="#4a6b7c"/>
            <stop offset="1" stop-color="#cbd5e1"/>
          </linearGradient>
          <linearGradient id="gPineDeck" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#4a3525"/>
            <stop offset="0.6" stop-color="#6b4c35"/>
            <stop offset="1" stop-color="#3d2b1f"/>
          </linearGradient>
        </defs>
        <rect width="674" height="92" fill="url(#gPineSky)"/>
        <!-- 아침 물안개 낀 청풍호 먼 산능선 -->
        <path d="M0 92 L0 62 Q110 38 220 64 Q330 35 450 60 Q560 40 674 56 L674 92 Z" fill="#334e58" opacity="0.72"/>
        <rect x="0" y="76" width="674" height="20" fill="#e2e8f0" opacity="0.38"/>
        <!-- 호숫가 나무 데크와 흙길 산책로 -->
        <polygon points="0,92 674,92 674,160 0,160" fill="url(#gPineDeck)"/>
        <line x1="0" y1="108" x2="674" y2="108" stroke="#2b1d12" stroke-width="1.2" opacity="0.65"/>
        <line x1="0" y1="128" x2="674" y2="128" stroke="#2b1d12" stroke-width="1.2" opacity="0.65"/>
        <line x1="0" y1="148" x2="674" y2="148" stroke="#2b1d12" stroke-width="1.2" opacity="0.65"/>
        <!-- 발밑에 수북이 쌓인 갈색 솔잎 양탄자 질감 -->
        <g stroke="#b47b44" stroke-width="1.4" stroke-linecap="round" opacity="0.78">
          <line x1="42" y1="115" x2="68" y2="122"/><line x1="42" y1="115" x2="70" y2="117"/>
          <line x1="95" y1="134" x2="125" y2="129"/><line x1="95" y1="134" x2="123" y2="136"/>
          <line x1="158" y1="118" x2="188" y2="125"/><line x1="158" y1="118" x2="190" y2="119"/>
          <line x1="215" y1="142" x2="246" y2="136"/><line x1="215" y1="142" x2="248" y2="143"/>
          <line x1="280" y1="122" x2="312" y2="128"/><line x1="280" y1="122" x2="310" y2="121"/>
          <line x1="520" y1="132" x2="554" y2="126"/><line x1="520" y1="132" x2="552" y2="134"/>
          <line x1="575" y1="116" x2="608" y2="122"/><line x1="575" y1="116" x2="610" y2="115"/>
        </g>
        <!-- 우측 전면 클로즈업: 밑동(뿌리)이 하나로 묶인 갈색 솔잎 두 바늘 -->
        <g transform="translate(345, 52)">
          <ellipse cx="78" cy="64" rx="88" ry="32" fill="#1f140e" opacity="0.32"/>
          <!-- 솔잎 밑동 집(근원) -->
          <rect x="18" y="58" width="14" height="7" rx="2.5" transform="rotate(-14 18 58)" fill="#5c3a21" stroke="#d9a05b" stroke-width="1"/>
          <!-- 한 뿌리에서 뻗어 나온 두 바늘 -->
          <path d="M30 57 Q95 36 168 24" fill="none" stroke="#eab368" stroke-width="3" stroke-linecap="round"/>
          <path d="M30 60 Q98 54 174 52" fill="none" stroke="#d99343" stroke-width="3" stroke-linecap="round"/>
          <circle cx="18" cy="60" r="3" fill="#f3c88b"/>
        </g>
      </svg>"""
    },
    {
        "id": "amos4_blank_reply_seven_seals",
        "label": "다섯 번 비어 있던 회신란 끝에 일곱 번 찍힌 발신인의 친필 서명(‘네움 여호와’)과 불에서 건져낸 나무 조각",
        "default_sub": "아모스 4:6-12 · 미회신 소명 안내문 철과 아버지의 파토스(Heschel, 1962)",
        "keywords": {
            "벨로-샤브템 아다이": 16, "네움 여호와": 16, "회신란": 15, "소명 안내": 15,
            "편지철": 15, "턱 근육": 15, "무차르": 15, "나무 조각": 14, "엘로헤이카": 14
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="다섯 번 비어 있는 답장란 뒤에 일곱 번 찍힌 붉은 인장 네움 여호와와 불에서 건져낸 나무 조각">
        <defs>
          <linearGradient id="gAmos4Bg" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#1b1917"/>
            <stop offset="0.55" stop-color="#2e2621"/>
            <stop offset="1" stop-color="#433024"/>
          </linearGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gAmos4Bg)"/>
        <!-- 좌측~중앙: 겹쳐진 다섯 통의 편지철과 하얗게 비어 있는 회신란 -->
        <g transform="translate(56, 18)">
          <rect x="0" y="10" width="230" height="114" rx="4" fill="#e5dccb" opacity="0.45"/>
          <rect x="10" y="5" width="230" height="114" rx="4" fill="#efe6d5" opacity="0.72"/>
          <rect x="20" y="0" width="236" height="118" rx="4" fill="#fbf7ef" stroke="#8c7355" stroke-width="1.5"/>
          <!-- 발신 문장 흔적 -->
          <line x1="38" y1="22" x2="188" y2="22" stroke="#6e5a44" stroke-width="2"/>
          <line x1="38" y1="34" x2="218" y2="34" stroke="#9c8870" stroke-width="1.4"/>
          <line x1="38" y1="46" x2="198" y2="46" stroke="#9c8870" stroke-width="1.4"/>
          <!-- 하얗게 비어 있는 수신인 답장란(회신란) 박스 5칸 -->
          <rect x="38" y="62" width="154" height="36" rx="3" fill="#ffffff" stroke="#b45309" stroke-width="1.3" stroke-dasharray="4 3"/>
          <!-- 회신란 바로 옆과 아래에 일곱 번 찍힌 발신인의 붉은 친필 인장(네움 여호와) -->
          <g fill="#b91c1c" opacity="0.88">
            <circle cx="214" cy="30" r="7"/><circle cx="232" cy="30" r="7"/>
            <circle cx="214" cy="50" r="7"/><circle cx="232" cy="50" r="7"/>
            <circle cx="214" cy="70" r="7"/><circle cx="232" cy="70" r="7"/>
            <circle cx="223" cy="94" r="9.5" fill="#991b1b" stroke="#fde68a" stroke-width="1.2"/>
          </g>
        </g>
        <!-- 우측: 불붙는 가운데서 누군가의 손에 의해 건져 올려진 나무 조각(무차르) -->
        <g transform="translate(390, 22)">
          <!-- 아래쪽 사그라드는 불꽃 -->
          <path d="M40 126 Q58 92 74 114 Q92 82 110 112 Q128 90 144 126 Z" fill="#ea580c" opacity="0.55"/>
          <path d="M56 126 Q76 100 94 116 Q112 96 128 126 Z" fill="#facc15" opacity="0.65"/>
          <!-- 타다 남은 그을린 나무 조각 -->
          <path d="M48 76 L142 54 L148 68 L54 90 Z" fill="#3b281e" stroke="#f59e0b" stroke-width="1.2"/>
          <circle cx="144" cy="61" r="4" fill="#fb923c"/>
          <!-- 위에서 뻗어 내려와 나무 조각을 감싸 쥐는 구원의 손길과 대면의 빛 -->
          <path d="M88 0 L88 46 Q88 58 76 62 M88 46 Q98 58 108 56" fill="none" stroke="#fde68a" stroke-width="3.2" stroke-linecap="round"/>
          <circle cx="88" cy="52" r="28" fill="#fde68a" opacity="0.16"/>
        </g>
      </svg>"""
    },
    {
        "id": "geonwoo_31_tent_of_meeting_reply",
        "label": "출애굽기 33장 11절 회막의 등불 아래 솔잎 두 바늘이 끼워진 성경책과 만년필로 적는 아버지의 답장",
        "default_sub": "출애굽기 33:11 · ‘하나님의 친구’ 건우의 서른한 번째 생일 축복과 아버지의 늦은 답장 한 줄",
        "keywords": {
            "출애굽기 33장 11절": 18, "하나님의 친구": 16, "건우(建友)": 18, "회막": 15,
            "여호수아": 15, "성경책 갈피": 16, "만년필": 15, "묵상 노트의 빈 여백": 16, "눈맞춤": 14
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="회막의 따뜻한 등불 아래 솔잎 두 바늘이 끼워진 성경책과 만년필로 답장을 적는 묵상 노트">
        <defs>
          <linearGradient id="gTentBg" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#172536"/>
            <stop offset="0.52" stop-color="#2b3d4f"/>
            <stop offset="1" stop-color="#5c4328"/>
          </linearGradient>
          <radialGradient id="gTentWarmth" cx="0.32" cy="0.42" r="0.48">
            <stop offset="0" stop-color="#fde68a" stop-opacity="0.52"/>
            <stop offset="0.55" stop-color="#f59e0b" stop-opacity="0.18"/>
            <stop offset="1" stop-color="#172536" stop-opacity="0"/>
          </radialGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gTentBg)"/>
        <rect width="674" height="160" fill="url(#gTentWarmth)"/>
        <!-- 좌측: 친구와 대면하여 말씀하시던 회막(출 33:11)의 드리운 휘장과 따뜻한 등불 -->
        <g transform="translate(68, 16)">
          <path d="M78 6 L16 124 L140 124 Z" fill="#33261d" stroke="#d9a05b" stroke-width="1.6"/>
          <path d="M78 34 L48 124 L108 124 Z" fill="#f59e0b" opacity="0.35"/>
          <circle cx="78" cy="76" r="10" fill="#fef08a"/>
        </g>
        <!-- 중앙~우측: 펼쳐진 성경책(솔잎 두 바늘 책갈피)과 만년필로 적는 아버지의 묵상 노트 답장란 -->
        <g transform="translate(262, 34)">
          <!-- 펼쳐진 성경책 -->
          <polygon points="0,84 150,76 164,108 10,116" fill="#f8f1e5" stroke="#785c3a" stroke-width="1.4"/>
          <line x1="78" y1="80" x2="86" y2="112" stroke="#a68a64" stroke-width="1.5"/>
          <!-- 성경책 갈피에 나란히 끼워진 갈색 솔잎 두 바늘 -->
          <path d="M72 86 Q105 56 148 44" fill="none" stroke="#d97706" stroke-width="2.4" stroke-linecap="round"/>
          <path d="M72 88 Q108 66 154 60" fill="none" stroke="#b45309" stroke-width="2.4" stroke-linecap="round"/>
          <rect x="66" y="84" width="8" height="4" rx="1.5" fill="#451a03"/>
          <!-- 옆에 놓인 묵상 노트(회신란)와 만년필 -->
          <polygon points="184,78 326,72 340,108 194,114" fill="#fffdf9" stroke="#64748b" stroke-width="1.3"/>
          <line x1="204" y1="88" x2="298" y2="84" stroke="#334155" stroke-width="1.6"/>
          <line x1="208" y1="98" x2="284" y2="95" stroke="#b45309" stroke-width="1.8"/>
          <!-- 만년필 실루엣 -->
          <line x1="286" y1="94" x2="338" y2="48" stroke="#e2e8f0" stroke-width="3.2" stroke-linecap="round"/>
          <polygon points="282,97 288,91 291,95" fill="#fbbf24"/>
        </g>
      </svg>"""
    },
    {
        "id": "overloaded_cart",
        "label": "무거운 하중을 가득 실은 수레와 깊게 패인 바퀴 자국",
        "default_sub": "수레의 하중과 정직한 직면",
        "keywords": {
            "수레": 8, "수레바퀴": 8, "하중": 7, "곡식 단": 8, "실린 양": 7,
            "아랫자리를 누르리니": 8, "흙을 누름": 7, "삐걱": 6, "부채": 5,
            "미수금": 5, "무게": 4, "아모스 2장 13절": 8, "짐을 덜어": 6
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="무거운 하중을 가득 실은 수레와 깊게 패인 바퀴 자국">
        <defs>
          <linearGradient id="gCartSky" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#231f20"/>
            <stop offset="0.55" stop-color="#4a3525"/>
            <stop offset="1" stop-color="#8c583a"/>
          </linearGradient>
          <linearGradient id="gCartGround" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#2c221b"/>
            <stop offset="1" stop-color="#17120e"/>
          </linearGradient>
          <radialGradient id="gCartGlow" cx="0.72" cy="0.28" r="0.55">
            <stop offset="0" stop-color="#f3c88b" stop-opacity="0.45"/>
            <stop offset="1" stop-color="#231f20" stop-opacity="0"/>
          </radialGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gCartSky)"/>
        <rect width="674" height="160" fill="url(#gCartGlow)"/>
        <!-- 지평선 언덕과 눌린 대지 -->
        <path d="M0 112 Q180 104 340 116 T674 108 L674 160 L0 160 Z" fill="url(#gCartGround)"/>
        <!-- 깊게 패인 수레바퀴 자국 -->
        <path d="M40 156 Q190 132 320 128" fill="none" stroke="#110d0a" stroke-width="5" stroke-linecap="round"/>
        <path d="M40 155 Q190 131 320 127" fill="none" stroke="#6e4f3a" stroke-width="1.2" opacity="0.6"/>
        <path d="M95 160 Q225 138 345 132" fill="none" stroke="#110d0a" stroke-width="4" stroke-linecap="round"/>
        <!-- 겹겹이 쌓인 무거운 단과 장부 더미 (수레 상부) -->
        <g transform="translate(230, 26)">
          <!-- 곡식 단/짐 더미 레이어 -->
          <path d="M22 62 Q85 12 156 58 Z" fill="#7a5230" stroke="#2b1d12" stroke-width="1.2"/>
          <rect x="28" y="48" width="118" height="15" rx="3" fill="#a47142" stroke="#2b1d12" stroke-width="1"/>
          <rect x="18" y="34" width="136" height="16" rx="3" fill="#8b5a32" stroke="#2b1d12" stroke-width="1"/>
          <rect x="30" y="20" width="114" height="15" rx="3" fill="#b8844f" stroke="#2b1d12" stroke-width="1"/>
          <rect x="44" y="7" width="88" height="14" rx="3" fill="#9a4a2e" stroke="#2b1d12" stroke-width="1"/>
          <!-- 묶은 밧줄과 하중 압박선 -->
          <line x1="62" y1="7" x2="54" y2="64" stroke="#2b1d12" stroke-width="2"/>
          <line x1="114" y1="7" x2="122" y2="64" stroke="#2b1d12" stroke-width="2"/>
          <!-- 수레 적재함 프레임 (무게에 휘어진 형상) -->
          <path d="M8 64 Q88 73 168 62 L160 78 Q88 86 16 78 Z" fill="#4e3422" stroke="#1f140d" stroke-width="1.5"/>
          <!-- 길게 뻗은 수레 채 -->
          <line x1="162" y1="72" x2="248" y2="92" stroke="#5c3d28" stroke-width="4.5" stroke-linecap="round"/>
          <!-- 무거운 나무 바퀴 -->
          <circle cx="88" cy="86" r="28" fill="none" stroke="#3a2518" stroke-width="6"/>
          <circle cx="88" cy="86" r="25" fill="none" stroke="#c89d6c" stroke-width="1" opacity="0.5"/>
          <circle cx="88" cy="86" r="6" fill="#9a4a2e" stroke="#1f140d" stroke-width="1.5"/>
          <line x1="88" y1="58" x2="88" y2="114" stroke="#3a2518" stroke-width="2.5"/>
          <line x1="60" y1="86" x2="116" y2="86" stroke="#3a2518" stroke-width="2.5"/>
          <line x1="68" y1="66" x2="108" y2="106" stroke="#3a2518" stroke-width="2"/>
          <line x1="108" y1="66" x2="68" y2="106" stroke="#3a2518" stroke-width="2"/>
        </g>
        <!-- 땅이 갈라지는 압박 크랙 -->
        <path d="M318 140 L302 152 M318 140 L335 155 M318 140 L288 144" stroke="#c9956b" stroke-width="1.3" opacity="0.65"/>
      </svg>"""
    },
    {
        "id": "prison_letter_scroll",
        "label": "감옥 창살 너머 스며드는 등불과 사슬 옆에 펼쳐진 간구의 서신",
        "default_sub": "빌레몬서 · 매임 속에서도 명령 대신 간구를 택하는 손",
        "keywords": {
            "빌레몬": 10, "오네시모": 10, "갇힌 자": 9, "데스미오스": 10, "데스모스": 10,
            "파라칼로": 10, "간구": 8, "감옥": 8, "심복": 9, "스플랑크나": 10,
            "승낙": 8, "자의": 7, "아킵보": 8, "동역자": 7, "영접": 8, "회계하라": 9
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="감옥 창살 너머 등불과 사슬 옆에 펼쳐진 서신">
        <defs>
          <linearGradient id="gPrisonBg" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#141821"/>
            <stop offset="0.55" stop-color="#262936"/>
            <stop offset="1" stop-color="#4a3728"/>
          </linearGradient>
          <radialGradient id="gCandleGlow" cx="0.64" cy="0.48" r="0.45">
            <stop offset="0" stop-color="#ffdfa0" stop-opacity="0.6"/>
            <stop offset="0.5" stop-color="#d99b52" stop-opacity="0.2"/>
            <stop offset="1" stop-color="#141821" stop-opacity="0"/>
          </radialGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gPrisonBg)"/>
        <rect width="674" height="160" fill="url(#gCandleGlow)"/>
        <!-- 좌측 석조 감옥 창살과 새어드는 빛 -->
        <rect x="58" y="14" width="110" height="92" rx="4" fill="#1e2433" stroke="#3b4254" stroke-width="2"/>
        <line x1="86" y1="14" x2="86" y2="106" stroke="#11151f" stroke-width="4"/>
        <line x1="113" y1="14" x2="113" y2="106" stroke="#11151f" stroke-width="4"/>
        <line x1="140" y1="14" x2="140" y2="106" stroke="#11151f" stroke-width="4"/>
        <polygon points="86,106 140,106 260,160 120,160" fill="#f3c88b" opacity="0.12"/>
        <!-- 석조 책상 상판 -->
        <rect x="0" y="122" width="674" height="38" fill="#231c18"/>
        <line x1="0" y1="122" x2="674" y2="122" stroke="#6e5644" stroke-width="1.2"/>
        <!-- 풀려 내려놓인 철사슬 고리 (데스모스) -->
        <g transform="translate(215, 118)" fill="none" stroke="#8c96a6" stroke-width="3">
          <ellipse cx="18" cy="14" rx="14" ry="7"/>
          <ellipse cx="38" cy="16" rx="14" ry="7"/>
          <ellipse cx="58" cy="13" rx="14" ry="7"/>
        </g>
        <!-- 펼쳐진 양피지 서신과 갈대펜 -->
        <polygon points="310,114 468,110 484,142 298,146" fill="#f5ebd6" stroke="#8c6d46" stroke-width="1"/>
        <line x1="330" y1="122" x2="442" y2="120" stroke="#7a5838" stroke-width="1.4"/>
        <line x1="326" y1="129" x2="450" y2="127" stroke="#9c7e5e" stroke-width="1"/>
        <line x1="322" y1="136" x2="418" y2="134" stroke="#9c7e5e" stroke-width="1"/>
        <line x1="452" y1="92" x2="496" y2="138" stroke="#c89d6c" stroke-width="2.5" stroke-linecap="round"/>
        <!-- 등잔과 따뜻한 불꽃 -->
        <ellipse cx="545" cy="116" rx="22" ry="8" fill="#9a6b3e"/>
        <path d="M545 92 Q553 104 545 112 Q537 104 545 92 Z" fill="#ffd97d"/>
      </svg>"""
    },
    {
        "id": "earthen_vessel_treasure",
        "label": "금이 간 질그릇의 틈새로 밝게 새어 나오는 보배의 빛",
        "default_sub": "고린도후서 · 질그릇의 약함 속에서 드러나는 하나님의 능력",
        "keywords": {
            "질그릇": 10, "보배": 10, "고린도후서": 8, "겉사람": 9, "속사람": 9,
            "환난": 8, "위로": 8, "사형 선고": 9, "살리시는 하나님": 9, "장막 집": 9,
            "파네로테": 9, "예수의 생명": 9, "약한 것": 7, "능력": 6, "향기": 8
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="금이 간 질그릇 틈새로 새어 나오는 보배의 빛">
        <defs>
          <linearGradient id="gVesselBg" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#121824"/>
            <stop offset="0.5" stop-color="#242b38"/>
            <stop offset="1" stop-color="#3d2e24"/>
          </linearGradient>
          <radialGradient id="gTreasureGlow" cx="0.5" cy="0.54" r="0.46">
            <stop offset="0" stop-color="#fff4cc" stop-opacity="0.75"/>
            <stop offset="0.45" stop-color="#f5b95f" stop-opacity="0.28"/>
            <stop offset="1" stop-color="#121824" stop-opacity="0"/>
          </radialGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gVesselBg)"/>
        <rect width="674" height="160" fill="url(#gTreasureGlow)"/>
        <!-- 빛살 광선 -->
        <polygon points="337,84 210,0 255,0" fill="#fff3c4" opacity="0.22"/>
        <polygon points="337,84 420,0 468,0" fill="#fff3c4" opacity="0.22"/>
        <polygon points="337,84 540,40 560,82" fill="#fff3c4" opacity="0.16"/>
        <rect x="0" y="132" width="674" height="28" fill="#1b1613"/>
        <!-- 투박한 토기 질그릇 실루엣 -->
        <g transform="translate(285, 28)">
          <path d="M32 8 L72 8 L66 24 C92 38 96 78 74 104 L30 104 C8 78 12 38 38 24 Z" fill="#6e4730" stroke="#2b1a10" stroke-width="2"/>
          <ellipse cx="52" cy="8" rx="20" ry="4.5" fill="#4a2e1e" stroke="#2b1a10" stroke-width="1.5"/>
          <!-- 질그릇의 균열(금)에서 뿜어져 나오는 황금빛 보배 -->
          <path d="M48 26 L56 46 L44 64 L58 84 L50 100" fill="none" stroke="#fff9db" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M56 46 L72 56 M44 64 L28 74" fill="none" stroke="#ffd875" stroke-width="2" stroke-linecap="round"/>
        </g>
      </svg>"""
    },
    {
        "id": "unveiled_mirror_letter",
        "label": "돌판과 먹물이 아닌 마음판에 새겨진 편지와 걷힌 수건의 빛",
        "default_sub": "고린도후서 3장 · 수건이 벗겨진 얼굴로 비추는 주의 영광",
        "keywords": {
            "추천서": 9, "마음의 비석": 10, "육비": 10, "돌비": 10, "먹으로": 9,
            "수건": 10, "모세": 8, "영광": 7, "거울": 8, "자유": 7, "그리스도의 편지": 10,
            "일군": 7, "새 언약": 8, "문자로": 8, "영으로": 8
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="걷힌 수건과 빛을 비추는 마음판의 서신">
        <defs>
          <linearGradient id="gVeilSky" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#192236"/>
            <stop offset="0.55" stop-color="#344966"/>
            <stop offset="1" stop-color="#c9956b"/>
          </linearGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gVeilSky)"/>
        <rect x="0" y="130" width="674" height="30" fill="#211d1a"/>
        <!-- 좌측: 차가운 두 돌판 -->
        <g transform="translate(150, 46)">
          <path d="M0 20 A22 20 0 0 1 44 20 L44 84 L0 84 Z" fill="#525b66" stroke="#2b3138" stroke-width="1.5"/>
          <path d="M48 20 A22 20 0 0 1 92 20 L92 84 L48 84 Z" fill="#606a75" stroke="#2b3138" stroke-width="1.5"/>
        </g>
        <!-- 우측: 바람에 걷혀 올라가는 반투명 수건과 빛나는 열린 서신 -->
        <polygon points="365,58 495,58 512,130 348,130" fill="#fffaf0" stroke="#c89d6c" stroke-width="1.5"/>
        <path d="M350 62 Q430 14 540 28 Q490 54 460 72 Z" fill="#e2e8f0" opacity="0.45"/>
        <circle cx="430" cy="40" r="26" fill="#fff6d6" opacity="0.35"/>
      </svg>"""
    },
    {
        "id": "justice_river_tent",
        "label": "메마른 광야를 가르고 흐르는 공의의 강물과 다시 세워진 장막",
        "default_sub": "아모스 5·9장 · 마르지 않는 하수같이 흐르는 정의와 회복",
        "keywords": {
            "하수": 10, "공의가 물": 10, "강물": 8, "다윗의 무너진 장막": 10, "장막": 7,
            "기근": 8, "말씀을 듣지": 9, "여호와를 찾으라": 9, "살리라": 8, "벧엘": 8,
            "길갈": 8, "사마리아": 7, "사로잡힌": 7, "돌이키리라": 8, "여름 실과": 9
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="광야를 흐르는 공의의 강물과 회복된 장막">
        <defs>
          <linearGradient id="gRiverSky" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#162436"/>
            <stop offset="0.5" stop-color="#2b4c66"/>
            <stop offset="1" stop-color="#d49a6a"/>
          </linearGradient>
          <linearGradient id="gWater" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#93c5fd"/>
            <stop offset="1" stop-color="#1d4ed8"/>
          </linearGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gRiverSky)"/>
        <!-- 광야 언덕 -->
        <path d="M0 106 Q190 88 360 108 T674 98 L674 160 L0 160 Z" fill="#3a2d24"/>
        <!-- 굽이쳐 흐르는 공의의 강물 -->
        <path d="M350 106 Q290 122 330 138 Q380 150 240 160 L430 160 Q450 142 395 128 Q360 116 385 106 Z" fill="url(#gWater)" opacity="0.88"/>
        <!-- 언덕 위에 다시 세워진 따뜻한 빛의 장막 -->
        <polygon points="480,104 522,68 564,104" fill="#d97706" stroke="#2b1d12" stroke-width="1.5"/>
        <polygon points="510,104 522,82 534,104" fill="#fef3c7"/>
      </svg>"""
    },
    {
        "id": "pastoral_listening_chairs",
        "label": "따뜻한 찻잔을 사이에 두고 마주 놓인 두 의자와 펼쳐진 성경",
        "default_sub": "판단보다 경청이 먼저 머무는 상담과 심방의 자리",
        "keywords": {
            "심방": 8, "상담": 8, "당회": 8, "성도": 7, "경청": 8, "인격": 7,
            "성경적 사고": 8, "말씀": 5, "기도": 6, "위로": 6, "화해": 8, "용서": 8
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="마주 놓인 두 의자와 따뜻한 찻잔과 펼쳐진 성경">
        <defs>
          <linearGradient id="gStudyWarm" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#231f1d"/>
            <stop offset="0.6" stop-color="#3d322a"/>
            <stop offset="1" stop-color="#6e503b"/>
          </linearGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gStudyWarm)"/>
        <rect x="0" y="128" width="674" height="32" fill="#1c1613"/>
        <!-- 원목 탁자 -->
        <rect x="235" y="102" width="204" height="8" rx="2" fill="#8c6239"/>
        <rect x="260" y="110" width="8" height="34" fill="#5c3d22"/>
        <rect x="406" y="110" width="8" height="34" fill="#5c3d22"/>
        <!-- 펼쳐진 성경과 두 찻잔 -->
        <polygon points="302,94 372,94 378,102 296,102" fill="#f7f2e7"/>
        <rect x="262" y="90" width="14" height="12" rx="2" fill="#d9c3b0"/>
        <rect x="398" y="90" width="14" height="12" rx="2" fill="#d9c3b0"/>
        <!-- 양옆에 마주 서 있는 원목 의자 실루엣 -->
        <path d="M168 58 L168 142 M168 106 L214 106 L214 142" fill="none" stroke="#a47551" stroke-width="5" stroke-linecap="round"/>
        <path d="M506 58 L506 142 M506 106 L460 106 L460 142" fill="none" stroke="#a47551" stroke-width="5" stroke-linecap="round"/>
      </svg>"""
    },
    {
        "id": "cheongpungho_mirror_invitation",
        "label": "옥순봉·구담봉 능선과 거울처럼 잔잔한 청풍호 수면, 물가 데크에 멈추어 선 고요한 뒷모습",
        "default_sub": "제천 청풍호반 · 과잉활동의 피로를 내려놓는 사색적 삶(Han, 2010)",
        "keywords": {
            "청풍호반": 14, "옥순봉": 14, "구담봉": 14, "내륙의 바다": 12,
            "과잉활동": 12, "피로사회": 12, "사색적 삶": 12, "나무 데크": 12
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="충북 제천 옥순봉·구담봉 산능선과 거울처럼 고요한 청풍호 수면, 물가 나무 데크에 멈추어 선 사람">
        <defs>
          <linearGradient id="gCpSky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#1e354b"/>
            <stop offset="0.52" stop-color="#3a6073"/>
            <stop offset="1" stop-color="#a8c0d0"/>
          </linearGradient>
          <linearGradient id="gCpWater" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#52798d"/>
            <stop offset="0.5" stop-color="#2c4a63"/>
            <stop offset="1" stop-color="#162838"/>
          </linearGradient>
        </defs>
        <rect width="674" height="86" fill="url(#gCpSky)"/>
        <rect x="0" y="86" width="674" height="74" fill="url(#gCpWater)"/>
        <!-- 먼 제천 능선과 옥순봉·구담봉 기암절벽 실루엣 -->
        <path d="M0 86 L0 58 Q95 36 190 62 Q265 28 345 54 Q430 22 520 56 Q595 40 674 52 L674 86 Z" fill="#2d4440" opacity="0.88"/>
        <path d="M180 86 L215 42 L248 56 L278 34 L315 86 Z" fill="#1f312e" opacity="0.92"/>
        <!-- 거울 같은 청풍호 수면에 드리운 산 그림자 반영 -->
        <path d="M180 86 L215 122 L248 110 L278 128 L315 86 Z" fill="#1a3040" opacity="0.55"/>
        <!-- 옅은 물안개와 잔잔한 수평선 결 -->
        <line x1="0" y1="86" x2="674" y2="86" stroke="#dce7ee" stroke-width="1" opacity="0.65"/>
        <line x1="80" y1="104" x2="590" y2="104" stroke="#a8c0d0" stroke-width="0.9" opacity="0.4"/>
        <line x1="140" y1="122" x2="520" y2="122" stroke="#a8c0d0" stroke-width="0.8" opacity="0.3"/>
        <!-- 우측 물가 나무 데크 난간과 두 손을 얹고 멈추어 선 뒷모습 -->
        <g transform="translate(470, 92)">
          <polygon points="0,68 48,18 190,18 204,68" fill="#4a3728" stroke="#291d14" stroke-width="1.2"/>
          <line x1="38" y1="28" x2="194" y2="28" stroke="#6b4f3a" stroke-width="1.2"/>
          <line x1="24" y1="44" x2="198" y2="44" stroke="#6b4f3a" stroke-width="1.2"/>
          <!-- 데크 난간 기둥과 가로대 -->
          <line x1="48" y1="0" x2="48" y2="18" stroke="#3b2a1e" stroke-width="3"/>
          <line x1="118" y1="0" x2="118" y2="18" stroke="#3b2a1e" stroke-width="3"/>
          <line x1="188" y1="0" x2="188" y2="18" stroke="#3b2a1e" stroke-width="3"/>
          <line x1="44" y1="2" x2="192" y2="2" stroke="#5c4230" stroke-width="2.5"/>
          <!-- 호수를 응시하는 인물의 고요한 실루엣 -->
          <circle cx="84" cy="-22" r="6.5" fill="#16222c"/>
          <path d="M72 -14 C72 -14 84 -16 96 -14 L92 18 L76 18 Z" fill="#1e2d3a"/>
        </g>
      </svg>"""
    },
    {
        "id": "cheongpungho_shalom_coordinates",
        "label": "거친 물줄기를 깊은 수심으로 침전시키는 청풍호와 동심원 수면 위에 겹쳐진 평강의 좌표",
        "default_sub": "내면의 담수량과 치유 · 삶의 상처를 가라앉히는 ‘평강의 좌표’",
        "keywords": {
            "평강의 좌표": 16, "담수량": 14, "흙탕물": 14, "부유물": 14,
            "침전": 14, "세무의 책상": 14, "목양의 강단": 14, "생채기": 12
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="깊은 수심으로 부유물을 침전시키는 호수와 수면 위 동심원 나침반 평강 좌표">
        <defs>
          <linearGradient id="gDeepLake" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#284b63"/>
            <stop offset="0.45" stop-color="#1b3548"/>
            <stop offset="1" stop-color="#0d1b26"/>
          </linearGradient>
          <radialGradient id="gShalomCore" cx="0.5" cy="0.48" r="0.42">
            <stop offset="0" stop-color="#e2c799" stop-opacity="0.42"/>
            <stop offset="1" stop-color="#0d1b26" stop-opacity="0"/>
          </radialGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gDeepLake)"/>
        <rect width="674" height="160" fill="url(#gShalomCore)"/>
        <!-- 깊은 수심 아래로 가라앉아 정화되는 부유물 입자들 -->
        <g fill="#94a3b8" opacity="0.38">
          <circle cx="140" cy="118" r="2"/><circle cx="185" cy="132" r="1.5"/><circle cx="230" cy="124" r="2.2"/>
          <circle cx="440" cy="122" r="1.8"/><circle cx="495" cy="134" r="2"/><circle cx="535" cy="116" r="1.6"/>
        </g>
        <!-- 수면 위로 퍼져나가며 잔잔히 수렴하는 동심원 파동 -->
        <g fill="none" stroke="#9ec1d4" stroke-width="1.2" opacity="0.55">
          <ellipse cx="337" cy="76" rx="46" ry="15"/>
          <ellipse cx="337" cy="76" rx="102" ry="30"/>
          <ellipse cx="337" cy="76" rx="168" ry="46"/>
          <ellipse cx="337" cy="76" rx="242" ry="62" stroke-dasharray="6 4"/>
        </g>
        <!-- 영혼의 영점을 조율하는 '평강의 좌표(방위선과 중심 별)' -->
        <g stroke="#e6c786" stroke-width="1.3" opacity="0.85">
          <line x1="210" y1="76" x2="464" y2="76"/>
          <line x1="337" y1="18" x2="337" y2="134"/>
          <polygon points="337,54 342,71 360,76 342,81 337,98 332,81 314,76 332,71" fill="#f5deb3" stroke="none"/>
        </g>
      </svg>"""
    },
    {
        "id": "cheongpungho_whisper_golden_ripples",
        "label": "호렙산의 세미한 음성처럼 해 질 녘 청풍호의 잔잔한 수면 위로 번져 나가는 금빛 윤슬",
        "default_sub": "열왕기상 19:12 · 사 30:15 · 고강도 열정을 넘어선 세미한 음성과 안식의 저항(Brueggemann, 2014)",
        "keywords": {
            "세미한 음성": 16, "콜 드마마 다카": 16, "고강도 열정": 14, "엘리야": 14,
            "갈멜산": 14, "호렙산": 14, "브루그만": 14, "윤슬": 14, "사 30:15": 14
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="해 질 녘 청풍호의 깊고 고요한 수면 위로 잔잔히 번지는 금빛 윤슬">
        <defs>
          <linearGradient id="gSunsetCp" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#1e293b"/>
            <stop offset="0.45" stop-color="#475569"/>
            <stop offset="0.78" stop-color="#c27d38"/>
            <stop offset="1" stop-color="#f3c677"/>
          </linearGradient>
          <linearGradient id="gSunsetLake" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#334e68"/>
            <stop offset="0.5" stop-color="#1e354b"/>
            <stop offset="1" stop-color="#102030"/>
          </linearGradient>
        </defs>
        <rect width="674" height="78" fill="url(#gSunsetCp)"/>
        <rect x="0" y="78" width="674" height="82" fill="url(#gSunsetLake)"/>
        <!-- 먼 산능선과 석양빛 -->
        <circle cx="337" cy="64" r="22" fill="#fde68a" opacity="0.75"/>
        <path d="M0 78 Q120 56 250 70 T490 62 L674 68 L674 78 Z" fill="#243447"/>
        <!-- 수면 위로 잔잔하게 반짝이는 금빛 윤슬 (세미한 음성의 파동) -->
        <g stroke="#fde68a" stroke-linecap="round">
          <line x1="305" y1="86" x2="369" y2="86" stroke-width="2.2" opacity="0.9"/>
          <line x1="288" y1="94" x2="386" y2="94" stroke-width="1.8" opacity="0.8"/>
          <line x1="270" y1="103" x2="404" y2="103" stroke-width="1.6" opacity="0.75"/>
          <line x1="295" y1="112" x2="379" y2="112" stroke-width="1.5" opacity="0.7"/>
          <line x1="255" y1="122" x2="419" y2="122" stroke-width="1.4" opacity="0.65"/>
          <line x1="280" y1="132" x2="394" y2="132" stroke-width="1.2" opacity="0.55"/>
          <line x1="310" y1="142" x2="364" y2="142" stroke-width="1.1" opacity="0.45"/>
        </g>
        <g fill="#fef3c7" opacity="0.85">
          <circle cx="242" cy="98" r="1.5"/><circle cx="432" cy="100" r="1.5"/>
          <circle cx="225" cy="116" r="1.3"/><circle cx="448" cy="114" r="1.3"/>
          <circle cx="262" cy="128" r="1.4"/><circle cx="412" cy="126" r="1.4"/>
        </g>
      </svg>"""
    },
    {
        "id": "gunsan_junkin_three_stones",
        "label": "늦가을 구암동산 묘역의 큰 비석 발치에 나란히 누운 조지·시드니·프랜시스의 세 작은 묘석",
        "default_sub": "군산 구암동산 선교사 묘역 · 단장(斷腸)의 세월을 품은 세 아기의 묘비",
        "keywords": {
            "구암동산": 14, "전킨": 14, "조지": 12, "시드니": 12, "프랜시스": 12,
            "세 개의 작은": 12, "묘석": 12, "화강암 비석": 10, "국화 한 송이": 10, "생후 8개월": 12
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="군산 구암동산 선교사 묘역의 큰 화강암 비석과 발치에 나란히 누운 세 아기의 작은 묘석">
        <defs>
          <linearGradient id="gGuamSky" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#1e293b"/>
            <stop offset="0.55" stop-color="#334155"/>
            <stop offset="1" stop-color="#b48a5a"/>
          </linearGradient>
          <linearGradient id="gGuamTurf" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#4d5e43"/>
            <stop offset="1" stop-color="#293524"/>
          </linearGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gGuamSky)"/>
        <!-- 먼 군산 앞바다와 구암동산 언덕 능선 -->
        <path d="M0 96 Q180 78 360 92 T674 84 L674 160 L0 160 Z" fill="#2c3a2f" opacity="0.82"/>
        <path d="M0 108 Q250 96 490 106 T674 102 L674 160 L0 160 Z" fill="url(#gGuamTurf)"/>
        <!-- 전킨(전위렴) 선교사 부부의 회색 화강암 비석 -->
        <g transform="translate(155, 32)">
          <rect x="0" y="72" width="76" height="10" rx="1" fill="#78716c" stroke="#292524" stroke-width="1.2"/>
          <path d="M8 72 L8 14 Q38 4 68 14 L68 72 Z" fill="#a8a29e" stroke="#292524" stroke-width="1.4"/>
          <!-- 비석 십자가 각인 -->
          <line x1="38" y1="22" x2="38" y2="42" stroke="#44403c" stroke-width="2"/>
          <line x1="30" y1="29" x2="46" y2="29" stroke="#44403c" stroke-width="2"/>
          <line x1="20" y1="52" x2="56" y2="52" stroke="#57534e" stroke-width="1.2"/>
          <line x1="24" y1="59" x2="52" y2="59" stroke="#57534e" stroke-width="1.2"/>
          <!-- 비석 앞 흰 국화 한 송이 -->
          <circle cx="38" cy="74" r="4.5" fill="#fef3c7" stroke="#d97706" stroke-width="0.8"/>
          <path d="M26 76 L34 75 M42 75 L50 77" stroke="#3f6212" stroke-width="1.5" stroke-linecap="round"/>
        </g>
        <!-- 발치 잔디밭에 나란히 누운 조지·시드니·프랜시스의 작은 평면 묘석 3기 -->
        <g transform="translate(278, 108)">
          <!-- 첫째 조지 (생후 8개월) -->
          <polygon points="0,16 56,12 64,26 8,30" fill="#d6d3d1" stroke="#44403c" stroke-width="1.3"/>
          <line x1="16" y1="19" x2="46" y2="17" stroke="#57534e" stroke-width="1.2"/>
          <line x1="20" y1="24" x2="42" y2="22" stroke="#78716c" stroke-width="1"/>
          <!-- 둘째 시드니 (생후 2개월) -->
          <polygon points="84,16 140,12 148,26 92,30" fill="#d6d3d1" stroke="#44403c" stroke-width="1.3"/>
          <line x1="100" y1="19" x2="130" y2="17" stroke="#57534e" stroke-width="1.2"/>
          <line x1="104" y1="24" x2="126" y2="22" stroke="#78716c" stroke-width="1"/>
          <!-- 셋째 프랜시스 (생후 20일) -->
          <polygon points="168,16 224,12 232,26 176,30" fill="#d6d3d1" stroke="#44403c" stroke-width="1.3"/>
          <line x1="184" y1="19" x2="214" y2="17" stroke="#57534e" stroke-width="1.2"/>
          <line x1="188" y1="24" x2="210" y2="22" stroke="#78716c" stroke-width="1"/>
        </g>
        <!-- 가을바람에 흩날리는 노란 은행잎들 -->
        <g fill="#eab308" opacity="0.88">
          <path d="M480 44 C486 38 494 42 490 50 L482 48 Z"/>
          <path d="M525 66 C531 60 539 64 535 72 L527 70 Z"/>
          <path d="M350 96 C356 90 364 94 360 102 L352 100 Z"/>
          <path d="M430 136 C436 130 444 134 440 142 L432 140 Z"/>
        </g>
      </svg>"""
    },
    {
        "id": "junkin_wheat_grain_incarnation",
        "label": "십자가 아래 땅에 떨어져 죽은 한 알의 밀알과 궁멀의 흙 위에 피어난 무수한 생명의 이삭",
        "default_sub": "요한복음 12장 24절 · 값비싼 제자도(Bonhoeffer, 1937)와 성육신적 선교(Bosch, 1991)",
        "keywords": {
            "값비싼 제자도": 14, "Bonhoeffer": 14, "성육신적 선교": 14, "Bosch": 14,
            "궁멀 전씨": 14, "버지니아": 12, "한 알의 밀": 14, "영명학교": 12, "멜볼딘": 12
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="십자가 아래 땅에 떨어진 한 알의 밀알과 궁멀 땅에 피어난 황금빛 이삭들">
        <defs>
          <linearGradient id="gMillSky" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#1c1917"/>
            <stop offset="0.5" stop-color="#442b1d"/>
            <stop offset="1" stop-color="#9a6b3b"/>
          </linearGradient>
          <radialGradient id="gSeedGlow" cx="0.5" cy="0.72" r="0.45">
            <stop offset="0" stop-color="#fde68a" stop-opacity="0.65"/>
            <stop offset="1" stop-color="#1c1917" stop-opacity="0"/>
          </radialGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gMillSky)"/>
        <rect width="674" height="160" fill="url(#gSeedGlow)"/>
        <!-- 버지니아 고향의 흙과 조선 궁멀의 흙이 하나로 합쳐진 대지 단면 -->
        <path d="M0 112 Q190 102 337 112 T674 106 L674 160 L0 160 Z" fill="#291d16"/>
        <path d="M0 124 Q220 116 337 124 T674 118 L674 160 L0 160 Z" fill="#1c130e"/>
        <!-- 중앙 흙 속에 묻혀 빛을 발하는 한 알의 밀알 -->
        <ellipse cx="337" cy="128" rx="9" ry="5.5" transform="rotate(-18 337 128)" fill="#fbbf24" stroke="#fef3c7" stroke-width="1.5"/>
        <!-- 밀알에서 뻗어 올라온 줄기와 무수한 황금빛 밀 이삭들 (구암교회·영명학교·예수병원·3.5 만세운동 상징) -->
        <g stroke="#f59e0b" stroke-width="1.8" fill="none" stroke-linecap="round">
          <path d="M337 122 L337 32"/>
          <path d="M337 122 Q305 88 272 44"/>
          <path d="M337 122 Q369 88 402 44"/>
          <path d="M337 122 Q275 96 224 58"/>
          <path d="M337 122 Q399 96 450 58"/>
        </g>
        <g fill="#fde68a">
          <ellipse cx="337" cy="28" rx="4" ry="7"/><ellipse cx="331" cy="40" rx="3.5" ry="6"/><ellipse cx="343" cy="40" rx="3.5" ry="6"/>
          <ellipse cx="272" cy="40" rx="4" ry="7"/><ellipse cx="266" cy="52" rx="3.5" ry="6"/><ellipse cx="278" cy="52" rx="3.5" ry="6"/>
          <ellipse cx="402" cy="40" rx="4" ry="7"/><ellipse cx="396" cy="52" rx="3.5" ry="6"/><ellipse cx="408" cy="52" rx="3.5" ry="6"/>
          <ellipse cx="224" cy="54" rx="4" ry="6.5"/><ellipse cx="450" cy="54" rx="4" ry="6.5"/>
        </g>
        <!-- 좌측 언덕 위 십자가 실루엣 -->
        <g stroke="#e7e5e4" stroke-width="2.2" opacity="0.75">
          <line x1="112" y1="42" x2="112" y2="104"/>
          <line x1="94" y1="60" x2="130" y2="60"/>
        </g>
      </svg>"""
    },
    {
        "id": "gunsan_memorial_steps_prayer",
        "label": "가을 햇살이 내려앉은 군산선교역사관 계단과 130년 전 밀알의 터전 위로 이어지는 발걸음",
        "default_sub": "군산선교역사관 계단 · 빚진 자의 일상으로 살아내는 한 알의 밀알",
        "keywords": {
            "군산선교역사관": 14, "온비아": 14, "찻사찻": 14, "표지석": 12,
            "빚진 자": 12, "순교의 시대": 12, "계단": 10, "고집과 욕심": 12
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="가을 햇살이 비치는 군산선교역사관 화강암 계단과 표지석">
        <defs>
          <linearGradient id="gMemSky" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#1e293b"/>
            <stop offset="0.5" stop-color="#475569"/>
            <stop offset="1" stop-color="#d97706"/>
          </linearGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gMemSky)"/>
        <!-- 구암동산 붉은 벽돌 선교역사관 아치 창과 지붕 실루엣 -->
        <g transform="translate(230, 16)">
          <polygon points="0,34 107,4 214,34" fill="#7c2d12" stroke="#431407" stroke-width="1.5"/>
          <rect x="14" y="34" width="186" height="54" fill="#9a3412" stroke="#431407" stroke-width="1.2"/>
          <path d="M52 72 L52 48 A12 12 0 0 1 76 48 L76 72 Z" fill="#fef3c7" opacity="0.85"/>
          <path d="M95 72 L95 46 A12 12 0 0 1 119 46 L119 72 Z" fill="#fef3c7" opacity="0.85"/>
          <path d="M138 72 L138 48 A12 12 0 0 1 162 48 L162 72 Z" fill="#fef3c7" opacity="0.85"/>
        </g>
        <!-- 계단과 좌측 '군산선교역사관' 화강암 표지석 -->
        <g fill="#cbd5e1" stroke="#475569" stroke-width="1.2">
          <rect x="190" y="102" width="294" height="12"/>
          <rect x="170" y="114" width="334" height="14"/>
          <rect x="150" y="128" width="374" height="14"/>
          <rect x="130" y="142" width="414" height="18"/>
        </g>
        <g transform="translate(138, 82)">
          <rect x="0" y="0" width="42" height="58" rx="3" fill="#e2e8f0" stroke="#334155" stroke-width="1.5"/>
          <line x1="12" y1="12" x2="30" y2="12" stroke="#334155" stroke-width="2"/>
          <line x1="12" y1="22" x2="30" y2="22" stroke="#334155" stroke-width="2"/>
          <line x1="12" y1="32" x2="30" y2="32" stroke="#334155" stroke-width="2"/>
        </g>
        <!-- 따스한 늦가을 햇살 광선 -->
        <polygon points="520,0 674,0 674,160 360,160" fill="#fde68a" opacity="0.18"/>
      </svg>"""
    },
    {
        "id": "gosrak_garden_cheomseongdae",
        "label": "푸른 잔디밭과 솔숲 너머 수천 개의 검붉은 옹기 군락과 나란히 선 첨성대",
        "default_sub": "익산 고스락 산책길 · ‘부드러운 매혹(Soft Fascination)’",
        "keywords": {
            "고스락": 12, "이화동산": 12, "첨성대": 12, "천문대": 10, "부드러운 매혹": 12,
            "Soft Fascination": 12, "솔숲": 9, "검붉은 항아리": 10, "장독대 정원": 10
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="익산 고스락 정원의 솔숲과 옹기 군락 그리고 첨성대">
        <defs>
          <linearGradient id="gGosrakSky" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#1d352d"/>
            <stop offset="0.52" stop-color="#355e4b"/>
            <stop offset="1" stop-color="#c89b6e"/>
          </linearGradient>
          <linearGradient id="gLawn" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#3f6a4e"/>
            <stop offset="1" stop-color="#223d2c"/>
          </linearGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gGosrakSky)"/>
        <!-- 먼 솔숲 능선 -->
        <path d="M0 98 Q140 76 290 92 T674 86 L674 160 L0 160 Z" fill="#244233" opacity="0.85"/>
        <!-- 좌측 소나무 실루엣 -->
        <g fill="#172c21">
          <rect x="44" y="54" width="5" height="56"/>
          <ellipse cx="46" cy="48" rx="28" ry="11"/>
          <ellipse cx="62" cy="58" rx="22" ry="9"/>
          <rect x="92" y="62" width="4" height="48"/>
          <ellipse cx="94" cy="56" rx="22" ry="9"/>
        </g>
        <!-- 푸른 잔디밭 마당 -->
        <path d="M0 112 Q240 100 470 110 T674 106 L674 160 L0 160 Z" fill="url(#gLawn)"/>
        <!-- 잔디밭 위를 스치는 낮은 바람결 -->
        <path d="M28 132 Q120 124 210 132 M140 144 Q250 136 350 142" fill="none" stroke="#a7d7b8" stroke-width="1.3" stroke-linecap="round" opacity="0.55"/>
        <!-- 중앙: 대지를 메운 검붉은 옹기 군락 -->
        <g transform="translate(210, 86)">
          <!-- 뒷줄 옹기들 -->
          <ellipse cx="24" cy="24" rx="11" ry="14" fill="#4a2518"/>
          <ellipse cx="52" cy="24" rx="12" ry="15" fill="#592d1e"/>
          <ellipse cx="82" cy="24" rx="11" ry="14" fill="#4a2518"/>
          <ellipse cx="112" cy="24" rx="12" ry="15" fill="#592d1e"/>
          <ellipse cx="142" cy="24" rx="11" ry="14" fill="#4a2518"/>
          <ellipse cx="172" cy="24" rx="12" ry="15" fill="#592d1e"/>
          <!-- 앞줄 옹기들과 뚜껑(전) -->
          <ellipse cx="38" cy="38" rx="15" ry="19" fill="#6b3422" stroke="#2b140c" stroke-width="1"/>
          <ellipse cx="38" cy="20" rx="11" ry="3.5" fill="#3b1c12"/>
          <ellipse cx="74" cy="39" rx="16" ry="20" fill="#7c3d28" stroke="#2b140c" stroke-width="1"/>
          <ellipse cx="74" cy="20" rx="12" ry="3.5" fill="#3b1c12"/>
          <ellipse cx="112" cy="38" rx="15" ry="19" fill="#632f1f" stroke="#2b140c" stroke-width="1"/>
          <ellipse cx="112" cy="20" rx="11" ry="3.5" fill="#3b1c12"/>
          <ellipse cx="150" cy="39" rx="16" ry="20" fill="#753824" stroke="#2b140c" stroke-width="1"/>
          <ellipse cx="150" cy="20" rx="12" ry="3.5" fill="#3b1c12"/>
          <ellipse cx="188" cy="38" rx="15" ry="19" fill="#6b3422" stroke="#2b140c" stroke-width="1"/>
          <ellipse cx="188" cy="20" rx="11" ry="3.5" fill="#3b1c12"/>
        </g>
        <!-- 우측: 잔디밭 끝자락에 조화롭게 서 있는 축소 첨성대 -->
        <g transform="translate(505, 42)">
          <!-- 기단 -->
          <rect x="8" y="76" width="52" height="8" fill="#8c8275" stroke="#3a352f" stroke-width="1.2"/>
          <!-- 원통형 몸체 (곡선 석축) -->
          <path d="M14 76 Q22 48 23 18 L45 18 Q46 48 54 76 Z" fill="#a89f91" stroke="#3a352f" stroke-width="1.3"/>
          <!-- 석축 단 줄눈 -->
          <line x1="16" y1="64" x2="52" y2="64" stroke="#5c5449" stroke-width="1"/>
          <line x1="19" y1="52" x2="49" y2="52" stroke="#5c5449" stroke-width="1"/>
          <line x1="21" y1="40" x2="47" y2="40" stroke="#5c5449" stroke-width="1"/>
          <line x1="22" y1="28" x2="46" y2="28" stroke="#5c5449" stroke-width="1"/>
          <!-- 남쪽 창구 -->
          <rect x="29" y="42" width="10" height="10" fill="#2c2623" stroke="#5c5449" stroke-width="1"/>
          <!-- 상부 정(井)자석 -->
          <rect x="19" y="12" width="30" height="6" fill="#968c7e" stroke="#3a352f" stroke-width="1.2"/>
          <rect x="21" y="7" width="26" height="5" fill="#ada395" stroke="#3a352f" stroke-width="1.2"/>
        </g>
      </svg>"""
    },
    {
        "id": "onggi_breathing_chorus",
        "label": "세월의 상흔을 품은 옹기들의 둥근 어깨와 미세 숨구멍을 스치는 바람의 합창",
        "default_sub": "미세 숨구멍의 호흡(Kim & Hu, 2023) · ‘시련 후 성장(Posttraumatic Growth)’",
        "keywords": {
            "숨구멍": 12, "발효": 10, "총탄 자국": 14, "시련 후 성장": 14,
            "Posttraumatic Growth": 14, "잘록한 단지": 12, "둥근 어깨": 12, "미생물": 10,
            "Kim & Hu": 14, "Tedeschi": 14, "무언의 화음": 12
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="숨구멍으로 호흡하는 다양한 옹기들과 바람의 합창 파동">
        <defs>
          <linearGradient id="gOnggiBg" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#1f1612"/>
            <stop offset="0.55" stop-color="#3d271d"/>
            <stop offset="1" stop-color="#6e4730"/>
          </linearGradient>
          <radialGradient id="gSunBreath" cx="0.5" cy="0.35" r="0.55">
            <stop offset="0" stop-color="#ffdfa0" stop-opacity="0.45"/>
            <stop offset="1" stop-color="#1f1612" stop-opacity="0"/>
          </radialGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gOnggiBg)"/>
        <rect width="674" height="160" fill="url(#gSunBreath)"/>
        <rect x="0" y="132" width="674" height="28" fill="#17100c"/>
        <!-- 항아리들의 둥근 어깨를 스치며 울려 퍼지는 바람과 합창의 파동선 -->
        <path d="M24 72 Q165 44 337 68 T650 58" fill="none" stroke="#f5d799" stroke-width="1.6" opacity="0.65"/>
        <path d="M40 88 Q190 62 355 84 T640 76" fill="none" stroke="#e8b878" stroke-width="1.2" stroke-dasharray="5 3" opacity="0.55"/>
        <!-- 미세 숨구멍으로 드나드는 빛 숨결 입자들 -->
        <g fill="#fff3c4" opacity="0.75">
          <circle cx="176" cy="64" r="2"/><circle cx="204" cy="52" r="1.5"/><circle cx="272" cy="74" r="2.2"/>
          <circle cx="322" cy="48" r="1.8"/><circle cx="394" cy="62" r="2"/><circle cx="456" cy="54" r="1.6"/>
          <circle cx="512" cy="68" r="2"/>
        </g>
        <!-- 좌측: 배가 넉넉하게 부른 항아리 -->
        <g transform="translate(135, 36)">
          <path d="M24 14 L76 14 C106 34 104 76 78 98 L22 98 C-4 76 -6 34 24 14 Z" fill="#6b3422" stroke="#24110a" stroke-width="2"/>
          <ellipse cx="50" cy="12" rx="30" ry="6" fill="#472115" stroke="#24110a" stroke-width="1.5"/>
          <path d="M16 36 Q50 44 84 36" fill="none" stroke="#c89b6e" stroke-width="1.4" opacity="0.6"/>
        </g>
        <!-- 중앙: 허리가 잘록한 단지 -->
        <g transform="translate(285, 44)">
          <path d="M22 10 L58 10 C68 24 52 44 64 62 C74 76 66 86 56 90 L24 90 C14 86 6 76 16 62 C28 44 12 24 22 10 Z" fill="#82432c" stroke="#24110a" stroke-width="2"/>
          <ellipse cx="40" cy="9" rx="20" ry="4.5" fill="#4f2618"/>
        </g>
        <!-- 우측: 세월의 더께와 한국전쟁 총탄 자국(상흔)을 품고 버텨온 거친 독 -->
        <g transform="translate(415, 28)">
          <path d="M26 16 L84 16 C110 40 106 82 84 106 L26 106 C4 82 0 40 26 16 Z" fill="#542c1e" stroke="#1f0e08" stroke-width="2"/>
          <ellipse cx="55" cy="14" rx="33" ry="6.5" fill="#381b11" stroke="#1f0e08" stroke-width="1.5"/>
          <!-- 총탄 상흔과 그 자리에서 빛나는 성숙의 결 -->
          <circle cx="48" cy="56" r="5.5" fill="#24110a" stroke="#e8b878" stroke-width="1.5"/>
          <path d="M48 56 L38 48 M48 56 L60 50 M48 56 L44 68" stroke="#e8b878" stroke-width="1.2" opacity="0.8"/>
          <circle cx="72" cy="70" r="4" fill="#24110a" stroke="#d49a6a" stroke-width="1.2"/>
        </g>
      </svg>"""
    },
    {
        "id": "sunset_walk_onggi_harmony",
        "label": "노을빛 내려앉는 장독대 산책길과 세월의 바람을 호흡하며 걸어가는 발걸음",
        "default_sub": "유리병의 밀폐를 넘어 숨구멍으로 세월을 호흡하는 삶",
        "keywords": {
            "유리병": 12, "화음 한 줄": 14, "숙성된 옹기들처럼": 14, "비바람을 받아들이며": 12,
            "조급하게 결과를 재촉": 12, "익어가는 삶": 12, "소망해 본다": 10
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="노을빛 장독대 사잇길 산책로와 천천히 걸어가는 사람">
        <defs>
          <linearGradient id="gSunsetWalk" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#1e2436"/>
            <stop offset="0.45" stop-color="#5e3c38"/>
            <stop offset="0.8" stop-color="#c97a4b"/>
            <stop offset="1" stop-color="#f5cf96"/>
          </linearGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gSunsetWalk)"/>
        <!-- 지평선 노을 태양빛 -->
        <circle cx="337" cy="96" r="38" fill="#ffe8b8" opacity="0.42"/>
        <!-- 대지와 원근감 있는 산책로 사잇길 -->
        <rect x="0" y="106" width="674" height="54" fill="#261b16"/>
        <polygon points="312,106 362,106 470,160 204,160" fill="#8c6d53" opacity="0.65"/>
        <!-- 좌우로 도열한 숙성된 옹기 대열 (원근 배치) -->
        <g fill="#422015" stroke="#1b0c07" stroke-width="1">
          <!-- 좌측 열 -->
          <ellipse cx="140" cy="134" rx="22" ry="24"/>
          <ellipse cx="195" cy="126" rx="18" ry="20"/>
          <ellipse cx="240" cy="118" rx="14" ry="16"/>
          <ellipse cx="276" cy="112" rx="10" ry="12"/>
          <!-- 우측 열 -->
          <ellipse cx="534" cy="134" rx="22" ry="24"/>
          <ellipse cx="479" cy="126" rx="18" ry="20"/>
          <ellipse cx="434" cy="118" rx="14" ry="16"/>
          <ellipse cx="398" cy="112" rx="10" ry="12"/>
        </g>
        <!-- 사잇길 한가운데서 바람을 맞으며 천천히 걸어가는 산책자의 실루엣 -->
        <g transform="translate(329, 70)">
          <circle cx="8" cy="7" r="5" fill="#231815"/>
          <path d="M2 15 L14 15 L16 38 L0 38 Z" fill="#231815"/>
        </g>
        <!-- 오선지처럼 흐르는 그윽한 저녁 바람의 화음 -->
        <path d="M60 54 Q210 38 340 52 T614 44" fill="none" stroke="#fff3d1" stroke-width="1.3" opacity="0.6"/>
        <path d="M90 64 Q230 48 360 62 T600 54" fill="none" stroke="#fff3d1" stroke-width="1" opacity="0.45"/>
      </svg>"""
    },
    {
        "id": "broken_shield_flight",
        "label": "끊어진 도피의 길과 땅에 내려놓인 활·방패",
        "default_sub": "다섯 번의 ‘할 수 없으며’가 멈춰 선 자리",
        "keywords": {
            "도피": 9, "마노스": 10, "빠른 자": 8, "활을 당기는": 8, "활을 가진": 8,
            "용사": 7, "벌거벗고": 8, "할 수 없으며": 9, "날랜 말": 7,
            "방패": 6, "아모스 2장 14": 8, "도망": 6, "수단": 5
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="끊어진 도피의 길과 땅에 내려놓인 부러진 활과 방패">
        <defs>
          <linearGradient id="gFlightSky" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#161b26"/>
            <stop offset="0.5" stop-color="#2e3440"/>
            <stop offset="1" stop-color="#6b3e2e"/>
          </linearGradient>
          <linearGradient id="gCliff" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#3b322c"/>
            <stop offset="1" stop-color="#181412"/>
          </linearGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gFlightSky)"/>
        <!-- 먼 산맥과 폭풍 구름 -->
        <path d="M0 95 L110 68 L210 88 L330 58 L430 92 L430 160 L0 160 Z" fill="#222630" opacity="0.7"/>
        <!-- 절벽으로 끊어진 길 (도피의 소멸) -->
        <polygon points="0,110 390,104 422,160 0,160" fill="url(#gCliff)"/>
        <polygon points="520,118 674,112 674,160 495,160" fill="#1e1916"/>
        <!-- 끊어진 협곡 아래의 심연 안개 -->
        <rect x="385" y="104" width="140" height="56" fill="#12151e" opacity="0.65"/>
        <!-- 절벽 끝까지 이어지다 끊긴 길의 흔적 -->
        <path d="M30 158 Q180 126 388 108" fill="none" stroke="#8c7a6b" stroke-width="2" stroke-dasharray="6 4" opacity="0.75"/>
        <!-- 땅에 버려진 청동 방패 -->
        <g transform="translate(175, 108)">
          <ellipse cx="42" cy="22" rx="36" ry="13" fill="#7c5036" stroke="#241710" stroke-width="2"/>
          <ellipse cx="42" cy="20" rx="28" ry="9" fill="none" stroke="#d4af7a" stroke-width="1.2" opacity="0.7"/>
          <circle cx="42" cy="19" r="5" fill="#d4af7a"/>
        </g>
        <!-- 부러진 활과 흩어진 화살 -->
        <g transform="translate(268, 96)">
          <path d="M10 34 Q38 4 68 24" fill="none" stroke="#c89d6c" stroke-width="3" stroke-linecap="round"/>
          <path d="M74 28 Q94 38 106 20" fill="none" stroke="#c89d6c" stroke-width="3" stroke-linecap="round"/>
          <line x1="12" y1="34" x2="58" y2="28" stroke="#e5dec9" stroke-width="1" stroke-dasharray="3 2" opacity="0.8"/>
          <line x1="25" y1="42" x2="88" y2="16" stroke="#d8d0c6" stroke-width="1.8"/>
          <polygon points="88,16 80,16 84,22" fill="#9a4a2e"/>
        </g>
        <!-- 절벽 끝에 멈춰 선 작은 실루엣 -->
        <g transform="translate(366, 72)">
          <circle cx="8" cy="6" r="4.5" fill="#e5dec9"/>
          <path d="M3 13 L13 13 L15 34 L1 34 Z" fill="#e5dec9"/>
        </g>
      </svg>"""
    },
    {
        "id": "cross_and_open_hands",
        "label": "언덕 위 십자가의 머묾과 빛 아래 내려놓은 두 손",
        "default_sub": "모든 수단이 그친 자리에서 기다리는 주님의 일인칭",
        "keywords": {
            "십자가": 10, "구원할 수 없도다": 10, "마 27": 9, "두 손을 내려놓": 9,
            "내려놓은 채": 8, "일인칭을 기다린다": 9, "사랑의 머묾": 9,
            "마지막 수단마저 내려놓고": 8, "골고다": 8, "주님": 5
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="언덕 위 십자가와 수직의 은총 빛 아래 내려놓은 두 손">
        <defs>
          <linearGradient id="gCrossSky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#141c2e"/>
            <stop offset="0.6" stop-color="#2c3545"/>
            <stop offset="1" stop-color="#59463a"/>
          </linearGradient>
          <linearGradient id="gGraceBeam" x1="0.5" y1="0" x2="0.5" y2="1">
            <stop offset="0" stop-color="#fff6dc" stop-opacity="0.55"/>
            <stop offset="0.7" stop-color="#e8c382" stop-opacity="0.22"/>
            <stop offset="1" stop-color="#e8c382" stop-opacity="0"/>
          </linearGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gCrossSky)"/>
        <!-- 하늘에서 수직으로 내리비치는 은총의 빛기둥 -->
        <polygon points="295,0 379,0 445,160 229,160" fill="url(#gGraceBeam)"/>
        <!-- 먼 골고다 언덕 실루엣 -->
        <path d="M0 132 Q190 118 337 102 Q484 118 674 134 L674 160 L0 160 Z" fill="#1e1a18"/>
        <!-- 언덕 위 십자가 -->
        <g transform="translate(325, 38)">
          <rect x="9" y="0" width="6" height="68" rx="1" fill="#3a281e"/>
          <rect x="-8" y="16" width="40" height="5.5" rx="1" fill="#3a281e"/>
          <rect x="10" y="0" width="2" height="68" fill="#f5e1b5" opacity="0.45"/>
        </g>
        <!-- 전면 책상/제단 위에 조용히 펼쳐 내려놓은 두 손과 정직한 장부 한 권 -->
        <rect x="0" y="138" width="674" height="22" fill="#2b211b"/>
        <line x1="0" y1="138" x2="674" y2="138" stroke="#8a6f5a" stroke-width="1"/>
        <!-- 펼쳐진 노트(장부) -->
        <polygon points="274,132 398,132 412,148 260,148" fill="#f7f2e7"/>
        <line x1="336" y1="132" x2="336" y2="148" stroke="#b8ab99" stroke-width="1.2"/>
        <!-- 양옆에 힘을 빼고 내려놓은 두 손의 온화한 실루엣 -->
        <path d="M212 142 Q232 128 254 136 Q262 140 252 146 L210 146 Z" fill="#d8b496" opacity="0.9"/>
        <path d="M462 142 Q442 128 420 136 Q412 140 422 146 L464 146 Z" fill="#d8b496" opacity="0.9"/>
      </svg>"""
    },
    {
        "id": "silenced_prophets_cedar",
        "label": "뿌리째 흔들리는 백향목과 침묵을 강요당한 예언자의 두루마리",
        "default_sub": "아모스 2:9–12 · 은혜의 사슬과 조직적 침묵",
        "keywords": {
            "백향목": 8, "상수리나무": 8, "아모리": 7, "나실인": 8, "포도주": 7,
            "예언하지 말라": 9, "조직적 침묵": 9, "입을 틀어막": 8, "침묵의 명령": 8
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="백향목 그루터기와 봉인된 예언자의 두루마리">
        <defs>
          <linearGradient id="gCedarSky" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#1d2625"/>
            <stop offset="0.6" stop-color="#35423c"/>
            <stop offset="1" stop-color="#5e3a2c"/>
          </linearGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gCedarSky)"/>
        <path d="M0 124 L674 124 L674 160 L0 160 Z" fill="#231d19"/>
        <!-- 거대한 백향목/상수리나무 그루터기와 드러난 뿌리 -->
        <g transform="translate(120, 18)">
          <path d="M40 106 L52 30 L88 30 L100 106 Z" fill="#3a2b22"/>
          <path d="M18 118 Q45 102 52 96 M122 118 Q95 102 88 96 M70 106 L70 126" stroke="#5c4333" stroke-width="5" stroke-linecap="round"/>
          <ellipse cx="70" cy="30" rx="18" ry="5" fill="#8c6d53"/>
        </g>
        <!-- 돌단 위에 놓인 엎질러진 잔과 붉은 끈으로 묶인(침묵당한) 두루마리 -->
        <g transform="translate(350, 78)">
          <rect x="0" y="34" width="170" height="16" fill="#4a443f"/>
          <!-- 두루마리 -->
          <rect x="28" y="20" width="84" height="14" rx="7" fill="#efe6d5" stroke="#2c2520" stroke-width="1.2"/>
          <rect x="64" y="18" width="12" height="18" fill="#9a4a2e"/>
          <!-- 엎어진 포도주 잔 -->
          <path d="M128 32 L146 22 L146 34 Z" fill="#b89768"/>
          <ellipse cx="156" cy="34" rx="10" ry="3" fill="#7a2822" opacity="0.85"/>
        </g>
      </svg>"""
    },
    {
        "id": "office_ledger",
        "label": "형광등 불빛 아래 성벽처럼 쌓인 장부와 서류철",
        "default_sub": "숫자와 기록이 마주하는 조사실의 책상",
        "keywords": {
            "조사관": 9, "서류철": 9, "형광등": 8, "볼펜": 8, "세무대리인": 8,
            "계좌 내역": 7, "극대화 기법": 8, "소명 자료": 7, "의뢰인": 6, "장부": 4
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="서재 책상과 기록물">
        <defs>
          <linearGradient id="gRoom" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#2a2d34"/>
            <stop offset="0.55" stop-color="#3c3a37"/>
            <stop offset="1" stop-color="#231f1d"/>
          </linearGradient>
          <radialGradient id="gLamp" cx="0.5" cy="0.08" r="0.65">
            <stop offset="0" stop-color="#f7f2e4" stop-opacity="0.55"/>
            <stop offset="0.45" stop-color="#d8ceb8" stop-opacity="0.18"/>
            <stop offset="1" stop-color="#2a2d34" stop-opacity="0"/>
          </radialGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gRoom)"/>
        <rect width="674" height="160" fill="url(#gLamp)"/>
        <rect x="210" y="10" width="254" height="5" rx="2.5" fill="#fffdf7" opacity="0.92"/>
        <rect x="200" y="8" width="274" height="9" rx="4" fill="#fffdf7" opacity="0.18"/>
        <polygon points="0,126 674,126 674,160 0,160" fill="#4a382b"/>
        <line x1="0" y1="126" x2="674" y2="126" stroke="#7b6554" stroke-width="1.2"/>
        <g transform="translate(118,54)">
          <rect x="0" y="56" width="128" height="16" fill="#8b7d6b" stroke="#2c2520" stroke-width="1"/>
          <rect x="6" y="59" width="116" height="10" fill="#efe8dc"/>
          <rect x="4" y="40" width="122" height="16" fill="#5c4638" stroke="#2c2520" stroke-width="1"/>
          <rect x="10" y="43" width="110" height="10" fill="#f3ede2"/>
          <rect x="2" y="24" width="118" height="16" fill="#9a4a2e" stroke="#2c2520" stroke-width="1"/>
          <rect x="8" y="27" width="106" height="10" fill="#efe8dc"/>
          <rect x="10" y="10" width="112" height="14" fill="#68635c" stroke="#2c2520" stroke-width="1"/>
          <rect x="15" y="13" width="102" height="8" fill="#f5efe6"/>
        </g>
        <g transform="translate(264,44)">
          <rect x="0" y="66" width="138" height="16" fill="#4f4842" stroke="#26211d" stroke-width="1"/>
          <rect x="6" y="69" width="126" height="10" fill="#ede5d8"/>
          <rect x="5" y="50" width="130" height="16" fill="#7a6855" stroke="#26211d" stroke-width="1"/>
          <rect x="11" y="53" width="118" height="10" fill="#f5efe6"/>
          <rect x="2" y="34" width="132" height="16" fill="#3b424c" stroke="#26211d" stroke-width="1"/>
          <rect x="8" y="37" width="120" height="10" fill="#ebe3d5"/>
          <rect x="8" y="18" width="124" height="16" fill="#8c5840" stroke="#26211d" stroke-width="1"/>
          <rect x="14" y="21" width="112" height="10" fill="#f5efe6"/>
        </g>
        <polygon points="432,134 522,131 534,148 442,152" fill="#f7f2e8" opacity="0.92"/>
        <line x1="445" y1="138" x2="508" y2="136" stroke="#9a4a2e" stroke-width="1.6"/>
        <line x1="447" y1="143" x2="515" y2="141" stroke="#7a7068" stroke-width="1"/>
        <line x1="538" y1="130" x2="578" y2="147" stroke="#d8d0c6" stroke-width="2.4" stroke-linecap="round"/>
        <circle cx="538" cy="130" r="1.8" fill="#9a4a2e"/>
      </svg>"""
    },
    {
        "id": "steering_wheel_night",
        "label": "시동을 걸지 못한 밤 차 안과 적막한 가로등 불빛",
        "default_sub": "홀로 남은 자리에서 마주하는 도덕적 상처와 침묵",
        "keywords": {
            "운전대": 10, "시동을 걸지": 10, "차에 올라": 9, "엘리베이터": 7,
            "도덕적 상처": 9, "강요된 순응": 8, "잠 못 이루며": 7, "천장을 바라": 7
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="밤 주차장 자동차 운전대와 가로등 불빛">
        <defs>
          <linearGradient id="gNightCar" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#0f172a"/>
            <stop offset="0.65" stop-color="#1e293b"/>
            <stop offset="1" stop-color="#090d16"/>
          </linearGradient>
          <radialGradient id="gStreetLamp" cx="0.72" cy="0.25" r="0.45">
            <stop offset="0" stop-color="#fbbf24" stop-opacity="0.5"/>
            <stop offset="0.5" stop-color="#f59e0b" stop-opacity="0.12"/>
            <stop offset="1" stop-color="#0f172a" stop-opacity="0"/>
          </radialGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gNightCar)"/>
        <rect width="674" height="160" fill="url(#gStreetLamp)"/>
        <!-- 창밖 가로등과 도시 그림자 -->
        <rect x="482" y="28" width="3" height="90" fill="#475569"/>
        <ellipse cx="483" cy="28" rx="14" ry="5" fill="#fef3c7"/>
        <!-- 대시보드와 운전대 실루엣 -->
        <path d="M0 118 Q337 104 674 122 L674 160 L0 160 Z" fill="#090d14"/>
        <circle cx="220" cy="138" r="54" fill="none" stroke="#1e2530" stroke-width="10"/>
        <circle cx="220" cy="138" r="52" fill="none" stroke="#475569" stroke-width="1.2" opacity="0.6"/>
        <line x1="172" y1="126" x2="268" y2="126" stroke="#1e2530" stroke-width="8"/>
        <rect x="298" y="122" width="46" height="18" rx="3" fill="#1e293b" opacity="0.8"/>
      </svg>"""
    },
    {
        "id": "watchtower_horizon",
        "label": "파수꾼의 성루와 어스름한 밤을 가르는 새벽 지평선",
        "default_sub": "하박국의 성루에서 기다리는 응답과 여명",
        "keywords": {
            "파수꾼": 9, "성루": 9, "하박국": 9, "파수하는": 8, "망대": 8,
            "묵시": 7, "지체될지라도": 8, "기다리라": 7, "기원전 7세기": 8
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="파수꾼의 성루와 새벽 지평선">
        <defs>
          <linearGradient id="gWatchSky" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#172038"/>
            <stop offset="0.52" stop-color="#3b4866"/>
            <stop offset="0.82" stop-color="#b87d56"/>
            <stop offset="1" stop-color="#f2d6ae"/>
          </linearGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gWatchSky)"/>
        <path d="M0 122 Q210 96 420 114 T674 102 L674 160 L0 160 Z" fill="#231f24" opacity="0.85"/>
        <!-- 성루(망대) 흉벽 실루엣 -->
        <path d="M60 160 L60 74 L84 74 L84 88 L108 88 L108 74 L132 74 L132 88 L156 88 L156 74 L180 74 L180 160 Z" fill="#181518"/>
        <!-- 성루 위에 서서 동쪽을 바라보는 파수꾼 -->
        <circle cx="144" cy="54" r="5" fill="#f2d6ae"/>
        <path d="M137 61 L151 61 L154 88 L134 88 Z" fill="#2b262c"/>
      </svg>"""
    },
    {
        "id": "withered_fig_olive",
        "label": "빈 들판의 무화과나무 가지와 어둠 속에 빛나는 별빛",
        "default_sub": "소출이 멈춘 자리에서 피어나는 조용한 신뢰",
        "keywords": {
            "무화과나무": 10, "포도나무": 9, "감람나무": 9, "외양간": 9,
            "소출이 없으며": 9, "열매가 없으며": 8, "밭에 식물이": 8, "여호와로 인하여": 8
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="빈 들판의 무화과나무와 별빛">
        <defs>
          <linearGradient id="gFigSky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#182238"/>
            <stop offset="0.65" stop-color="#3a445e"/>
            <stop offset="1" stop-color="#7c6354"/>
          </linearGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gFigSky)"/>
        <circle cx="480" cy="34" r="1.8" fill="#fff6dc"/>
        <circle cx="540" cy="24" r="1.4" fill="#fff6dc" opacity="0.8"/>
        <circle cx="390" cy="42" r="1.5" fill="#fff6dc" opacity="0.7"/>
        <path d="M0 126 Q240 108 674 128 L674 160 L0 160 Z" fill="#241e1a"/>
        <!-- 잎이 마른 무화과나무 가지와 끝에 맺힌 작은 새순 빛 -->
        <path d="M180 132 Q186 92 204 68 M204 68 Q170 46 142 40 M204 68 Q236 42 276 34 M228 52 Q248 28 264 20" fill="none" stroke="#2c221c" stroke-width="4.5" stroke-linecap="round"/>
        <circle cx="276" cy="34" r="3.5" fill="#f3d27c"/>
      </svg>"""
    },
    {
        "id": "plumbline_wall",
        "label": "기울어진 돌담 앞에 수직으로 드리워진 다림줄",
        "default_sub": "하나님의 기준선 앞에 드러나는 삶의 기울기",
        "keywords": {
            "다림줄": 10, "성벽": 7, "돌담": 7, "기준": 5, "공의": 6, "정의": 6, "아모스 7": 9
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="성벽과 수직으로 드리워진 다림줄">
        <defs>
          <linearGradient id="gPlumbSky" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#1e293b"/>
            <stop offset="1" stop-color="#475569"/>
          </linearGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gPlumbSky)"/>
        <!-- 약간 기울어진 돌벽 -->
        <polygon points="180,22 310,22 296,160 166,160" fill="#645b53" stroke="#2c2623" stroke-width="1.5"/>
        <!-- 수직 다림줄 -->
        <line x1="348" y1="0" x2="348" y2="112" stroke="#f8fafc" stroke-width="1.8"/>
        <polygon points="340,112 356,112 348,132" fill="#d97706" stroke="#fffbeb" stroke-width="1"/>
      </svg>"""
    },
    {
        "id": "dawn_study_window",
        "label": "서재 창문 너머로 어둠을 밀어내며 스며드는 새벽빛",
        "default_sub": "고통의 밤을 지나 일상의 자리로 스며드는 빛",
        "keywords": {
            "새벽": 7, "창문": 6, "햇살": 7, "아침": 6, "소망": 5, "빛이": 5
        },
        "svg": """<svg viewBox="0 0 674 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="서재 창문으로 스며드는 새벽빛">
        <defs>
          <linearGradient id="gDawn" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#1f2842"/>
            <stop offset="0.48" stop-color="#52586c"/>
            <stop offset="0.78" stop-color="#c9956b"/>
            <stop offset="1" stop-color="#f3dfc1"/>
          </linearGradient>
          <linearGradient id="gBeam" x1="1" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#fff6e0" stop-opacity="0.45"/>
            <stop offset="1" stop-color="#fff6e0" stop-opacity="0"/>
          </linearGradient>
        </defs>
        <rect width="674" height="160" fill="url(#gDawn)"/>
        <path d="M0 128 Q140 104 280 118 T560 108 L674 115 L674 160 L0 160 Z" fill="#2b2628" opacity="0.65"/>
        <polygon points="420,0 674,0 674,160 220,160" fill="url(#gBeam)"/>
        <rect x="0" y="0" width="18" height="160" fill="#24201d" opacity="0.78"/>
        <rect x="656" y="0" width="18" height="160" fill="#24201d" opacity="0.78"/>
        <rect x="334" y="0" width="6" height="160" fill="#24201d" opacity="0.48"/>
        <rect x="0" y="77" width="674" height="5" fill="#24201d" opacity="0.38"/>
        <rect x="0" y="148" width="674" height="12" fill="#24201d" opacity="0.88"/>
      </svg>"""
    },
]


def extract_frontmatter(text):
    if text.startswith("---"):
        parts = text.split("---", 2)
        if len(parts) >= 3:
            return parts[1].strip(), parts[2].strip()
    return "", text.strip()


def chunk_paragraphs(paragraphs):
    n = len(paragraphs)
    if n <= 4:
        return [paragraphs]
    if n <= 7:
        mid = (n + 1) // 2
        return [paragraphs[:mid], paragraphs[mid:]]
    if n == 8:
        return [paragraphs[:3], paragraphs[3:6], paragraphs[6:]]
    if n in (9, 10):
        return [paragraphs[:4], paragraphs[4:7], paragraphs[7:]]
    pages = []
    idx = 0
    first = True
    while idx < n:
        step = 4 if first else 3
        first = False
        if n - (idx + step) == 1:
            step += 1
        pages.append(paragraphs[idx : idx + step])
        idx += step
    return pages


def extract_page_motif(p_list, default_sub):
    """페이지 내 문단에서 성경 구절이나 핵심 따옴표 어구를 추출하여 캡션 부제로 활용합니다."""
    joined = " ".join(p_list)
    # 1) 성경 장절 패턴 검색 (예: 빌레몬서 1장 8절, 아모스 2장 13절, 고린도후서 4장 7절 등)
    m_bib = re.search(
        r"((?:빌레몬서|고린도후서|히브리서|열왕기하|민수기|사사기|아모스|하박국|요한복음|마태복음|로마서|시편|잠언|욥기|이사야|예레미야|창세기|출애굽기|고후|몬|히|마|요|롬|시|암|합)\s*\d+\s*(?:장|:|편)\s*\d+(?:[–\-~]\d+)?\s*절?)",
        joined,
    )
    # 2) 문단 내 강조된 작은따옴표/큰따옴표 핵심 개념 검색
    m_quote = re.search(r"[‘“'\"]([^’”'\"]{3,28})[’”'\"]", joined)
    if m_bib and m_quote:
        return f"{m_bib.group(1)} · ‘{m_quote.group(1)}’"
    if m_bib:
        return m_bib.group(1)
    if default_sub and len(default_sub) > 12:
        return default_sub
    if m_quote:
        return f"‘{m_quote.group(1)}’"
    return default_sub


def select_scene_for_page(p_list, title, p_idx, used_scene_ids):
    """문단 텍스트의 어휘·메타포를 분석하여 가장 부합하는 컷 일러스트를 선택합니다."""
    page_text = " ".join(p_list) + " " + (title if p_idx == 0 else "")
    best_scene = None
    best_score = -1

    for scene in SCENE_LIBRARY:
        if scene["id"] in used_scene_ids:
            continue
        score = 0
        for kw, weight in scene["keywords"].items():
            count = page_text.count(kw)
            if count > 0:
                score += weight * (1 + min(count - 1, 2) * 0.35)
        if score > best_score:
            best_score = score
            best_scene = scene

    # 키워드 매칭 점수가 0인 일반 문단일 경우 텍스트 해시 기반으로 중복 없이 선택
    if best_scene is None or best_score <= 0:
        available = [s for s in SCENE_LIBRARY if s["id"] not in used_scene_ids]
        if not available:
            available = SCENE_LIBRARY
        h = int(hashlib.md5(page_text.encode("utf-8")).hexdigest(), 16)
        best_scene = available[h % len(available)]

    used_scene_ids.add(best_scene["id"])
    sub_text = extract_page_motif(p_list, best_scene["default_sub"])
    return best_scene["svg"], best_scene["label"], sub_text, best_scene["id"]


def build_figure_html(svg_code, label, sub_text, p_idx):
    fig_style = "" if p_idx == 0 else ' style="margin-top:26px"'
    cap_html = ""
    if label:
        right_span = f"<span>{html.escape(sub_text)}</span>" if sub_text else ""
        cap_html = (
            f'\n    <figcaption class="cut-caption">'
            f"<span>▲ {html.escape(label)}</span>{right_span}"
            f"</figcaption>"
        )
    return (
        f"  <figure{fig_style}>\n"
        f'    <div class="photo">\n'
        f"      {svg_code.strip()}\n"
        f"    </div>{cap_html}\n"
        f"  </figure>"
    )


def load_custom_cuts(filepath, cuts_arg=None):
    """파일별 커스텀 컷 정의(<파일명>.cuts.json 또는 --cuts)가 있으면 로드합니다."""
    candidates = []
    if cuts_arg:
        candidates.append(Path(cuts_arg))
    stem_path = os.path.splitext(filepath)[0]
    candidates.append(Path(stem_path + ".cuts.json"))
    for c in candidates:
        if c.exists():
            return json.loads(c.read_text(encoding="utf-8"))
    return None


THESIS_KEYWORDS = (
    "아니라",
    "비로소",
    "초청",
    "평강의 좌표",
    "평강",
    "유지되는 것이 아니",
    "유지되지 않는다",
    "원천이다",
    "호흡이다",
    "살아내고 싶다",
    "살아내게 하소서",
    "소망해 본다",
    "항복의 자리",
    "값비싼 제자도",
    "성육신적 선교",
    "한 알의 밀",
    "밀알의 걸음",
    "부드러운 매혹",
    "미세 숨구멍",
    "시련 후 성장",
    "무언의 화음",
    "깊은 장맛",
    "깨달았다",
    "발견했기 때문",
    "증언하고 있다",
    "벨로-샤브템 아다이",
    "네움 여호와",
    "무차르",
    "엘로헤이카",
    "친필 서명",
    "구원의 흔적",
    "대면의 자리",
    "하나님의 친구",
    "눈맞춤 하나면 충분",
    "마주 서 있습니다",
    "미회신 구간",
    "디르슈니 비흐유",
    "디르슈 에트-여호와 비흐유",
    "거래 장부가 소리 없이 덮이고",
    "결정적인 차이가 있다",
    "생명의 동작이었다",
    "첫째 명령의 목적어",
    "이중 은혜",
    "살려 내는 분부다",
    "존귀한 분부이기 때문",
    "거룩한 분부다",
)


def _highlight_quotes_outside_marks(escaped_html: str, max_quotes: int = 2) -> str:
    """이미 <mark>로 감싸지지 않은 핵심 인용구(‘...’, “...”)를 형광+볼드 처리합니다."""
    parts = re.split(r"(<mark class=\"hl\"><strong>.*?</strong></mark>)", escaped_html)
    count = 0
    quote_pat = re.compile(r"(‘[^’]{2,48}’|“[^”]{4,130}”)")

    for idx, part in enumerate(parts):
        if part.startswith('<mark class="hl">'):
            continue

        def _repl(m):
            nonlocal count
            if count >= max_quotes:
                return m.group(0)
            count += 1
            return f'<mark class="hl"><strong>{m.group(1)}</strong></mark>'

        parts[idx] = quote_pat.sub(_repl, part)
    return "".join(parts)


def sanitize_markdown_raw_html(text: str) -> str:
    """마크다운 원문에 실수로 기입된 <mark>, <strong> 태그 및 이스케이프 잔재를 표준 마크다운(**...**)으로 정화합니다."""
    if "<mark" in text or "<strong" in text or "&lt;mark" in text or "&lt;strong" in text:
        text = re.sub(
            r"&lt;mark[^&]*&gt;\s*&lt;strong&gt;(.*?)&lt;/strong&gt;\s*&lt;/mark&gt;",
            r"**\1**",
            text,
            flags=re.DOTALL,
        )
        text = re.sub(
            r"<mark[^>]*>\s*<strong>(.*?)</strong>\s*</mark>",
            r"**\1**",
            text,
            flags=re.DOTALL,
        )
        text = re.sub(
            r"<strong>\s*<mark[^>]*>(.*?)</mark>\s*</strong>",
            r"**\1**",
            text,
            flags=re.DOTALL,
        )
        text = re.sub(r"<mark[^>]*>(.*?)</mark>", r"==\1==", text, flags=re.DOTALL)
        text = re.sub(r"<strong>(.*?)</strong>", r"**\1**", text, flags=re.DOTALL)
    return text


def format_paragraph_with_highlights(para: str, is_dropcap: bool = False) -> str:
    """
    원문 텍스트 100%를 보존하면서 핵심 구절/문장을 형광펜 + 볼드체(<mark class="hl"><strong>...</strong></mark>)로 강조합니다.
    1) 원문에 실수로 포함된 <mark>/<strong> HTML 태그가 있으면 먼저 **...** 로 자동 정화하여 &lt;mark 이스케이프 노출을 원천 차단
    2) 마크다운에 명시적 ==...== 또는 **...** 가 있으면 해당 구절을 형광+볼드 변환
    3) 평문 에세이 단락이면 단락 내 핵심 명제절(결론/주제 문장)과 핵심 개념 인용구(‘...’, “...”)를 자동 형광+볼드 강조
    """
    para = sanitize_markdown_raw_html(para)
    para = re.sub(r"^#{2,6}\s+", "", para.strip())
    if "==" in para or "**" in para:
        esc = html.escape(para)
        esc = re.sub(
            r"==\*\*(.+?)\*\*==|\*\*==(.+?)==\*\*",
            lambda m: f'<mark class="hl"><strong>{m.group(1) or m.group(2)}</strong></mark>',
            esc,
        )
        esc = re.sub(
            r"==(.+?)==",
            r'<mark class="hl"><strong>\1</strong></mark>',
            esc,
        )
        esc = re.sub(
            r"\*\*(.+?)\*\*",
            r'<mark class="hl"><strong>\1</strong></mark>',
            esc,
        )
        return esc

    # 문장 분리 (마침표/물음표/느낌표 뒤 공백 기준, 원문 공백 완벽 보존)
    spans = []
    last_idx = 0
    for m in re.finditer(r"(?<=[.?!다요죠])\s+", para):
        spans.append((last_idx, m.start(), para[last_idx : m.start()]))
        last_idx = m.end()
    spans.append((last_idx, len(para), para[last_idx:]))

    best_i = -1
    best_score = -1
    for idx, (s_start, s_end, sent) in enumerate(spans):
        if is_dropcap and idx == 0 and len(spans) > 1:
            continue
        if len(sent.strip()) < 16:
            continue
        score = 0
        for kw in THESIS_KEYWORDS:
            if kw in sent:
                score += 4
        if idx == len(spans) - 1:
            score += 3
        elif idx == len(spans) - 2:
            score += 1
        if "‘" in sent or "“" in sent:
            score += 2
        if score > best_score:
            best_score = score
            best_i = idx

    if best_i == -1:
        best_i = len(spans) - 1 if (not is_dropcap or len(spans) > 1) else -1

    if best_i >= 0:
        s_start, s_end, sent = spans[best_i]
        hl_start, hl_end = s_start, s_end
        # 문장이 길고 쉼표로 절이 나뉘는 경우, 뒷부분 핵심 명제절(22자 이상)을 집중 강조하여 가독성을 높임
        if len(sent) > 78 and "," in sent:
            comma_positions = [m.end() for m in re.finditer(r",\s*", sent)]
            for c_pos in comma_positions:
                tail = sent[c_pos:]
                if 24 <= len(tail) <= 85:
                    hl_start = s_start + c_pos
                    break

        before = html.escape(para[:hl_start])
        target = html.escape(para[hl_start:hl_end])
        after = html.escape(para[hl_end:])
        combined = f'{before}<mark class="hl"><strong>{target}</strong></mark>{after}'
        return _highlight_quotes_outside_marks(combined, max_quotes=2)

    return _highlight_quotes_outside_marks(html.escape(para), max_quotes=2)


def process_file(filepath, template_html, out_suffix="", cuts_arg=None):
    filename = os.path.basename(filepath)
    name_without_ext = os.path.splitext(filename)[0]
    text = Path(filepath).read_text(encoding="utf-8")
    if "<mark" in text or "<strong" in text or "&lt;mark" in text:
        text = sanitize_markdown_raw_html(text)
        Path(filepath).write_text(text, encoding="utf-8")
    frontmatter, body = extract_frontmatter(text)

    # 날짜 추출
    date_str = ""
    m_date = re.match(r"^(\d{8})", name_without_ext)
    if m_date:
        d = m_date.group(1)
        date_str = f"{d[:4]}년 {d[4:6]}월 {d[6:]}일"
    else:
        ym = re.search(r"date:\s*([^\n]+)", frontmatter)
        if ym:
            date_str = ym.group(1).strip()

    # 제목 추출 및 본문 분리 (중간제목 ## 지원)
    lines = [ln.strip() for ln in body.splitlines()]
    title = ""
    sections = []  # list of (subhead_text, [paragraphs])
    curr_subhead = ""
    curr_paras = []
    buf = []

    def flush_buf():
        nonlocal buf, curr_paras
        if buf:
            curr_paras.append(" ".join(buf))
            buf = []

    has_explicit_h2 = any(ln.startswith("## ") for ln in lines)

    for ln in lines:
        if not ln:
            flush_buf()
            continue
        if ln.startswith("# ") and not title:
            flush_buf()
            title = ln[2:].strip()
            continue
        if ln.startswith("## "):
            flush_buf()
            if curr_subhead or curr_paras:
                sections.append((curr_subhead, curr_paras))
                curr_paras = []
            curr_subhead = ln[3:].strip()
            continue
        buf.append(ln)
    flush_buf()
    if curr_subhead or curr_paras:
        sections.append((curr_subhead, curr_paras))

    if not title:
        tm = re.search(r'title:\s*"?([^"\n]+)"?', frontmatter)
        title = tm.group(1).strip() if tm else name_without_ext

    # 페이지 분할 구성
    paged_sections = []  # list of (subhead_text, [paragraphs])
    if has_explicit_h2 and sections:
        for subh, paras in sections:
            paged_sections.append((subh, paras))
    else:
        all_paras = []
        for _, paras in sections:
            all_paras.extend(paras)
        chunked = chunk_paragraphs(all_paras)
        for p_list in chunked:
            paged_sections.append(("", p_list))

    pages_html = []
    total_pages = len(paged_sections)
    used_scene_ids = set()
    custom_cuts = load_custom_cuts(filepath, cuts_arg)

    for p_idx, (subhead, p_list) in enumerate(paged_sections):
        page_no = f"{p_idx + 1:03d}"

        if custom_cuts and p_idx < len(custom_cuts):
            cut_item = custom_cuts[p_idx]
            svg_code = cut_item["svg"]
            label = cut_item.get("label", "")
            sub_text = cut_item.get("sub", "")
            scene_id = cut_item.get("id", f"custom_{p_idx+1}")
        else:
            svg_code, label, sub_text, scene_id = select_scene_for_page(
                p_list, title, p_idx, used_scene_ids
            )

        print(f"  [Page {page_no}] Cut matched -> {scene_id} ({label})")
        fig_html = build_figure_html(svg_code, label, sub_text, p_idx)

        run_right = (
            f"{p_idx + 1:02d} · {date_str}"
            if (p_idx == 0 and date_str)
            else f"{p_idx + 1:02d} / {total_pages:02d}"
        )
        header_html = f'  <header class="runhead"><b>{html.escape(title)}</b><span>{html.escape(run_right)}</span></header>'

        top_block = ""
        if p_idx == 0:
            top_block = (
                f'\n  <p class="kicker">말씀과 묵상 · 에세이</p>\n'
                f'  <h1 id="doc-title">{html.escape(title)}</h1>'
            )

        subhead_html = ""
        if subhead:
            m_num = re.match(r"^([ⅠⅡⅢⅣⅤⅥⅦⅧⅨⅩ\d]+[\.\)]?)\s*(.*)$", subhead)
            style_attr = "" if p_idx == 0 else ' style="margin-top:18px"'
            if m_num:
                num_part, title_part = m_num.group(1), m_num.group(2)
                subhead_html = f'  <h2 class="subhead"{style_attr}><span class="subhead-num">{html.escape(num_part)}</span>{html.escape(title_part)}</h2>\n'
            else:
                subhead_html = f'  <h2 class="subhead"{style_attr}>{html.escape(subhead)}</h2>\n'

        is_last_page = (p_idx == total_pages - 1) and len(p_list) >= 2
        body_paras = p_list[:-1] if is_last_page else p_list
        addr_para = p_list[-1] if is_last_page else None

        body_lines = ['  <div class="body">']
        for i, para in enumerate(body_paras):
            esc = format_paragraph_with_highlights(para, is_dropcap=(i == 0))
            if i == 0:
                body_lines.append(f'    <p class="dc essay-p">{esc}</p>')
                if p_idx == 1 and len(body_paras) >= 2:
                    body_lines.append('    <span class="break"></span>')
            elif p_idx == 0 and i == len(body_paras) - 1 and len(body_paras) >= 3:
                body_lines.append(f'    <p class="pull essay-p">{esc}</p>')
            else:
                body_lines.append(f'    <p class="essay-p">{esc}</p>')
        body_lines.append("  </div>")

        addr_html = ""
        if addr_para:
            addr_html = (
                '\n  <section class="address">\n'
                f'    <p class="essay-p">{format_paragraph_with_highlights(addr_para, is_dropcap=False)}</p>\n'
                "  </section>"
            )

        foot_html = f'  <footer class="foot"><span>{page_no}</span><span>1단 / 18px · 1.8</span></footer>'

        page_block = (
            f'<article class="page">\n'
            f"{header_html}"
            f"{top_block}\n"
            f"{subhead_html}\n"
            f"{fig_html}\n\n"
            + "\n".join(body_lines)
            + f"{addr_html}\n\n"
            f"{foot_html}\n"
            f"</article>"
        )
        pages_html.append(page_block)

    final_html = template_html.replace("{TITLE}", html.escape(title)).replace(
        "{PAGES_HTML}", "\n\n".join(pages_html)
    )

    out_name = name_without_ext + out_suffix + ".html"
    output_path = os.path.join(os.path.dirname(filepath), out_name)
    Path(output_path).write_text(final_html, encoding="utf-8")
    return output_path, title, date_str


def deploy_to_repos(items, workspace_root):
    """생성된 HTML/MD 파일들을 bible-thought 및 sparkofbible에 복사·인덱스 갱신·Git Push까지 단 1회에 수행합니다."""
    repos = [
        os.path.join(workspace_root, "bible-thought"),
        os.path.join(workspace_root, "sparkofbible"),
    ]
    for repo in repos:
        if not os.path.isdir(repo):
            continue
        index_path = Path(repo) / "index.html"
        index_text = index_path.read_text(encoding="utf-8") if index_path.exists() else ""
        index_modified = False

        for md_path, html_path, title, date_str in items:
            html_name = os.path.basename(html_path)
            shutil.copy2(html_path, os.path.join(repo, html_name))

            safe_html_name = html_name.replace(" ", "_")
            if safe_html_name != html_name:
                shutil.copy2(html_path, os.path.join(repo, safe_html_name))

            card_title = f"{title} (A4 1단 지면 · 본문 연동 컷)"
            if index_text and safe_html_name not in index_text:
                anchor = '<h2 class="section-title">철학 · 신학 성찰 에세이</h2>\n        <div class="list-group">'
                badge = date_str if date_str else "A4 1단 지면 에세이"
                entry = f"""            <a href="./{safe_html_name}" class="list-item" target="_blank">
                <div class="item-info">
                    <h3>{html.escape(card_title)}</h3>
                    <p>{html.escape(badge)} · KoPub 바탕 18px · 본문 연동 와이드 컷 일러스트 수록</p>
                </div>
                <div class="arrow">→</div>
            </a>"""
                if anchor in index_text:
                    index_text = index_text.replace(anchor, anchor + "\n" + entry, 1)
                    index_modified = True

        if index_modified and index_path.exists():
            index_path.write_text(index_text, encoding="utf-8")

        subprocess.run(["git", "-C", repo, "add", "-A"], check=False)
        status = subprocess.run(
            ["git", "-C", repo, "status", "--porcelain"],
            capture_output=True,
            text=True,
            encoding="utf-8",
        )
        if status.stdout.strip():
            subprocess.run(
                ["git", "-C", repo, "commit", "-m", "Auto-deploy ait-html essays"],
                check=False,
            )
            subprocess.run(["git", "-C", repo, "push", "origin", "main"], check=False)
            print(f"Deployed & pushed: {repo}")
        else:
            print(f"No git changes to push in: {repo}")


def main():
    parser = argparse.ArgumentParser(
        description="Convert Markdown to A4 1-column + AI-HTML fused format with content-linked SVG cuts (ait-html)"
    )
    parser.add_argument("--file", help="Path to a single markdown file")
    parser.add_argument("--dir", help="Path to a directory containing markdown files")
    parser.add_argument("--pattern", default=".*", help="Regex pattern to filter filenames")
    parser.add_argument(
        "--template",
        default=os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "templates",
            "ait_template.html",
        ),
        help="Path to the HTML template",
    )
    parser.add_argument("--suffix", default="", help="Optional filename suffix (e.g. _1)")
    parser.add_argument("--cuts", help="Optional JSON file containing custom per-page SVG cuts")
    parser.add_argument(
        "--deploy",
        action="store_true",
        help="Automatically copy to bible-thought & sparkofbible, update index.html, and git push in one shot",
    )
    parser.add_argument(
        "--gosrak",
        action="store_true",
        help="Write the Gosrak essay markdown file and process it",
    )
    parser.add_argument(
        "--gosrak-ican",
        action="store_true",
        help="Write the Gosrak ican-write 5-stage design log and refined final essay, convert to ait-html, and deploy",
    )
    parser.add_argument(
        "--gunsan-ican",
        action="store_true",
        help="Write the Gunsan Missionary Cemetery ican-write 4th-stage draft, 5th-stage final essay, and design log, convert to ait-html, and deploy",
    )
    parser.add_argument(
        "--cheongpungho-ican",
        action="store_true",
        help="Write the Cheongpungho dual-agent (ican-drafter & ican-evaluator) 5-stage outputs, convert to ait-html, and deploy",
    )
    parser.add_argument(
        "--geonwoo-ican",
        action="store_true",
        help="Write the Geonwoo 31st Birthday & Amos 4 multi-round (Round 1-3) 5-stage outputs, convert to ait-html, and deploy",
    )
    parser.add_argument(
        "--amos5-ican",
        action="store_true",
        help="Write the 2026-11-10 Amos 5:1-6 multi-round (Round 1-3) 5-stage outputs (including 20261110_인격만들기_에세이), convert to ait-html, and deploy",
    )
    args = parser.parse_args()

    template_html = Path(args.template).read_text(encoding="utf-8")
    pattern_re = re.compile(args.pattern)
    workspace_root = str(Path(__file__).resolve().parents[4])
    processed_items = []

    if args.amos5_ican:
        amos5_draft1_md = """---
title: "살아내는 일도 주님께로부터 받은 거룩한 분부입니다 — ‘그리하면’의 거래 장부를 덮고 ‘그리고’의 호흡으로 읽는 아모스 5장 (초고 1)"
date: 2026-11-10
tags: [아모스5장, 디르슈니비흐유, 두줄의명령, 이중은혜, 세무상담실, 인격만들기, 초고1]
---

# 살아내는 일도 주님께로부터 받은 거룩한 분부입니다 — ‘그리하면’의 거래 장부를 덮고 ‘그리고’의 호흡으로 읽는 아모스 5장

새벽녘 책상 스탠드를 켜고 오래 손때 묻은 개역한글 성경을 펼치면, 아모스 5장 4절과 6절의 “너희는 나를 찾으라 그리하면 살리라”, “너희는 여호와를 찾으라 그리하면 살리라”라는 구절 아래에 예전에 그어 둔 연필 밑줄이 눈에 들어온다. 나는 오랫동안 그 문장 한가운데 자리 잡은 ‘그리하면’이라는 네 글자에 내 신앙의 무게중심을 실어 두곤 했다. 주님을 찾는 경건의 시간을 값으로 꼬박꼬박 치르면, 그 대가로 언젠가 내 삶이 풀리고 숨통이 트이는 ‘살리라’의 보상이 지급될 것처럼 은밀한 거래의 장부를 펴 놓고 있었던 셈이다. 그렇게 읽는 동안 주님을 찾는 일은 오늘 내가 치러야 할 고단한 의무가 되었고, 정작 살아내는 일은 모든 문제가 해결된 뒤에야 비로소 누릴 수 있는 미래의 상급으로 아득히 유예되어 있었다. 그런데 히브리어 원문을 한 단어씩 소리 내어 짚어 읽던 어느 새벽, 내 손끝이 4절의 ‘디르슈니 비흐유’(나를 찾으라, 그리고 살라)와 6절의 ‘디르슈 에트-여호와 비흐유’(여호와를 찾으라, 그리고 살라) 앞에서 우뚝 멈추어 섰다. 아모스 5장 1절부터 6절까지 일흔아홉 단어, 백다섯 개의 형태소를 아무리 뒤져 보아도 우리말 번역이 보태 놓은 ‘그리하면’이라는 조건 표지는 단 한 개도 없었다. 거기에는 오직 ‘찾으라’(‘다라시’)와 ‘살라’(‘하야’)라는 두 동사가 똑같은 칼 명령형 2인칭 남성 복수의 굵기로 나란히 서 있었고, 그 둘 사이를 잇는 것은 ‘그리고’를 뜻하는 접속사 ‘브’(וְ) 단 한 글자뿐이었다.

구약성경 전체에서 ‘찾다’와 ‘살다’라는 두 동사가 한 절 안에서 만나는 일곱 구절 가운데, 두 동사가 모두 명령형으로 나란히 서 있는 곳은 아모스 5장 4절과 6절 단 두 곳뿐이다. 주님은 “네가 나를 찾는 조건을 다 채우면 그때 가서 살게 해 주겠다”라고 조건부 계약서를 내미신 것이 아니라, “나를 찾으라, 그리고 살라!”라고 두 줄의 분부를 동시에 내리셨다. 생각건대 우리 일상에서 두 개의 명령이 ‘그리고’로 나란히 이어질 때, 둘째 명령은 첫째 명령이 끝난 뒤 한참을 기다려 받는 보수가 아니다. 진료실 의사가 환자에게 “이 약을 드십시오, 그리고 푹 주무십시오”라고 말할 때나, 식탁 앞에서 부모가 아이에게 “손 씻어라, 그리고 밥 먹어라”라고 할 때, 또 재활 병동에서 “보조기를 착용하십시오, 그리고 걸으십시오”라고 할 때, 뒤따르는 명령은 앞선 명령과 한 호흡으로 지금 당장 시작해야 할 삶의 동작이다. 세무사인 내가 처음 가게를 여는 개업 사업자와 마주 앉아 “사업자 등록을 하십시오, 그리고 영업하십시오”라고 안내할 때도 마찬가지다. 영업은 사업자 등록증을 받은 대가로 주어지는 포상이 아니라 등록과 함께 즉시 착수해야 할 본업이다. 다만 세무 실무의 ‘등록 후 영업’에는 기한 내 미등록 가산세 같은 엄격한 법적 요건이나 세법의 세부 규정이 따라붙지만, 아모스 5장의 “나를 찾으라, 그리고 살라”에는 사전 자격 요건도, 무엇을 어떻게 성취하며 살라는 세부 조항도 적혀 있지 않다는 결정적인 차이가 있다.

그렇다면 왜 주님은 아무런 세부 규정도 적어 두지 않으신 채 “살라”는 명령을 “나를 찾으라”는 명령 바로 옆에 나란히 놓으셨을까. 그 물음을 안고 나는 서재 방 한가운데로 걸어 나와 아모스 5장 5절과 6절을 몸으로 읽어 보았다. 정면을 주님을 향한 자리로 삼고 오른쪽을 벧엘, 왼쪽을 길갈, 뒤쪽을 브엘세바로 정해 둔 뒤, 5절의 “벧엘을 찾지 말며 길갈로 들어가지 말며 브엘세바로도 나아가지 말라”를 천천히 읊조리며 각 지명이 나올 때마다 그쪽을 향해 몸을 반쯤 기울였다가 발바닥이 바닥에서 떨어지기 직전에 멈추어 섰다. 익숙하게 의지하던 종교적 안식처와 옛 영광의 자리로 쏠리던 몸의 무게중심을 발을 떼기 직전에 멈추어 세우는 일은 생각보다 팽팽한 긴장을 요구했다. 세 번의 멈춤 끝에 다시 정면으로 몸을 돌려 세우고, 6절의 “여호와를 찾으라”에서 고개를 똑바로 든 채 “그리고 살라”에서 가슴 깊은 곳까지 숨을 들이쉬었다가 길게 내쉬어 보았다. 그 순간 내 허파를 채웠다 빠져나가는 따뜻한 날숨이 내게 조용히 말을 걸어왔다. 숨은 고개를 든 대가로 지급받는 상급이 아니었다. 주님을 향해 고개를 든 사람이 “살라”는 분부를 받아 의식하며 내쉬는 그 한 번의 호흡 자체가 이미 주님 앞에서 시작된 거룩한 생명의 동작이었다.

이 몸의 회전 앞에서 나는 문법 구조보다 더 무서운 것이 첫째 명령의 ‘목적어’ 자리라는 사실을 깨닫는다. 만약 두 명령이 나란히 선 문법 틀만 그대로 남겨 둔 채 첫째 명령의 목적어를 슬쩍 바꾸어 “벧엘을 찾으라, 그리고 살라”라고 적는다면 어떻게 될까. 문장 구조는 아모스 5장 4절과 똑같지만, 그것은 본문 5절이 부정어와 지시형 동사를 동원해 “벧엘을 찾지 말라”(‘베알-티드레슈 베트엘’)고 가장 엄하게 금지한 죽음의 문장이 되고 만다. 당시 북이스라엘 백성들에게 부족했던 것은 종교적 열심이 아니었다. 그들은 누구보다 부지런히 벧엘의 제단을 찾고 길갈의 모임으로 몰려갔지만, 정작 하나님 자신이 아니라 성소라는 장소와 예배라는 형식, 내가 쌓아 올린 종교적 업적을 찾음의 목적어로 삼았다. 예수께서도 성경을 부지런히 상고하면서 정작 영생을 얻기 위하여 주님 자신에게 오기를 원하지 않는 자들을 향해 탄식하셨다(요 5:39–40). 둘째 명령 “살라”에 아무런 세부 행동 수칙이 적혀 있지 않을 때 우리가 또 다른 율법의 체크리스트를 만들어 내지 않으려면, 언제나 첫째 명령의 목적어이신 ‘나를’, 곧 살아 계신 인격이신 여호와 자신을 향한 자리로 돌아가야 한다.

장 칼뱅이 『기독교강요』 제3권에서 그리스도와 연합한 신자가 누리는 ‘이중 은혜(duplex gratia)’를 설명하며, 하나님 앞에 의롭다 함을 얻는 은혜와 거룩하게 살아내는 새 생명의 은혜를 태양의 빛과 열처럼 결코 떼어 놓을 수 없으되 하나를 다른 하나의 값을 치르는 조건으로 삼을 수 없다고 말한 이치도 바로 여기에 맞닿아 있다. 더욱이 아모스 5장이 이 두 줄의 명령을 선포하는 배경은 평온한 강단이 아니라 “처녀 이스라엘이 엎드러졌음이여 다시 일어나지 못하리로다”(5:2)라는 절망적인 애가의 한복판이다. 스스로 일어설 기력조차 잃어버린 그 죽음의 자리에서 “나를 찾으라, 그리고 살라”고 명하실 수 있는 까닭은, 그 명령을 내리시는 분이 사망과 음부의 열쇠를 쥐고 세세토록 살아 계신 주님(계 1:18)이시기 때문이다. 그러므로 주님의 입에서 나오는 “살라”(‘비흐유’)는 장차 조건이 충족되면 생존하게 될 것이라는 미래의 조건부 예측이 아니라, 말씀이 들려오는 지금 이 순간 쓰러진 자의 호흡을 다시 시작하게 만드는 창조적이고 수행적인 발화다.

이 문법의 전환은 내가 낮마다 마주하는 세무 상담실의 풍경을 전혀 다른 눈으로 보게 만든다. 아모스 5장 3절은 성읍에서 천 명이 나가던 곳에 백 명만 남고, 백 명이 나가던 곳에 열 명만 남는 참담한 현실을 에둘러 포장하지 않고 숫자 그대로 기록한다. 매출이 급감하고 거래처가 끊겨 폐업 위기에 몰린 사업자가 구겨진 영수증 뭉치를 들고 내 사무실을 찾아와 “세무사님, 지금이라도 밀린 장부를 제대로 정리하면 다시 살아날 수 있겠습니까?”라고 떨리는 목소리로 물을 때가 있다. 그때 내 입 끝까지 차오르는 가장 손쉬운 대답은 “그럼요, 지금이라도 장부를 깨끗이 정리하면 반드시 길이 열릴 것입니다”라는 조건문이다. 그러나 그런 섣부른 조건부 낙관은 당장 다음 달에 매출이 오르지 않거나 끝내 가게를 접어야 하는 냉혹한 숫자와 부딪히는 순간, 정직하게 장부를 정리한 그 수고마저 아무 소용없는 실패로 만들어 사람을 두 번 무너뜨린다. 아모스 5장의 문법을 배운 뒤로 나는 상담실 책상 위에서 ‘그러면’이라는 단어를 삼킨다. 줄어든 매출과 냉정한 세무 수치는 3절 말씀처럼 가감 없이 정직하게 마주하되, 그의 눈을 바라보며 두 줄의 문장을 나란히 건넨다. “사장님, 오늘 장부를 정직하게 정리하십시오. 그리고 내일 아침 가게 문을 여십시오.” 장부를 바르게 정리하는 일은 내일의 대박을 사기 위한 부적이 아니라 오늘 주님과 자기 양심 앞에 마땅히 서야 할 정직의 자리이고, 내일 아침 문을 여는 일은 매출이 보장된 뒤에야 받는 상급이 아니라 오늘 호흡이 붙어 있는 생활인이 감당해야 할 존귀한 분부이기 때문이다.

이 부르심은 교회 행정을 돌보고 설교와 공지 문안을 다듬는 목회자로서의 내 언어 습관도 아프게 돌아보게 한다. 나는 그동안 주보의 예배 안내문이나 교인들에게 보내는 집회 공지 문안을 작성할 때마다 얼마나 자주 “이번 특별새벽기도회에 빠짐없이 나오시면 큰 은혜와 응답을 받습니다”, “이 수련회에 참석하면 가정과 일터에 회복이 일어납니다” 같은 조건문을 써 왔던가. 교인들의 발걸음을 독려하려는 선한 의도였다고 변명해 보지만, 그 문장 속에는 주님 자신이 아니라 ‘새벽기도회’나 ‘집회’라는 장소와 프로그램을 찾음의 목적어로 세우는 위험한 대치가 숨어 있었다. 조건문으로 쓰인 공지는 개근한 사람에게는 마땅히 보상을 요구할 자격을 얻었다는 도덕주의적 우월감을 심어 주고, 삶의 무거운 형편 때문에 자리에 나오지 못한 성도에게는 은혜에서 탈락했다는 깊은 정죄감을 안겨 준다. 이제 나는 공지 문안의 ‘나오시면’과 ‘받습니다’를 지우고 그 자리에 ‘그리고’를 적어 넣는다. “성도 여러분, 장소가 아니라 주님 자신을 찾읍시다. 그리고 이번 한 주간도 각자의 일터와 가정에서 그분 앞에 살아냅시다. 이번 새벽기도회는 그 부르심에 함께 응답하는 자리입니다.” 그렇게 문장을 고쳐 쓸 때, 모든 성도는 예배당 안팎의 모든 공간에서 신앙과 일상을 완벽하게 일치시키며 참된 그리스도인의 사명을 온전히 완수하게 된다.

아침마다 서재 책상에 앉아 하루의 일정을 적는 다이어리를 펼칠 때에도 나는 예전의 습관을 내려놓는다. 전에는 빼곡한 세무 신고 일정과 심방 목록 아래에 “이 일들을 다 끝내면 저녁에는 편히 쉬고 기뻐하겠다”라고 조건부 보상 계획표를 적어 두곤 했다. 그러나 해야 할 일은 좀처럼 끝나지 않았고, 내 삶과 기쁨은 늘 내일로 미루어졌다. 이제 나는 다이어리 맨 윗줄에 똑같은 크기와 높이로 두 줄의 문장을 나란히 적어 넣는다. 첫째 줄에는 “오늘도 벧엘이 아니라 살아 계신 주님 자신을 찾는다”라고 적고, 둘째 줄에는 “그리고 주님께서 허락하신 오늘 하루를 숨 쉬며 살아낸다”라고 적는다. 주님을 찾는 일과 오늘을 살아내는 일 사이에는 어떤 조건의 칸막이도 없다. 살아내는 일은 주님을 찾은 대가로 나중에 지급받는 보수가 아니라, 지금 나를 부르시는 주님께로부터 받은 똑같이 거룩한 분부다. 우리가 성경 여백과 일터의 장부, 그리고 매일의 삶에서 조건의 계산식을 완전히 버리고 주님의 명령에 절대적으로 순종할 때, 우리의 모든 날은 마침내 흔들리지 않는 생명의 기적으로 가득 차게 될 것이다.
"""
        amos5_draft1_path = Path(workspace_root) / "20261110_살아내는_일도_주님께로부터_받은_거룩한_분부입니다_아모스_5_1-6_초고1.md"
        amos5_draft1_path.write_text(amos5_draft1_md, encoding="utf-8")

        amos5_final_md = """---
title: "살아내는 일도 주님께로부터 받은 거룩한 분부입니다 — ‘그리하면’의 거래 장부를 덮고 ‘그리고’의 호흡으로 읽는 아모스 5장 (ican-write 5단계 다회차 완성본)"
date: 2026-11-10
tags: [아모스5장, 디르슈니비흐유, 두줄의명령, 이중은혜, 세무상담실, 인격만들기, ican-write, 성찰에세이]
---

# 살아내는 일도 주님께로부터 받은 거룩한 분부입니다 — ‘그리하면’의 거래 장부를 덮고 ‘그리고’의 호흡으로 읽는 아모스 5장

새벽녘 책상 스탠드를 켜고 오래 손때 묻은 개역한글 성경을 펼치면, 아모스 5장 4절과 6절의 “너희는 나를 찾으라 그리하면 살리라”, “너희는 여호와를 찾으라 그리하면 살리라”라는 구절 아래에 예전에 그어 둔 연필 밑줄이 눈에 들어온다. 나는 오랫동안 그 문장 한가운데 자리 잡은 ‘그리하면’이라는 네 글자에 내 신앙의 무게중심을 실어 두곤 했다. 정해 둔 성경 장수를 채우고 새벽 무릎의 시간을 값으로 꼬박꼬박 치르면, 그 대가로 언젠가 내 삶이 풀리고 숨통이 트이는 ‘살리라’의 보상이 지급될 것처럼 은밀한 거래의 장부를 펴 놓고 있었던 셈이다. 그렇게 읽는 동안 주님을 찾는 일은 오늘 내가 치러야 할 고단한 의무가 되었고, 정작 살아내는 일은 모든 문제가 해결된 뒤에야 비로소 누릴 수 있는 미래의 상급으로 아득히 유예되어 있었다. 그런데 히브리어 원문을 한 단어씩 소리 내어 짚어 읽던 어느 새벽, 내 손끝이 4절의 ‘디르슈니 비흐유’(나를 찾으라, 그리고 살라)와 6절의 ‘디르슈 에트-여호와 비흐유’(여호와를 찾으라, 그리고 살라) 앞에서 우뚝 멈추어 섰다. 아모스 5장 1절부터 6절까지 일흔아홉 단어, 백다섯 개의 형태소를 아무리 뒤져 보아도 우리말 번역이 보태 놓은 ‘그리하면’이라는 조건 표지는 단 한 개도 없었다. 거기에는 오직 ‘찾으라’(‘다라시’)와 ‘살라’(‘하야’)라는 두 동사가 똑같은 칼 명령형 2인칭 남성 복수의 굵기로 나란히 서 있었고, 그 둘 사이를 잇는 것은 ‘그리고’를 뜻하는 접속사 ‘브’(וְ) 단 한 글자뿐이었다. 손톱만 한 그 글자 하나 앞에서, 내가 오랫동안 주님 앞에 펴 놓았던 조건부 거래 장부가 소리 없이 덮이고 있었다.

구약성경 전체에서 ‘찾다’와 ‘살다’라는 두 동사가 한 절 안에서 만나는 일곱 구절 가운데, 두 동사가 모두 명령형으로 나란히 서 있는 곳은 아모스 5장 4절과 6절 단 두 곳뿐이다. 주님은 “네가 나를 찾는 조건을 다 채우면 그때 가서 살게 해 주겠다”라고 조건부 계약서를 내미신 것이 아니라, “나를 찾으라, 그리고 살라!”라고 두 줄의 분부를 동시에 내리셨다. 생각건대 우리 일상에서 두 개의 명령이 ‘그리고’로 나란히 이어질 때, 둘째 명령은 첫째 명령이 끝난 뒤 한참을 기다려 받는 보수가 아니다. 진료실 의사가 환자에게 “이 약을 드십시오, 그리고 푹 주무십시오”라고 말할 때나, 식탁 앞에서 부모가 아이에게 “손 씻어라, 그리고 밥 먹어라”라고 할 때, 또 재활 병동에서 “보조기를 착용하십시오, 그리고 걸으십시오”라고 할 때, 뒤따르는 명령은 앞선 명령과 한 호흡으로 지금 당장 시작해야 할 삶의 동작이다. 세무사인 내가 처음 가게를 여는 개업 사업자와 마주 앉아 “사업자 등록을 하십시오, 그리고 영업하십시오”라고 안내할 때도 마찬가지다. 영업은 사업자 등록증을 받은 대가로 주어지는 포상이 아니라 등록과 함께 즉시 착수해야 할 본업이다. 다만 세무 실무의 ‘등록 후 영업’에는 기한 내 미등록 가산세 같은 엄격한 법적 요건이나 세법의 세부 규정이 따라붙지만, 아모스 5장의 “나를 찾으라, 그리고 살라”에는 사전 자격 요건도, 무엇을 어떻게 성취하며 살라는 세부 조항도 적혀 있지 않다는 결정적인 차이가 있다.

그렇다면 왜 주님은 아무런 세부 규정도 적어 두지 않으신 채 “살라”는 명령을 “나를 찾으라”는 명령 바로 옆에 나란히 놓으셨을까. 그 물음을 안고 나는 서재 방 한가운데로 걸어 나와 아모스 5장 5절과 6절을 몸으로 읽어 보았다. 정면을 주님을 향한 자리로 삼고 오른쪽을 벧엘, 왼쪽을 길갈, 뒤쪽을 브엘세바로 정해 둔 뒤, 5절의 “벧엘을 찾지 말며 길갈로 들어가지 말며 브엘세바로도 나아가지 말라”를 천천히 읊조리며 각 지명이 나올 때마다 그쪽을 향해 몸을 반쯤 기울였다가 발바닥이 바닥에서 떨어지기 직전에 멈추어 섰다. 익숙하게 의지하던 종교적 안식처와 옛 영광의 자리로 쏠리던 몸의 무게중심을 발을 떼기 직전에 멈추어 세우는 일은 생각보다 팽팽한 긴장을 요구했다. 세 번의 멈춤 끝에 다시 정면으로 몸을 돌려 세우고, 6절의 “여호와를 찾으라”에서 고개를 똑바로 든 채 “그리고 살라”에서 가슴 깊은 곳까지 숨을 들이쉬었다가 길게 내쉬어 보았다. 그 순간 내 허파를 채웠다 빠져나가는 따뜻한 날숨이 내게 조용히 말을 걸어왔다. 숨은 고개를 든 대가로 지급받는 상급이 아니었다. 주님을 향해 고개를 든 사람이 “살라”는 분부를 받아 의식하며 내쉬는 그 한 번의 호흡 자체가 이미 주님 앞에서 시작된 거룩한 생명의 동작이었다.

이 몸의 회전 앞에서 나는 문법 구조보다 더 무서운 것이 첫째 명령의 ‘목적어’ 자리라는 사실을 깨닫는다. 만약 두 명령이 나란히 선 문법 틀만 그대로 남겨 둔 채 첫째 명령의 목적어를 슬쩍 바꾸어 “벧엘을 찾으라, 그리고 살라”라고 적는다면 어떻게 될까. 문장 구조는 아모스 5장 4절과 똑같지만, 그것은 본문 5절이 부정어와 지시형 동사를 동원해 “벧엘을 찾지 말라”(‘베알-티드레슈 베트엘’)고 가장 엄하게 금지한 죽음의 문장이 되고 만다. 당시 북이스라엘 백성들에게 부족했던 것은 종교적 열심이 아니었다. 그들은 누구보다 부지런히 벧엘의 제단을 찾고 길갈의 모임으로 몰려갔지만, 정작 하나님 자신이 아니라 성소라는 장소와 예배의 횟수, 내가 채운 출석 도장과 종교적 이력을 찾음의 목적어로 삼았다. 예수께서도 성경을 부지런히 상고하면서 정작 영생을 얻기 위하여 주님 자신에게 오기를 원하지 않는 자들을 향해 탄식하셨다(요 5:39–40). 둘째 명령 “살라”에 아무런 세부 행동 수칙이 적혀 있지 않을 때 우리가 또 다른 율법의 체크리스트를 만들어 내지 않으려면, 언제나 첫째 명령의 목적어이신 ‘나를’, 곧 살아 계신 인격이신 여호와 자신을 향한 자리로 돌아가야 한다.

장 칼뱅이 『기독교강요』 제3권에서 그리스도와 연합한 신자가 누리는 ‘이중 은혜(duplex gratia)’를 설명하며, 하나님 앞에 의롭다 함을 얻는 은혜와 거룩하게 살아내는 새 생명의 은혜를 태양의 빛과 열처럼 결코 떼어 놓을 수 없으되 하나를 다른 하나의 값을 치르는 조건으로 삼을 수 없다고 말한 이치도 바로 여기에 맞닿아 있다. 더욱이 아모스 5장이 이 두 줄의 명령을 선포하는 배경은 평온한 강단이 아니라 “처녀 이스라엘이 엎드러졌음이여 다시 일어나지 못하리로다”(5:2)라는 절망적인 애가의 한복판이다. 스스로 일어설 기력조차 잃어버린 그 죽음의 자리에서 “나를 찾으라, 그리고 살라”고 명하실 수 있는 까닭은, 그 명령을 내리시는 분이 사망과 음부의 열쇠를 쥐고 세세토록 살아 계신 주님(계 1:18)이시기 때문이다. 그러므로 주님의 입에서 나오는 “살라”(‘비흐유’)는 장차 조건이 충족되면 생존하게 될 것이라는 미래의 조건부 예측이 아니라, 말씀이 들려오는 지금 이 순간 쓰러진 자의 멈춘 가슴에 다시 첫 숨을 불어넣어 일으켜 세우시는 주님의 살려 내는 분부다.

이 문법의 전환은 내가 낮마다 마주하는 세무 상담실의 풍경을 전혀 다른 눈으로 보게 만든다. 아모스 5장 3절은 성읍에서 천 명이 나가던 곳에 백 명만 남고, 백 명이 나가던 곳에 열 명만 남는 참담한 현실을 에둘러 포장하지 않고 숫자 그대로 기록한다. 매출이 급감하고 거래처가 끊겨 폐업 위기에 몰린 사업자가 구겨진 영수증 뭉치를 들고 내 사무실을 찾아와 “세무사님, 지금이라도 밀린 장부를 제대로 정리하면 다시 살아날 수 있겠습니까?”라고 떨리는 목소리로 물을 때가 있다. 그때 내 입 끝까지 차오르는 가장 손쉬운 대답은 “그럼요, 지금이라도 장부를 깨끗이 정리하면 반드시 길이 열릴 것입니다”라는 조건문이다. 그러나 그런 섣부른 조건부 낙관은 당장 다음 달에 매출이 오르지 않거나 끝내 가게를 접어야 하는 냉혹한 숫자와 부딪히는 순간, 정직하게 장부를 정리한 그 수고마저 아무 소용없는 실패로 만들어 사람을 두 번 무너뜨린다. 아모스 5장의 문법을 배운 뒤로 나는 상담실 책상 위에서 ‘그러면’이라는 단어를 삼킨다. 줄어든 매출과 냉정한 세무 수치는 3절 말씀처럼 가감 없이 정직하게 마주하되, 그의 눈을 바라보며 두 줄의 문장을 나란히 건넨다. “사장님, 오늘 장부를 정직하게 정리하십시오. 그리고 내일 아침 가게 문을 여십시오.” 장부를 바르게 정리하는 일은 내일의 대박을 사기 위한 부적이 아니라 오늘 주님과 자기 양심 앞에 마땅히 서야 할 정직의 자리이고, 내일 아침 문을 여는 일은 매출이 보장된 뒤에야 받는 상급이 아니라 오늘 호흡이 붙어 있는 생활인이 감당해야 할 존귀한 분부이기 때문이다.

이 부르심은 교회 행정을 돌보고 설교와 공지 문안을 다듬는 목회자로서의 내 언어 습관도 아프게 돌아보게 한다. 나는 그동안 주보의 예배 안내문이나 교인들에게 보내는 집회 공지 문안을 작성할 때마다 얼마나 자주 “이번 특별새벽기도회에 빠짐없이 나오시면 큰 은혜와 응답을 받습니다”, “이 수련회에 참석하면 가정과 일터에 회복이 일어납니다” 같은 조건문을 써 왔던가. 교인들의 발걸음을 독려하려는 선한 의도였다고 변명해 보지만, 그 문장 속에는 주님 자신이 아니라 ‘새벽기도회’나 ‘집회’라는 장소와 프로그램을 찾음의 목적어로 세우는 위험한 대치가 숨어 있었다. 조건문으로 쓰인 공지는 개근한 사람에게는 마땅히 보상을 요구할 자격을 얻었다는 도덕주의적 우월감을 심어 주고, 삶의 무거운 형편 때문에 자리에 나오지 못한 성도에게는 은혜에서 탈락했다는 깊은 정죄감을 안겨 준다. 이제 나는 공지 문안의 ‘나오시면’과 ‘받습니다’를 지우고 그 자리에 ‘그리고’를 적어 넣는다. “성도 여러분, 장소가 아니라 주님 자신을 찾읍시다. 그리고 이번 한 주간도 각자의 일터와 가정에서 그분 앞에 살아냅시다. 이번 새벽기도회는 그 부르심에 함께 응답하는 자리입니다.” 그렇게 문장을 고쳐 적어 놓고 나면, 새벽 예배당 의자에 앉은 교우의 어깨에서도, 삶의 무거운 형편 때문에 그 시각 일터와 부엌에서 아침을 여는 교우의 마음에서도 조건의 짐이 한 겹 덜어지기를 조용히 바라게 된다.

아침마다 서재 책상에 앉아 하루의 일정을 적는 다이어리를 펼칠 때에도 나는 예전의 습관을 내려놓는다. 전에는 빼곡한 세무 신고 일정과 심방 목록 아래에 “이 일들을 다 끝내면 저녁에는 편히 쉬고 기뻐하겠다”라고 조건부 보상 계획표를 적어 두곤 했다. 그러나 해야 할 일은 좀처럼 끝나지 않았고, 내 삶과 기쁨은 늘 내일로 미루어졌다. 이제 나는 다이어리 맨 윗줄에 똑같은 크기와 높이로 두 줄의 문장을 나란히 적어 넣는다. 첫째 줄에는 “오늘도 벧엘이 아니라 살아 계신 주님 자신을 찾는다”라고 적고, 둘째 줄에는 “그리고 주님께서 허락하신 오늘 하루를 숨 쉬며 살아낸다”라고 적는다. 주님을 찾는 일과 오늘을 살아내는 일 사이에는 어떤 조건의 칸막이도 없다. 살아내는 일은 주님을 찾은 대가로 나중에 지급받는 보수가 아니라, 지금 나를 부르시는 주님께로부터 받은 똑같이 거룩한 분부다. 두 줄의 문장을 나란히 적어 놓은 다이어리를 덮고 책상 스탠드 불을 끈다. 창밖으로 밝아 오는 아침 공기를 가슴 깊이 들이쉬며, 나는 오늘도 주님을 찾고, 그리고 내게 맡겨진 오늘 하루를 살아내러 방문을 연다.
"""
        amos5_final_path = Path(workspace_root) / "20261110_살아내는_일도_주님께로부터_받은_거룩한_분부입니다_아모스_5_1-6_깊은사고_에세이.md"
        amos5_final_path.write_text(amos5_final_md, encoding="utf-8")

        amos5_ingyeok_path = Path(workspace_root) / "20261110_인격만들기_에세이.md"
        amos5_ingyeok_path.write_text(amos5_final_md, encoding="utf-8")

        amos5_design_md = """---
title: "[ican-write 이원화·다회차(Round 1~3) 설계·평가 기록] 살아내는 일도 주님께로부터 받은 거룩한 분부입니다 (아모스 5:1-6)"
date: 2026-11-10
tags: [ican-write, ican-drafter, ican-evaluator, 다회차제련, 아모스5장, 디르슈니비흐유, 이중은혜, 인격만들기]
---

# [ican-write 이원화·다회차(Round 1~3) 설계·평가 기록] 살아내는 일도 주님께로부터 받은 거룩한 분부입니다 — 아모스 5:1–6

본 문서는 진행·집필 전담 에이전트(**`ican-drafter`**)와 독립 평가·선택안 결정 전담 에이전트(**`ican-evaluator`**)가 분리 운영되며, 특히 **2단계(목차), 3단계(상세설계도), 5단계(내 글화·5대 지표 퇴고)에서 단 1회에 끝내지 않고 각 3라운드(`Round 1 → Round 2 → Round 3`)에 걸쳐 평가·비평·수정을 주고받으며 원고를 벼려 낸 전 과정**을 기록한 문서입니다.

---

## [1단계] 글감 발견과 생각 확장 (`ican-drafter` 후보 도출 ⇄ `ican-evaluator` Gate 1 결정)

### 1-1. `ican-drafter` 글감 후보 3안 및 학술·성경 자료 후보 4종 제출
* **글감 후보 A안 (문법·신앙 거래 장부 성찰 중심)**: 개역한글 아모스 5:4·6의 ‘그리하면’이라는 조건의 칸을 걷어내고, 히브리어 원문이 접속사 `וְ`(브, ‘그리고’) 단 한 글자로 나란히 세운 두 개의 명령형(`디르슈니 비흐유` — 나를 찾으라, 그리고 살라!)을 마주하며 내 안의 거래 장부를 덮는 성찰.
* **글감 후보 B안 (신체 감각·찾음의 목적어 분별 중심)**: 서재 방 한가운데서 세 성소(벧엘·길갈·브엘세바)로 기울던 몸을 발을 떼기 직전에 멈추어 정면으로 돌려 세우고, 6절에서 고개를 들어 날숨을 내쉬며 문법 구조보다 무서운 것이 첫째 명령의 목적어(‘벧엘’이 아닌 ‘여호와 자신’)임을 깨닫는 성찰.
* **글감 후보 C안 (원문 문법 + 몸의 회전 + 세무·목회·다이어리 실무 통합안)**: A안의 원문 발견과 B안의 신체 호흡을 품고, 이를 폐업 위기 사업자와 마주 앉은 세무 상담실의 두 줄 권면, 교회 주보·집회 공지 문안의 수정, 아침 서재 다이어리 첫 줄의 기록으로 일관되게 관통시키는 통합 성찰.
* **학술·성경 자료 후보 4종**:
  1. **히브리어 원문 구문 분석**: 아모스 5:4·6의 `다라시`+`하야` 칼 명령형 2인칭 남성 복수 병렬, 구약 전체 7절 중 둘 다 명령형인 곳은 본문 2절뿐, 5:1–6 전체 79단어·105형태소 중 조건 표지 0개, 5:5 `베알-티드레슈 베트엘`(`אַל`+지시형) 목적어 금지.
  2. **장 칼뱅(John Calvin), 『기독교강요(1559)』 제3권 11·16장**: ‘이중 은혜(duplex gratia)’ — 칭의와 성화의 불가분리성 및 비조건성.
  3. **존 오스틴(J. L. Austin), 『화행론(1962)』**: ‘수행적 발화(Performative Utterance)’ — 미래 조건부 예측이 아니라 발화 순간 생명의 호흡을 개시하게 하는 명령.
  4. **요한복음 5:39–40 & 요한계시록 1:18**: 성소와 문자를 넘어 찾음의 유일한 목적어이신 주님과, 애가의 자리(암 5:2)에서 “살라”고 명하시는 살아 계신 그리스도.

### 1-2. `ican-evaluator` [Gate 1] 비교 심사 및 최종 선택 결정
* **글감 심사 판정**:
  * **A안·B안 단독 채택 보류**: A안만으로는 생활 현장의 구체적 변화가 약하고, B안만으로는 원문 문법 발견의 충격파가 반감됨.
  * **최종 채택 (글감 C안 통합형)**: 새벽 서재의 원문 발견(`וְ` 한 글자와 두 명령형) → 방 한가운데서 세 성소로 기울던 발을 멈추고 쉬는 숨 → 세무 상담실·목회 공지·아침 다이어리로 이어지는 C안을 최종 채택.
* **학술·성경 자료 4종 노출 수위 결정**:
  * **히브리어 구문 분석 & 요 5:39–40 · 계 1:18**: 전면 채택.
  * **장 칼뱅 『기독교강요』 3권 ‘이중 은혜’**: 채택하되 교리사 강의처럼 길어지지 않도록 ‘태양의 빛과 열’ 비유를 중심으로 1문장 내에 녹여낼 것.
  * **존 오스틴 『화행론』 ‘수행적 발화’**: **조건부 채택 (학자명·전문용어 직접 노출 금지)** — 에세이 본문에 ‘존 오스틴’이나 ‘수행적 발화’라는 번역투 학술 개념어를 날것으로 노출하면 문학적 감응이 식으므로, 설계도 밑바탕에만 두고 본문에서는 ‘멈춘 가슴에 다시 첫 숨을 불어넣는 살려 내는 분부’ 등 우리말 고유 감각으로 치환할 것.

---

## [2단계] 핵심 메시지 정립과 독자 중심 목차 설계 (3라운드 반복 제련: `v1 → v2 → v3`)

### [Round 1] 초기 목차(`v1`) 도출 및 `ican-evaluator` 1차 심사 (독자 반문 및 유추의 한계선 지적)
* **`ican-drafter` 초기 제출안(`v1`)**: 목차 A안(구문·교리·적용 순차형) vs 목차 B안(삶의 탄식·몸의 감각·실무 통합 서사형).
* **`ican-evaluator` [Gate 2 - Round 1 심사 지시]**:
  1. **기본 틀**: 새벽 성경 밑줄의 탄식에서 출발해 몸의 회전과 세무·목회 실무로 흘러가는 **목차 B안**을 기본 틀로 선택함.
  2. **[결함 1 — 독자의 잠재적 반문 누락]**: 독자가 “‘살리라’라는 약속이 아니라 ‘살라’라는 명령이라면, 가뜩이나 버거운 삶이 또 하나의 무거운 의무가 되는 것 아닌가?”라고 되물을 수 있음. 이를 풀어 줄 징검다리를 보강할 것.
  3. **[결함 2 — 세무 실무 유추의 한계선 미비]**: “사업자 등록을 하십시오, 그리고 영업하십시오”라는 유추에는 ‘미등록 가산세’ 같은 법적 요건이 따르지만, 아모스 5장의 두 명령에는 자격 요건도 세부 행동 수칙도 없다는 **‘유추가 깨지는 결정적 차이’**를 명시할 것.

### [Round 2] 수정 목차(`v2`) 제출 및 `ican-evaluator` 2차 심사 (목차 3대 속성 정밀 조율)
* **`ican-drafter` 수정 제출안(`v2`)**: 세무 실무 유추의 한계선(‘세부 조항 없는 명령’)과 서재 방 한가운데에서의 날숨 체험을 연결한 수정 2단 목차 제출.
* **`ican-evaluator` [Gate 2 - Round 2 심사 지시]**:
  1. **[연결성 보완 — 2장과 3장 사이]**: 몸을 멈추어 정면으로 돌아선 자리에서 발견한 것이 바로 **‘문법 구조보다 무서운 첫째 명령의 목적어(벧엘이 아닌 여호와 자신)’**임을 밝혀 인과 고리를 조일 것.
  2. **[논리성·설득성 보완 — 4장 내 세 현장의 점층 배치]**: 세무 상담실·교회 공지·아침 다이어리가 평면적 나열로 읽히지 않도록 **‘타인의 무너진 장부 앞(세무 상담실) → 공동체를 부르는 문장 앞(목회 공지) → 내 하루를 여는 첫 줄 앞(서재 다이어리)’**으로 바깥 일터에서 자기 내면으로 좁혀 들어오는 점층 순서를 확립할 것.

### [Round 3] 최종 목차(`v3`) 확정 및 Gate 2 최종 승인
* **확정 제목**: **`살아내는 일도 주님께로부터 받은 거룩한 분부입니다 — ‘그리하면’의 거래 장부를 덮고 ‘그리고’의 호흡으로 읽는 아모스 5장`**
* **확정 2단 목차 (`v3`, 4장 12절 — 본문 8문단 매핑)**:
  * **제1장. ‘그리하면’이라는 거래의 칸이 없는 두 줄의 명령** (1-1. 성경 여백에 그어 둔 줄과 오래된 거래 장부 / 1-2. 구약 전체에서 단 두 번뿐인 나란한 명령형과 접속사 `וְ` 한 글자 / 1-3. 의사·부모·세무사·재활 병동의 두 명령과 아모스 5장의 결정적 차이)
  * **제2장. 발을 떼기 직전에 멈추어 돌아서는 몸의 호흡과 찾음의 목적어** (2-1. 방 한가운데서 세 성소로 기울던 몸을 멈추어 세우다 / 2-2. 고개를 들고 내쉬는 깊고 긴 숨과 “벧엘을 찾으라, 그리고 살라”의 위험성 / 2-3. 첫째 명령의 목적어이신 ‘나를, 곧 여호와를’)
  * **제3장. 엎드러진 애가의 자리에서 생명을 개시하는 주님의 목소리** (3-1. 칼뱅의 ‘이중 은혜’와 떼어 놓을 수 없는 두 부르심 / 3-2. 처녀 이스라엘이 엎드러졌다는 애가(5:2)와 살아 계신 분(계 1:18)의 살려 내는 분부 / 3-3. 천 명이 나가 백 명만 남는 현실(5:3)과 세무 상담실의 떨리는 질문)
  * **제4장. ‘그러면’을 ‘그리고’로 고쳐 쓰는 세무 상담실·목회 공지·아침 다이어리** (4-1. 세무 상담실에서 건네는 조건 없는 두 줄의 분부 / 4-2. 교회 행정과 목회 공지 문안의 성찰 / 4-3. 내 아침 다이어리 맨 윗줄의 두 문장과 오늘을 살아내는 숨결)

---

## [3단계] A4 상세설계도와 재료 보강 (3라운드 반복 제련: `v1 → v2 → v3`)

### [Round 1] 초기 상세설계도(`v1`) 심사 및 3곳 재료 보강 지시
* **`ican-evaluator` [Gate 3 - Round 1 심사 지시]**:
  1. **[보강 1 — 1~2문단 원문 계량 수치 명시]**: 아모스 5:1–6 전체 **79단어·105형태소 중 조건 표지가 0개**라는 점과, 구약 전체에서 `다라시`와 `하야`가 한 절에서 만나는 **7구절 중 두 동사 모두 명령형인 곳은 5:4·6 단 2구절뿐**이라는 정확한 수치를 제시할 것.
  2. **[보강 2 — 3~4문단 신체 프로토콜 및 부정 명령 대조 구체화]**: 방 한가운데서 수행한 동작을 **정면(주님)·오른쪽(벧엘)·왼쪽(길갈)·뒤쪽(브엘세바)**의 공간 배치와 **‘발바닥이 바닥에서 떨어지기 직전 멈추어 서는 긴장’**으로 세밀화하고, 4문단에서 `베알-티드레슈 베트엘`(강한 금지) 및 요 5:39–40과 직접 연결할 것.
  3. **[보강 3 — 5~6문단 애가(5:2) 및 10% 잔존율(5:3)과 폐업 위기 상담실 결합]**: 아모스 5:2의 애가와 5:3의 냉혹한 숫자(1,000명→100명, 100명→10명)를 구겨진 영수증 뭉치를 들고 세무 상담실을 찾아온 폐업 위기 사업자의 현실과 정면으로 포갤 것.

### [Round 2] 재료 보강안(`v2`) 전후 비교 심사 및 과잉 이론 절제 지시
* **`ican-evaluator` [Gate 3 - Round 2 심사 지시]**:
  1. **[절제 1 — 히브리어 문법 분류어 및 화행론 용어 압축]**: `v2` 설계도에 히브리어 접속사 바브의 세분화된 문법 용어와 오스틴 화행론의 학술 설명이 불어나 서재의 성찰적 어조를 방해함. 문법 설명은 ‘칼 명령형 2인칭 남성 복수’와 ‘접속사 `וְ`(브) 한 글자’로만 남기고 화행론 학술 용어는 덜어낼 것.
  2. **[절제 2 — 칼뱅 『기독교강요』 인용의 체화]**: 제3권 11·16장 설명이 신학 각주처럼 분리되지 않도록 ‘태양의 빛과 열’ 비유 한 줄로 응축하여 아모스 5:2 및 요한계시록 1:18과 한 호흡으로 이어지게 할 것.

### [Round 3] 최종 상세설계도(`v3`) 및 A4 3개 지면 연동 컷 일러스트 최종 승인
* **Page 001 확정 컷 (`amos5_two_imperatives_vav`)**: ‘그리하면’이라는 거래의 칸을 지우고 접속사 `וְ`(그리고) 한 글자로 나란히 선 두 줄의 명령(`דִּרְשׁוּנִי וִחְיוּ`)
* **Page 002 확정 컷 (`amos5_turn_from_bethel_breathe`)**: 세 성소(벧엘·길갈·브엘세바)로 기울던 발을 멈추어 정면의 여호와께 고개를 들고 내쉬는 생명의 호흡
* **Page 003 확정 컷 (`amos5_counseling_and_diary_two_lines`)**: 세무 상담실·목회 공지·아침 다이어리에서 ‘그러면’을 지우고 ‘그리고’로 나란히 적는 두 줄의 분부

---

## [4단계 & 5단계] `ican-evaluator` Gate 4 정밀 진단 및 Gate 5 3라운드(`초고 1 → v1 → v2 → v3`) 변증법적 퇴고 대조표

### 1. Gate 4 (`초고 1` 정밀 진단) & Gate 5 Round 1 역점검 (1차 퇴고안 `v1`에 새로 유입된 AI 미사여구 적발)
* **Gate 4 진단**: `ican-drafter`의 `초고 1`(2,250자)에서 **`(독자)` 메모 3곳**(1문단 `경건의 시간` 상투적 범주어, 4문단 `종교적 업적` 추상어, 5문단 말미 `창조적이고 수행적인 발화다`라는 번역투 학술어)과 **`(내 마음)` 메모 3곳**(1문단 말미 문법 발견 직후의 내면 호흡 누락, 7문단 말미 `모든 성도는... 완벽하게 일치시키며... 온전히 완수하게 된다`라는 전칭 과장 클리셰, 8문단 결미 `조건의 계산식을 완전히 버리고 주님의 명령에 절대적으로 순종할 때, 우리의 모든 날은 마침내 흔들리지 않는 생명의 기적으로 가득 차게 될 것이다`라는 **본문 스스로가 금기시한 조건문 클리셰로의 치명적 미끄러짐**)을 적시하여 1차 퇴고를 지시함.
* **Gate 5 - Round 1 역점검**: `1차 퇴고안(v1)`을 재심사한 결과, 기존 결함은 제거되었으나 **교정 과정에서 새로 끼어든 신파적 감정 과장·추상 한자어·교계 상투어 4곳**을 적발하여 2차 재수정을 지시함:
  1. **1문단 말미(`v1`) 적발**: `가슴을 치는 뜨거운 눈물이 하염없이 쏟아졌다` → 없는 눈물 창작 삭제, 오랜 거래 장부가 소리 없이 덮이던 고요한 내면의 감각으로 절제 지시.
  2. **5문단 말미(`v1`) 적발**: `초월적 생명력의 선언이자 창조적 사건이다` → 새로 유입된 추상 한자어 삭제, 쓰러진 자의 멈춘 가슴에 다시 첫 숨을 불어넣는 **‘주님의 살려 내는 분부다’**로 복원 지시.
  3. **7문단 말미(`v1`) 적발**: `진정한 공동체적 영성의 회복과 일상의 성화를 깊이 경험하게 된다` → 교계 상투어 삭제, 새벽 예배당 의자에 앉은 교우와 일터·부엌에서 아침을 여는 교우의 어깨에서 조건의 짐이 덜어지기를 바라는 목회자의 진심으로 복원 지시.
  4. **8문단 결미(`v1`) 적발**: `놀라운 평강과 생명의 은총이 영원한 찬송처럼 울려 퍼진다` → 감상적 미사여구 삭제, 다이어리를 덮고 책상 스탠드 불을 끄고 방문을 여는 구체적 첫 동작과 수미상관으로 복원 지시.

### 2. 구절별 3단(`초고 1` → `1차 퇴고안 v1` → `최종 승인본 v2/v3`) 변증법적 퇴고 대조표

| 점검 구간 | 4단계 `초고 1` (진단 전) | Gate 5 `1차 퇴고안(v1)` (1차 교정 및 역점검 대상) | Gate 5 `최종 승인 완성본(v2/v3)` (내 표현 완전 복원) |
| :--- | :--- | :--- | :--- |
| **1문단 중반·말미**<br>`(독자 #1)`<br>`(내 마음 #1)`<br>`[Round 1 역점검]` | 주님을 찾는 <u>경건의 시간</u>을 값으로 꼬박꼬박 치르면 (...) 그 둘 사이를 잇는 것은 ‘그리고’를 뜻하는 접속사 ‘브’(וְ) 단 한 글자뿐이었다. <u>*(내면 호흡 누락)*</u> | 정해 둔 성경 장수를 넘기고 새벽 기도 시간을 값으로 꼬박꼬박 치르면 (...) 그 작은 글자 하나가 들어오는 순간 <u>가슴을 치는 뜨거운 눈물이 하염없이 쏟아졌다.</u> *(신파적 감정 과장 적발)* | **정해 둔 성경 장수를 채우고 새벽 무릎의 시간을 값으로 꼬박꼬박 치르면** (...) 그 둘 사이를 잇는 것은 ‘그리고’를 뜻하는 접속사 ‘브’(וְ) 단 한 글자뿐이었다. **손톱만 한 그 글자 하나 앞에서, 내가 오랫동안 주님 앞에 펴 놓았던 조건부 거래 장부가 소리 없이 덮이고 있었다.** |
| **4문단 중반**<br>`(독자 #2)` | 정작 하나님 자신이 아니라 성소라는 장소와 <u>예배라는 형식, 내가 쌓아 올린 종교적 업적</u>을 찾음의 목적어로 삼았다. | 정작 하나님 자신이 아니라 성소라는 장소와 내가 채운 성경 통독 표와 새벽 출석 도장 같은 종교적 이력을 찾음의 목적어로 삼았다. | 정작 하나님 자신이 아니라 성소라는 장소와 **예배의 횟수, 내가 채운 출석 도장과 종교적 이력**을 찾음의 목적어로 삼았다. |
| **5문단 말미**<br>`(독자 #3)`<br>`[Round 1 역점검]` | 말씀이 들려오는 지금 이 순간 쓰러진 자의 호흡을 다시 시작하게 만드는 <u>창조적이고 수행적인 발화다.</u> *(번역투 학술어)* | 말씀이 들려오는 지금 이 순간 쓰러진 자의 호흡을 다시 시작하게 만드는 <u>초월적 생명력의 선언이자 창조적 사건이다.</u> *(추상 한자어 유입)* | 말씀이 들려오는 지금 이 순간 **쓰러진 자의 멈춘 가슴에 다시 첫 숨을 불어넣어 일으켜 세우시는 주님의 살려 내는 분부다.** |
| **7문단 말미**<br>`(내 마음 #2)`<br>`[Round 1 역점검]` | <u>그렇게 문장을 고쳐 쓸 때, 모든 성도는 예배당 안팎의 모든 공간에서 신앙과 일상을 완벽하게 일치시키며 참된 그리스도인의 사명을 온전히 완수하게 된다.</u> *(전칭 과장 클리셰)* | 그렇게 문장을 고쳐 쓸 때, 성도들은 예배당 안팎에서 <u>진정한 공동체적 영성의 회복과 일상의 성화를 깊이 경험하게 된다.</u> *(교계 상투어 유입)* | **그렇게 문장을 고쳐 적어 놓고 나면, 새벽 예배당 의자에 앉은 교우의 어깨에서도, 삶의 무거운 형편 때문에 그 시각 일터와 부엌에서 아침을 여는 교우의 마음에서도 조건의 짐이 한 겹 덜어지기를 조용히 바라게 된다.** |
| **8문단 결미**<br>`(내 마음 #3)`<br>`[Round 1 역점검]` | <u>우리가 성경 여백과 일터의 장부, 그리고 매일의 삶에서 조건의 계산식을 완전히 버리고 주님의 명령에 절대적으로 순종할 때, 우리의 모든 날은 마침내 흔들리지 않는 생명의 기적으로 가득 차게 될 것이다.</u> *(조건문·기적 클리셰)* | 다이어리를 덮고 일어서는 내 발걸음마다 주님이 주시는 <u>놀라운 평강과 생명의 은총이 영원한 찬송처럼 울려 퍼진다.</u> *(감상적 미사여구 유입)* | **두 줄의 문장을 나란히 적어 놓은 다이어리를 덮고 책상 스탠드 불을 끈다. 창밖으로 밝아 오는 아침 공기를 가슴 깊이 들이쉬며, 나는 오늘도 주님을 찾고, 그리고 내게 맡겨진 오늘 하루를 살아내러 방문을 연다.** |

---

## [Gate 5 - Round 3] 김익한 5대 평가지표 최종 감리 총평
1. **수월성 (Pass)**: 아모스 5:1–6의 히브리어 원문 계량 분석(79단어·105형태소 중 조건 표지 0개, 구약 7절 중 유일한 이중 명령형 2절)과 칼뱅의 이중 은혜, 성경신학적 정점(요 5:39–40, 계 1:18)이 학술적 과시 없이 목회자·세무사의 일상 서사 속에 물 흐르듯 용해됨.
2. **주체성 (Pass)**: Gate 4와 Gate 5 Round 1~2를 거치며 AI식 전칭 과장어(`모든`, `완벽하게`, `완전히`, `절대적으로`)와 당위적 조건문 결미를 철저히 도려내고, 글쓴이 자신이 감당할 수 있는 정직한 고백과 구체적 첫 동작(다이어리를 덮고 스탠드 불을 끄고 방문을 여는 동작)으로 온전히 복원됨.
3. **논리성 (Pass)**: ‘그리하면’의 통념 해체(1문단) → 일상·세무 유추와 그 한계선(2문단) → 세 방향 신체 멈춤과 정면 날숨(3문단) → 목적어 분별(4문단) → 이중 은혜와 살려 내는 분부(5문단) → 세무 상담실·목회 공지·아침 다이어리(6~8문단)로 이어지는 8문단 인과 사슬에 비약이 없음.
4. **선명성 (Pass)**: 번역투 개념어(‘창조적이고 수행적인 발화’)와 추상 한자어(‘초월적 생명력의 선언’)를 걷어내고 ‘쓰러진 자의 멈춘 가슴에 다시 첫 숨을 불어넣어 일으켜 세우시는 주님의 살려 내는 분부’로 벼려 내어 주제가 단번에 각인됨.
5. **감응성 (Pass)**: 구겨진 영수증 뭉치를 든 폐업 위기 사업자에게 건네는 두 줄의 문장과, 새벽 스탠드를 켜며 시작해 스탠드 불을 끄고 방문을 열며 끝맺는 수미상관의 호흡이 깊은 울림과 위로를 남김.
"""
        amos5_design_path = Path(workspace_root) / "20261110_살아내는_일도_주님께로부터_받은_거룩한_분부입니다_아모스_5_1-6_ican_write_설계기록.md"
        amos5_design_path.write_text(amos5_design_md, encoding="utf-8")

        for target_md in (amos5_final_path, amos5_ingyeok_path, amos5_draft1_path, amos5_design_path):
            out, title, date_str = process_file(str(target_md), template_html, args.suffix, args.cuts)
            print(f"Created: {out}")
            processed_items.append((str(target_md), out, title, date_str))

        amos5_top_cards = """        <h2 class="section-title">철학 · 신학 성찰 에세이</h2>
        <div class="list-group">
            <a href="./20261110_인격만들기_에세이.html" class="list-item" target="_blank">
                <div class="item-info">
                    <h3>살아내는 일도 주님께로부터 받은 거룩한 분부입니다 — ‘그리하면’의 거래 장부를 덮고 ‘그리고’의 호흡으로 읽는 아모스 5장 (ican-write 다회차 완성본 · A4/모바일 반응형)</h3>
                    <p>아모스 5:1-6 ‘디르슈니 비흐유’ 두 명령형과 접속사 ‘브(וְ)’ 한 글자, 세 성소에서 돌아서는 호흡, 세무 상담실과 아침 다이어리의 두 줄 분부</p>
                </div>
                <div class="arrow">→</div>
            </a>
            <a href="./20261110_살아내는_일도_주님께로부터_받은_거룩한_분부입니다_아모스_5_1-6_깊은사고_에세이.md" class="list-item" target="_blank" download>
                <div class="item-info">
                    <h3>살아내는 일도 주님께로부터 받은 거룩한 분부입니다 — 아모스 5:1-6 (5단계 완성본 MD 다운로드)</h3>
                    <p>옵시디언 및 마크다운 에디터용 원본 문서 (ican-drafter ⇄ ican-evaluator 3라운드 정밀 퇴고 완성본)</p>
                </div>
                <div class="arrow">↓</div>
            </a>
            <a href="./20261110_살아내는_일도_주님께로부터_받은_거룩한_분부입니다_아모스_5_1-6_초고1.html" class="list-item" target="_blank">
                <div class="item-info">
                    <h3>살아내는 일도 주님께로부터 받은 거룩한 분부입니다 — 아모스 5:1-6 (4단계 초고 1 · A4/모바일 반응형)</h3>
                    <p>ican-drafter가 3단계 최종 상세설계도(v3)를 바탕으로 집필한 4단계 초고 1 원문 및 본문 연동 3컷 지면</p>
                </div>
                <div class="arrow">→</div>
            </a>
            <a href="./20261110_살아내는_일도_주님께로부터_받은_거룩한_분부입니다_아모스_5_1-6_ican_write_설계기록.html" class="list-item" target="_blank">
                <div class="item-info">
                    <h3>[ican-write 이원화·다회차(Round 1~3) 설계·평가 기록] 살아내는 일도 주님께로부터 받은 거룩한 분부입니다 (A4/모바일 반응형)</h3>
                    <p>ican-drafter ⇄ ican-evaluator의 2단계·3단계·5단계 각 3라운드(v1→v2→v3) 반복 비평·조율 및 구절별 3단 퇴고 대조표</p>
                </div>
                <div class="arrow">→</div>
            </a>
            <a href="./20261110_살아내는_일도_주님께로부터_받은_거룩한_분부입니다_아모스_5_1-6_ican_write_설계기록.md" class="list-item" target="_blank" download>
                <div class="item-info">
                    <h3>[ican-write 이원화·다회차(Round 1~3) 설계·평가 기록] 아모스 5:1-6 에세이 (MD 다운로드)</h3>
                    <p>옵시디언 및 마크다운 에디터용 이원화·다회차 에이전트 설계·평가·퇴고 기록 원본 문서 (.md)</p>
                </div>
                <div class="arrow">↓</div>
            </a>
            <a href="./20261109_답장란이_비어_있는_편지철_그_끝에_찍힌_일곱_번의_서명_건우의_서른한_번째_생일_깊은사고_에세이.html\""""

        for repo_name in ("bible-thought", "sparkofbible"):
            idx_p = Path(workspace_root) / repo_name / "index.html"
            if idx_p.exists():
                raw = idx_p.read_text(encoding="utf-8")
                m = re.search(
                    r'\s*<h2 class="section-title">철학 · 신학 성찰 에세이</h2>\s*<div class="list-group">.*?<a href="\./20261109_답장란이_비어_있는_편지철_그_끝에_찍힌_일곱_번의_서명_건우의_서른한_번째_생일_깊은사고_에세이\.html"',
                    raw,
                    flags=re.DOTALL,
                )
                if m:
                    raw = raw[: m.start()] + "\n" + amos5_top_cards + raw[m.end() :]
                    idx_p.write_text(raw, encoding="utf-8")

    if args.geonwoo_ican:
        gw_draft1_md = """---
title: "답장란이 비어 있는 편지철, 그 끝에 찍힌 일곱 번의 서명 — 청풍호의 솔잎 위에서 아모스 4장과 출애굽기 33장으로 아들 건우의 서른한 번째 생일을 축복하며 (초고 1)"
date: 2026-11-09
tags: [청풍호, 솔잎, 아모스4장, 네움여호와, 출애굽기33장11절, 하나님의친구, 건우생일, 초고1]
---

# 답장란이 비어 있는 편지철, 그 끝에 찍힌 일곱 번의 서명 — 청풍호의 솔잎 위에서 아모스 4장과 출애굽기 33장으로 아들 건우의 서른한 번째 생일을 축복하며

어제 제천 청풍호반을 걸으며 내 안의 과열된 열정을 내려놓는 평강의 좌표를 묵상한 데 이어, 오늘 아침 다시 호숫가 산책로로 나섰다. 밤사이 호수 위로 낮게 깔린 물안개 사이로 나무 데크와 흙길이 이어지고, 그 위로 갈색 솔잎들이 발목이 푹신하게 잠길 만큼 수북이 내려앉아 있었다. 걸음을 멈추고 허리를 숙여 밑동이 하나로 묶인 솔잎 두 바늘을 집어 들었다. 발밑을 가득 덮은 저 솔잎들은 어쩌다 한 번 스쳐 간 바람에 떨어진 것이 아니었다. 지난 계절 내내 소나무가 가지를 흔들어 쉼 없이 내려보낸 시간의 흔적들이 겹겹이 쌓여 오늘 아침의 양탄자를 이룬 것이다. 손가락 끝으로 마른 솔잎의 결을 매만지는데, 마침 오늘이 아들 건우가 서른한 번째 생일을 맞는 아침이라는 사실이 가슴을 따뜻하게 데웠다.

아들에게 건넬 생일 축복의 말을 생각하며 숙소 창가에 앉아 펼친 본문은 아모스 4장 1절에서 13절이었다. 뜻밖에도 그 지면 위에는 방금 산책길에서 밟고 온 솔잎의 두께만큼이나 묵직한 하나님의 부르심들이 층층이 쌓여 있었다. 하나님은 북이스라엘을 향해 다섯 번이나 부르심의 언어를 바꾸셨다. 양식이 떨어지는 기근으로(6절), 비를 멈추는 가뭄으로(7~8절), 곡식을 치는 풍재와 깜부기병으로(9절), 애굽의 전염병으로(10절), 그리고 소돔과 고모라 같은 성읍의 무너짐으로(11절) 거듭 신호를 보내셨다. 그러나 그 다섯 번의 단락 끝마다 토씨 하나 바뀌지 않고 똑같이 적힌 문장은 오직 하나, “너희가 내게로 돌아오지 아니하였느니라(‘벨로-샤브템 아다이’)”라는 서늘한 무응답의 기록이었다.

다섯 번이나 되풀이되는 이 침묵의 후렴구를 읽는 순간, 세무 행정 현장에서 오랫동안 마주하곤 했던 행정 문서들이 눈앞에 겹쳐졌다. 과세 관청에서 소명 안내문을 여러 차례 보내도 수신인이 여러 사정으로 봉투를 열지 않으면 그 서류철의 회신란은 끝내 하얗게 비어 있게 마련이다. 마르틴 부버가 말했듯 하나님은 매 순간 삶의 구체적인 사건들을 통해 우리에게 인격적인 말을 건네시건만, 아모스 4장은 발신인이 계절마다 편지지와 필체를 바꾸어 다섯 통의 등기 우편을 보냈음에도 수신인의 답장란이 전부 비어 있는 한 묶음의 편지철 같았다. 그리고 그 빈칸은 남의 이야기가 아니었다. 예순 해의 세월을 숨 가쁘게 달려오는 동안, 내 삶의 구비마다 찾아왔던 숱한 신호들을 그저 우연이나 일상의 긴장으로 치부한 채 봉투조차 뜯지 않고 지나쳐 버린 내 영혼의 미회신 구간들이 솔잎처럼 발밑에 쌓여 있었기 때문이다.

그런데 아모스 4장의 편지철을 다시 들여다보던 내 눈길이 기이한 대목에서 멈추었다. 하얗게 비어 있는 백성들의 답장란 바로 뒤마다, 동사조차 생략된 채 ‘여호와의 말씀이니라(‘네움 여호와’)’라는 두 단어의 명사 묶음이 본문 전체에 일곱 번이나 도장처럼 찍혀 있는 것이다. 아브라함 헤셸이 ‘하나님의 파토스(아파하시는 사랑)’라 불렀던 그 행간의 침묵이 어떤 무게인지 몸으로 가늠해 보고 싶었다. 나는 묵상 노트를 쓰다 말고 오른손으로 책상을 도장 찍듯 누른 채 입을 벌렸다가 하고 싶은 말을 그대로 삼켜 보았다. 이내 턱 근육이 뻐근해져 왔다. 다섯 번의 침묵 뒤에 일곱 번 찍힌 ‘네움 여호와’는 위엄 있는 심판관의 냉정한 관인이 아니었다. 아무리 불러도 대답 없는 자식 앞에서, 차마 관계를 끊겠다는 말은 내뱉지 못하고 어금니를 물며 당신의 이름 석 자만 다시 눌러 찍으신 아버지의 뻐근한 친필 서명이었다.

다섯 번째 부르심 끝에서 하나님은 끝내 돌아오지 않는 그들을 가리켜 “불붙는 가운데서 빼낸 나무 조각(‘무차르’) 같았으나”(암 4:11)라고 탄식하신다. 히브리어 수동 분사로 적힌 이 한 단어 앞에서 내 지난날의 자부심이 조용히 허물어졌다. 나무 조각은 스스로 불구덩이에서 걸어 나올 수 없다. 누군가 뜨거운 불길 속으로 손을 뻗어 건져 올려 주었기에 비로소 재가 되지 않고 남았을 뿐이다. 나 역시 지난 예순 해의 숱한 위기와 고비들을 내 판단과 성실함으로 통과해 온 줄 알았으나, 돌아보니 내 삶의 모든 성취는 내가 이룬 것이 아니라 불붙는 자리에서 나를 빼내신 하나님의 손길이 남긴 구원의 흔적이었다.

세상의 행정 절차에서는 소명 기한까지 끝내 회신이 없으면 지체 없이 직권 처분 통지서를 발송하고 모든 대화를 종결한다. 다섯 번이나 소명 기회를 저버렸다면 이제는 관계 파기와 최종 처벌이 선고되어야 마땅하다. 그러나 12절을 여시는 하나님은 처분 통지서를 내미는 대신 끝내 ‘네 하나님(‘엘로헤이카’)’이라는 호칭을 거두지 않으신다. “그러므로 이스라엘아 내가 이와 같이 네게 행하리라 이스라엘아 네 하나님 만나기를 예비하라.” 산들을 지으시고 바람을 창조하시며 사람의 속생각을 낱낱이 아시는 만군의 하나님(13절)께서, 그을음 묻은 나무 조각 같은 우리를 법정의 피고인으로 호명하시는 것이 아니라 “이제 그만 숨고 나와 내 얼굴을 마주 보자”고 대면의 자리로 부르시는 것이다.

“네 하나님 만나기를 예비하라”는 이 눈물겨운 초청장 앞에서, 나는 오늘 서른한 번째 생일을 맞은 아들 건우의 이름을 나직이 불러 본다. 건우(建友), ‘하나님의 친구’라는 네 이름은 출애굽기 33장 11절, “사람이 자기의 친구와 이야기함 같이 여호와께서는 모세와 대면하여 말씀하시며… 눈의 아들 젊은 수종자 여호수아는 회막을 떠나지 아니하니라”라는 말씀에서 길어 올린 약속이다. 모세 곁에서 회막을 떠나지 않던 그 젊은 여호수아의 나이를 꼭 닮은 서른한 살의 아들아. 아버지는 예순 해를 돌고 돌아서야 비로소 내가 놓쳤던 빈 회신란 앞에 멈춰 섰지만, 네가 걸어갈 서른한 살의 계절은 달랐으면 한다. 인생의 무게 앞에서 하나님께 완벽한 성취의 소명서를 제출하려 홀로 애쓰기보다, 설령 그을음이 묻은 자리에서라도 친구처럼 얼굴과 얼굴을 마주하며 “아버지, 제가 여기 있습니다”라고 먼저 눈을 맞추는 회막의 사람이 되기를 축복한다. 그렇게 하나님과 날마다 대면하는 습관만이 모든 인생의 승패를 결정짓는 유일한 열쇠이기 때문이다.

산책길에서 주워 온 갈색 솔잎 두 바늘을 아모스 4장이 펼쳐진 성경책 갈피에 나란히 끼워 넣는다. 한 뿌리에서 나와 끝까지 떨어지지 않은 두 바늘처럼, 하나님과 마주 앉을 아들의 서른한 살과 내 남은 계절이 그분 안에서 나란히 묶여 있기를 기도한다. 일곱 번이나 당신의 이름을 도장처럼 찍으시며 기다리신 아버지의 편지철 맨 아랫줄, 오랫동안 하얗게 비어 있던 내 회신란에 오늘 아침 아버지가 먼저 늦은 답장 한 줄을 적어 올린다. “주님, 그 모든 날에 나를 부르셨군요. 건우의 서른한 번째 생일 아침, 저도 이제 주님 앞에 마주 서 있습니다.”
"""
        gw_draft1_path = Path(workspace_root) / "20261109_답장란이_비어_있는_편지철_그_끝에_찍힌_일곱_번의_서명_건우의_서른한_번째_생일_초고1.md"
        gw_draft1_path.write_text(gw_draft1_md, encoding="utf-8")

        gw_final_md = """---
title: "답장란이 비어 있는 편지철, 그 끝에 찍힌 일곱 번의 서명 — 청풍호의 솔잎 위에서 아모스 4장과 출애굽기 33장으로 아들 건우의 서른한 번째 생일을 축복하며 (ican-write 5단계 다회차 완성본)"
date: 2026-11-09
tags: [청풍호, 솔잎, 아모스4장, 네움여호와, 무차르, 출애굽기33장11절, 하나님의친구, 건우생일, ican-write, 성찰에세이]
---

# 답장란이 비어 있는 편지철, 그 끝에 찍힌 일곱 번의 서명 — 청풍호의 솔잎 위에서 아모스 4장과 출애굽기 33장으로 아들 건우의 서른한 번째 생일을 축복하며

어제 제천 청풍호반을 걸으며 내 안의 과열된 열정을 내려놓는 평강의 좌표를 묵상한 데 이어, 오늘 아침 다시 호숫가 산책로로 나섰다. 밤사이 호수 위로 낮게 깔린 물안개 사이로 나무 데크와 흙길이 이어지고, 그 위로 갈색 솔잎들이 발목이 푹신하게 잠길 만큼 수북이 내려앉아 있었다. 걸음을 멈추고 허리를 숙여 밑동이 하나로 묶인 솔잎 두 바늘을 집어 들었다. 발밑을 가득 덮은 저 솔잎들은 어쩌다 한 번 스쳐 간 바람에 떨어진 것이 아니었다. 지난 계절 내내 소나무가 가지를 흔들어 쉼 없이 내려보낸 시간의 흔적들이 겹겹이 쌓여 오늘 아침의 양탄자를 이룬 것이다. 손가락 끝으로 마른 솔잎의 결을 매만지는데, 마침 오늘이 아들 건우가 서른한 번째 생일을 맞는 아침이라는 사실이 가슴을 따뜻하게 데웠다.

아들에게 건넬 생일 축복의 말을 생각하며 숙소 창가에 앉아 펼친 본문은 아모스 4장 1절에서 13절이었다. 뜻밖에도 그 지면 위에는 방금 산책길에서 밟고 온 솔잎의 두께만큼이나 묵직한 하나님의 부르심들이 층층이 쌓여 있었다. 하나님은 북이스라엘을 향해 다섯 번이나 부르심의 언어를 바꾸셨다. 양식이 떨어지는 기근으로(6절), 비를 멈추는 가뭄으로(7~8절), 곡식을 치는 풍재와 깜부기병으로(9절), 애굽의 전염병으로(10절), 그리고 소돔과 고모라 같은 성읍의 무너짐으로(11절) 거듭 신호를 보내셨다. 그러나 그 다섯 번의 단락 끝마다 토씨 하나 바뀌지 않고 똑같이 적힌 문장은 오직 하나, “너희가 내게로 돌아오지 아니하였느니라(‘벨로-샤브템 아다이’)”라는 서늘한 무응답의 기록이었다.

다섯 번이나 되풀이되는 이 침묵의 후렴구를 읽는 순간, 세무 행정 현장에서 오랫동안 마주하곤 했던 서류철들이 눈앞에 겹쳐졌다. 과세 관청에서 소명 안내 등기 우편을 여러 차례 보내도 수신인이 당장 눈앞의 생업이 바쁘다는 이유로, 혹은 봉투 안의 무거운 질문을 마주하기가 두려워 끝내 봉투를 열지 않으면 그 서류철의 회신란은 하얗게 비어 있게 마련이다. 마르틴 부버가 말했듯 하나님은 매 순간 삶의 구체적인 사건들을 통해 우리에게 인격적인 말을 건네시건만, 아모스 4장은 발신인이 계절마다 편지지와 필체를 바꾸어 다섯 통의 등기 우편을 보냈음에도 수신인의 답장란이 전부 비어 있는 한 묶음의 편지철 같았다. 그리고 그 빈칸은 남의 이야기가 아니었다. 예순 해의 세월을 숨 가쁘게 달려오는 동안, 예기치 않게 찾아왔던 몸의 고단함이나 관계의 막막함, 계획대로 풀리지 않던 일터의 멈춤 신호들을 그저 지나가야 할 계절의 피로쯤으로 여긴 채 봉투조차 뜯지 않고 지나쳐 버린 내 영혼의 미회신 구간들이 솔잎처럼 발밑에 쌓여 있었기 때문이다.

그런데 아모스 4장의 편지철을 다시 들여다보던 내 눈길이 기이한 대목에서 멈추었다. 하얗게 비어 있는 백성들의 답장란 바로 뒤마다, 동사조차 생략된 채 ‘여호와의 말씀이니라(‘네움 여호와’)’라는 두 단어의 명사 묶음이 본문 전체에 일곱 번이나 도장처럼 찍혀 있는 것이다. 아브라함 헤셸이 ‘하나님의 파토스(아파하시는 사랑)’라 불렀던 그 행간의 침묵이 어떤 무게인지 몸으로 가늠해 보고 싶었다. 나는 묵상 노트를 쓰다 말고 오른손으로 책상을 도장 찍듯 누른 채 입을 벌렸다가 하고 싶은 말을 그대로 삼켜 보았다. 이내 턱 근육이 뻐근해져 왔다. 잠시 말을 꾹 삼키며 버티는 일만으로도 내 턱이 이토록 쉽게 지치는데, 다섯 번의 외면 앞에서도 끝내 절교의 말을 삼키신 아버지의 침묵은 얼마나 묵직했을까. 다섯 번의 침묵 뒤에 일곱 번 찍힌 ‘네움 여호와’는 위엄 있는 심판관의 냉정한 관인이 아니었다. 아무리 불러도 대답 없는 자식 앞에서, 차마 관계를 끊겠다는 말은 내뱉지 못하고 어금니를 물며 당신의 이름 석 자만 다시 눌러 찍으신 아버지의 뻐근한 친필 서명이었다.

다섯 번째 부르심 끝에서 하나님은 끝내 돌아오지 않는 그들을 가리켜 “불붙는 가운데서 빼낸 나무 조각(‘무차르’) 같았으나”(암 4:11)라고 탄식하신다. 히브리어 수동 분사로 적힌 이 한 단어 앞에서 내 지난날의 자부심이 조용히 허물어졌다. 나무 조각은 스스로 불구덩이에서 걸어 나올 수 없다. 누군가 뜨거운 불길 속으로 손을 뻗어 건져 올려 주었기에 비로소 재가 되지 않고 남았을 뿐이다. 나 역시 지난 예순 해의 숱한 위기와 고비들을 내 판단과 성실함으로 통과해 온 줄 알았으나, 돌아보니 내가 내 힘으로 버텨 내고 일구어 냈다고 믿었던 그 자리들조차, 실은 뜨거운 불길 속으로 손을 뻗어 나를 건져 올리신 하나님의 손길이 남긴 구원의 흔적이었다.

세상의 행정 절차에서는 소명 기한까지 끝내 회신이 없으면 지체 없이 직권 처분 통지서를 발송하고 모든 대화를 종결한다. 다섯 번이나 소명 기회를 저버렸다면 이제는 관계 파기와 최종 처벌이 선고되어야 마땅하다. 그러나 12절을 여시는 하나님은 처분 통지서를 내미는 대신 끝내 ‘네 하나님(‘엘로헤이카’)’이라는 호칭을 거두지 않으신다. “그러므로 이스라엘아 내가 이와 같이 네게 행하리라 이스라엘아 네 하나님 만나기를 예비하라.” 산들을 지으시고 바람을 창조하시며 사람의 속생각을 낱낱이 아시는 만군의 하나님(13절)께서, 그을음 묻은 나무 조각 같은 우리를 법정의 피고인으로 호명하시는 것이 아니라 “이제 그만 숨고 나와 내 얼굴을 마주 보자”고 대면의 자리로 부르시는 것이다.

“네 하나님 만나기를 예비하라”는 이 눈물겨운 초청장 앞에서, 나는 오늘 서른한 번째 생일을 맞은 아들 건우의 이름을 나직이 불러 본다. 건우(建友), ‘하나님의 친구’라는 네 이름은 출애굽기 33장 11절, “사람이 자기의 친구와 이야기함 같이 여호와께서는 모세와 대면하여 말씀하시며… 눈의 아들 젊은 수종자 여호수아는 회막을 떠나지 아니하니라”라는 말씀에서 길어 올린 약속이다. 모세 곁에서 회막을 떠나지 않던 그 젊은 여호수아의 나이를 꼭 닮은 서른한 살의 아들아. 아버지는 예순 해를 돌고 돌아서야 비로소 내가 놓쳤던 빈 회신란 앞에 멈춰 섰지만, 네가 걸어갈 서른한 살의 계절은 달랐으면 한다. 인생의 무게 앞에서 하나님께 완벽한 성취의 소명서를 제출하려 홀로 애쓰기보다, 설령 그을음이 묻은 자리에서라도 친구처럼 얼굴과 얼굴을 마주하며 “아버지, 제가 여기 있습니다”라고 먼저 눈을 맞추는 회막의 사람이 되기를 축복한다. 우리가 하나님 앞에서 끝내 지켜야 할 것은 무결점의 성적표가 아니라, 부르실 때 언제든 고개를 돌려 마주 보는 그 따뜻한 눈맞춤 하나면 충분하기 때문이다.

산책길에서 주워 온 갈색 솔잎 두 바늘을 아모스 4장이 펼쳐진 성경책 갈피에 나란히 끼워 넣는다. 한 뿌리에서 나와 끝까지 떨어지지 않은 두 바늘처럼, 하나님과 마주 앉을 아들의 서른한 살과 내 남은 계절이 그분 안에서 나란히 묶여 있기를 기도한다. 일곱 번이나 당신의 이름을 도장처럼 찍으시며 기다리신 아버지의 편지철 맨 아랫줄, 오랫동안 하얗게 비어 있던 내 회신란을 대신하여, 성경책 옆에 펼쳐 둔 묵상 노트의 빈 여백에 만년필로 내 이름 석 자와 함께 늦은 답장 한 줄을 또박또박 적어 내려간다. “주님, 그 모든 날에 나를 부르셨군요. 건우의 서른한 번째 생일 아침, 저도 이제 주님 앞에 마주 서 있습니다.”
"""
        gw_final_path = Path(workspace_root) / "20261109_답장란이_비어_있는_편지철_그_끝에_찍힌_일곱_번의_서명_건우의_서른한_번째_생일_깊은사고_에세이.md"
        gw_final_path.write_text(gw_final_md, encoding="utf-8")

        gw_design_md = """---
title: "[ican-write 이원화·다회차(Round 1~3) 설계·평가 기록] 답장란이 비어 있는 편지철, 그 끝에 찍힌 일곱 번의 서명 — 아들 건우의 서른한 번째 생일을 축복하며"
date: 2026-11-09
tags: [ican-write, ican-drafter, ican-evaluator, 다회차제련, 아모스4장, 출애굽기33장11절, 건우생일]
---

# [ican-write 이원화·다회차(Round 1~3) 설계·평가 기록] 답장란이 비어 있는 편지철, 그 끝에 찍힌 일곱 번의 서명 — 아들 건우의 서른한 번째 생일을 축복하며

본 문서는 진행·집필 전담 에이전트(**`ican-drafter`**)와 독립 평가·선택안 결정 전담 에이전트(**`ican-evaluator`**)가 분리 운영되며, 특히 **2단계(목차), 3단계(상세설계도), 5단계(내 글화·5대 지표 퇴고)에서 단 1회에 끝내지 않고 각 3라운드(`Round 1 → Round 2 → Round 3`)에 걸쳐 평가·비평·수정을 주고받으며 원고를 벼려 낸 전 과정**을 기록한 문서입니다.

---

## [1단계] 글감 발견과 생각 확장 (`ican-drafter` 후보 도출 ⇄ `ican-evaluator` Gate 1 결정)

### 1-1. `ican-drafter` 글감 후보 3안 및 학술·성경 자료 후보 4종 제출
* **글감 후보 A안 (경험·성찰 및 부자 서신 통합형)**: 서른한 번째 생일을 맞은 아들 건우의 아침, 청풍호 산책길에 수북이 내려앉은 갈색 솔잎을 밟으며, 다섯 번의 침묵(‘벨로-샤브템 아다이’) 끝에도 ‘네 하나님’이라는 호칭을 거두지 않고 일곱 번 친필 서명(‘네움 여호와’)을 찍으신 아모스 4장의 하나님이 내 예순 해의 빈칸을 어떻게 기다리셨는지 고백하고 아들을 ‘하나님의 친구(출 33:11)’로 축복하는 이야기.
* **글감 후보 B안 (세무 실무 은유·본문 주해 중심형)**: 세무서에서 보낸 소명 안내문 봉투를 끝내 뜯지 않아 비어 있던 납세자의 회신란을 떠올리며, 아모스 4장의 다섯 번 무응답과 일곱 번의 서명이 어떻게 대면의 초청장(“네 하나님 만나기를 예비하라”)으로 역전되는지 밝히는 글.
* **글감 후보 C안 (자연 관조·인생 후반전 묵상형)**: 어제 청풍호반에서 고강도 열정을 내려놓는 평강을 묵상한 데 이어, 오늘 아침 다시 걸은 호숫가 솔숲의 낙엽을 보며 내 인생의 무응답과 타다 남은 나무 조각 같은 한계를 인정하고 하나님 앞에 조용히 서는 법을 성찰하는 에세이.
* **학술·성경 자료 후보 4종**:
  1. **마르틴 부버(Martin Buber), 『나와 너(Ich und Du, 1923)』**: ‘부르심과 응답(Anrede und Antwort)’ 및 사건 너머에서 인격적 ‘너(Du)’를 부르시는 하나님.
  2. **아브라함 조슈아 헤셸(Abraham Joshua Heschel), 『예언자들(The Prophets, 1962)』**: ‘하나님의 파토스(Divine Pathos)’ — 인간의 외면에 가장 깊이 아파하시며 끝까지 구애하시는 아버지.
  3. **아모스 4:6-12 히브리어 원어 구문 4종**: `벨로-샤브템 아다이`(5회 무응답), `네움 여호와`(7회 명사구 서명), 호팔 수동 분사 `무차르`(불붙는 데서 건져 올려진 나무 조각), 2인칭 단수 소유격 `엘로헤이카`(네 하나님).
  4. **출애굽기 33:11 히브리어 원문**: `파님 엘 파님`(얼굴과 얼굴을 마주하여)과 회막을 떠나지 아니한 젊은 수종자 여호수아.

### 1-2. `ican-evaluator` [Gate 1] 비교 심사 및 최종 선택 결정
* **글감 심사 판정**:
  * **B안 기각**: 과세 예고·독촉장·체납 처분 절차와 일대일로 대응시키는 발상은 구조적 명쾌함은 있으나, 글이 ‘세무 행정을 활용한 성경 강해’로 굳어져 오늘 아침 청풍호 산책과 아들 건우의 31번째 생일이라는 고유한 실존적 체온이 반감됨.
  * **C안 기각**: 어제(11월 8일) 묵상과 변별력이 약해지며, 아모스 4장의 서늘한 긴장감과 부자(父子) 세대 계승의 역동성이 약화됨.
  * **최종 채택 (글감 A안)**: ① 구체적 시공간의 감각(청풍호 산책로 발밑의 갈색 솔잎 두 바늘), ② 텍스트의 낯선 발견(다섯 번 비어 있는 답장란 뒤에 일곱 번 찍힌 ‘네움 여호와’ 서명과 수동 분사 ‘무차르’), ③ 실존적 수신인의 현존(오늘 서른한 살 생일을 맞은 아들 건우[建友, 출 33:11 ‘하나님의 친구’])이 하나의 유기적 질문으로 맞물려 있어 최우수안으로 채택.
* **학술·성경 자료 4종 활용 수위 결정**:
  * **아모스 4:6-12 히브리어 원어 4종 & 출애굽기 33:11**: 전면 채택 (본 에세이의 주해적 물증 및 성경 내적 가교).
  * **마르틴 부버 『나와 너』 & 아브라함 헤셸 『예언자들』**: 조건부 채택 — 본문에서 철학·신학 강의처럼 길게 설명하지 말고, 각각 ‘미개봉 소명 안내문’ 비유 및 ‘책상을 도장 찍듯 누르며 말을 삼킬 때의 뻐근한 턱 근육 감각’과 결합해 1문장으로 압축 용해할 것.

---

## [2단계] 핵심 메시지 정립과 독자 중심 목차 설계 (3라운드 반복 제련: `v1 → v2 → v3`)

### [Round 1] 초기 목차(`v1`) 도출 및 `ican-evaluator` 1차 심사 (독자 질문 및 빠진 징검다리 지적)
* **`ican-drafter` 초기 제출안(`v1`)**: 목차 A안(경험·서신형 4장 12절) vs 목차 B안(주해·논증형 4장 12절).
* **`ican-evaluator` [Gate 2 - Round 1 심사 지시]**:
  1. **기본 틀**: 아침 산책의 감각에서 출발해 부자(父子)의 서신으로 수렴하는 **목차 A안**을 기본 뼈대로 채택함.
  2. **[결함 1 — 빠진 징검다리 (1장 → 2장 비약)]**: ‘청풍호 산책로에 쌓인 갈색 솔잎’에서 ‘아모스 4장의 다섯 번 재앙과 세무서 미회신 우편물’로 넘어갈 때 매개가 빠져 있음. **‘켜켜이 쌓인 솔잎의 두께 = 오랫동안 뜯지 않고 쌓아 둔 미개봉 통지서·편지철의 두께’**라는 연상 고리를 명시할 것.
  3. **[결함 2 — 모호한 전환 논리 (3장 → 4장 비약)]**: 아모스 4:12(“네 하나님 만나기를 예비하라”)은 본래 심판 경고문인데 곧바로 아들의 생일 축복으로 넘어가면 작위적으로 보일 수 있음. 3장 말미에 **‘심판 법정의 호출장을 대면의 초청장으로 뒤집는 하나님의 호칭(“네 하나님, 엘로헤이카”)’**을 먼저 배치하여 신학적 전환을 완성할 것.

### [Round 2] 수정 목차(`v2`) 제출 및 `ican-evaluator` 2차 심사 (목차 3대 속성 정밀 점검)
* **`ican-drafter` 수정 제출안(`v2`)**: ‘솔잎 두께 → 미개봉 편지철’ 징검다리 및 ‘아모스 4:12(엘로헤이카) → 출 33:11(파님 엘 파님)’ 전환 고리를 보강한 수정 2단 목차 제출.
* **`ican-evaluator` [Gate 2 - Round 2 심사 지시]**:
  1. **[연결성·설득성 조율 — 절 제목의 원어 노출 절제]**: `v2`의 절 제목에 히브리어 음차(`벨로-샤브템 아다이`, `네움 여호와`, `무차르`, `엘로헤이카`)가 과다 노출되어 학술 논문 같은 거리감을 줌. 절 제목에서는 원어를 걷어내고 감각적인 한국어 어휘로 정제할 것.
  2. **[논리성 조율 — 은혜의 문법 순서 확정]**: ‘다섯 번의 빈칸(3문단)’ 직후에 **‘일곱 번 찍힌 아버지의 서명 네움 여호와(4문단)’**가 바로 맞물려야 대조의 충격파가 극대화됨. 그 서명의 아픔을 확인한 뒤 **‘불붙는 데서 빼낸 나무 조각 무차르(5문단)’**로 내 자부심이 허물어지고, 이어 **‘네 하나님을 만나라(6문단)’**는 대면 초청으로 나아가도록 순서를 확정할 것.

### [Round 3] 최종 목차(`v3`) 확정 및 Gate 2 최종 승인
* **확정 제목**: **`답장란이 비어 있는 편지철, 그 끝에 찍힌 일곱 번의 서명 — 청풍호의 솔잎 위에서 아모스 4장과 출애굽기 33장으로 아들 건우의 서른한 번째 생일을 축복하며`**
* **확정 2단 목차 (`v3`, 4장 12절)**:
  * **제1장. 청풍호의 갈색 솔잎과 아들의 서른한 번째 생일 아침** (1-1. 어제 호숫가에서 배운 평강에 이어 오늘 아침 발밑에 푹신하게 밟힌 갈색 솔잎의 두께 / 1-2. 계절 내내 내려앉은 솔잎과 서른한 살 생일을 맞은 아들 건우를 떠올리며 펼친 아모스 4장 / 1-3. 다섯 번이나 부르심의 언어를 바꾸셨으나 토씨 하나 바뀌지 않은 백성의 침묵)
  * **제2장. 답장란이 비어 있는 편지철과 삼켜진 말의 무게** (2-1. 세무서 시절 보았던 미회신 소명 안내문 철과 내 예순 해의 빈칸 / 2-2. 빈칸 직후마다 동사도 없이 도장처럼 일곱 번 찍힌 발신인의 친필 서명 / 2-3. 책상을 오른손으로 누르고 입을 벌린 채 말을 삼켜 보며 확인한 턱 근육의 뻐근함)
  * **제3장. 타다 남은 나무 조각을 여전히 ‘네 하나님’이라 부르시는 은혜** (3-1. 내 힘으로 걸어 나온 줄 알았던 여정, 실상은 불붙는 데서 건져 올려진 나무 조각 / 3-2. 세무 행정의 직권 처분 통지서와 달리 끝내 ‘네 하나님’이라는 호칭을 거두지 않으시는 부르심 / 3-3. “네 하나님 만나기를 예비하라”—추궁의 법정이 아니라 얼굴과 얼굴을 마주하자는 대면의 초청장)
  * **제4장. ‘하나님의 친구’ 건우에게, 오늘 아버지가 먼저 적는 답장 한 줄** (4-1. 출애굽기 33장 11절, 네 이름 ‘건우(하나님의 친구)’에 담긴 회막의 대면과 젊은 여호수아 / 4-2. 완벽한 성취의 소명서가 아니라 “제가 여기 있습니다”라는 솔직한 눈맞춤으로 서른한 살을 걸어가기를 / 4-3. 아모스 4장 여백에 청풍호 솔잎 두 바늘을 끼워 넣으며 아버지가 먼저 적어 올리는 늦은 답장)

---

## [3단계] A4 상세설계도와 재료 보강 (3라운드 반복 제련: `v1 → v2 → v3`)

### [Round 1] 초기 상세설계도(`v1`) 심사 및 3곳 재료 보강 지시
* **`ican-evaluator` [Gate 3 - Round 1 심사 지시]**:
  1. **[보강 1 — 2장 1절(3문단) 직업적 경험의 구체화]**: 세무 행정 경험을 ‘소명 안내 등기우편, 봉투조차 열지 않은 미개봉 상태, 하얗게 비어 있는 서류철의 회신란’이라는 구체적 실무 사물로 시각화하고, 이를 ‘예순 해 동안 바쁘다는 핑계로 미뤄 둔 내 영혼의 미회신 구간’으로 끌어안으라.
  2. **[보강 2 — 2장 3절~3장 1절(4~5문단) 신체 감각과 원어 문법의 결합]**: ‘네움 여호와’가 동사 없는 명사구로 7회 찍힌다는 사실을 독자가 체감하도록 **오른손으로 책상을 도장 찍듯 누른 채 말을 삼킬 때 턱 근육과 어금니가 뻐근해지는 신체 경험**을 `ㅇ메모`에 정밀 배치하고, 5문단에서 수동 분사 `무차르`를 통해 ‘내 판단과 성실함으로 위기를 넘겼다는 자부심’이 허물어지는 과정을 구체화하라.
  3. **[보강 3 — 4장 3절(8문단) 솔잎 두 바늘의 수미상관]**: 1문단에서 주운 **‘밑동이 하나로 묶인 갈색 솔잎 두 바늘’**이 8문단에서 아모스 4장 성경책 갈피에 끼워지며 **‘예순 해를 건너온 아버지와 서른한 살을 시작하는 아들 건우가 하나님 안에서 한 묶음으로 마주 서는 풍경’**으로 수미상관을 이루게 하라.

### [Round 2] 재료 보강안(`v2`) 전후 비교 심사 및 과잉 이론 절제 지시
* **`ican-evaluator` [Gate 3 - Round 2 심사 지시]**:
  * **설득력이 높아진 곳**: 등기우편과 빈 회신란, 턱 근육의 뻐근함, 솔잎 두 바늘의 수미상관으로 글의 물성과 체온이 비약적으로 살아남.
  * **과해져서 내 이야기를 가린 곳 (절제 지시 2건)**:
    1. **[학술 개념의 과잉 노출 절제]**: `v2`에서 마르틴 부버(『나와 너』의 `Es/Du` 존재론)와 아브라함 헤셸(『예언자들』의 반(反)아파테이아 논증) 설명이 길어져 아버지의 고백록이 신학 강의록처럼 딱딱해짐. 부버와 헤셸은 각각 한 문장 안에서 방향을 잡아주는 등대처럼만 언급하고, 글쓴이의 성찰과 신체 감각을 전면 배치할 것.
    2. **[7문단 아들 축복 대목의 훈계조 경계]**: 서른한 살 아들에게 건네는 당부가 도덕적 훈계로 흐르지 않도록, ‘아버지는 예순 해를 돌고 돌아서야 빈 회신란 앞에 멈춰 섰지만’이라는 아버지의 부끄러운 고백을 먼저 깔아 눈높이를 맞출 것.

### [Round 3] 최종 상세설계도(`v3`) 및 A4 3개 지면 연동 컷 일러스트 최종 승인
* **Page 001 확정 컷 (`cheongpungho_pine_needles_morning`)**: 안개 낀 청풍호 산책로에 수북이 내려앉은 갈색 솔잎들과 밑동이 하나로 묶인 솔잎 두 바늘 클로즈업
* **Page 002 확정 컷 (`amos4_blank_reply_seven_seals`)**: 다섯 번 비어 있던 회신란(`벨로-샤브템 아다이`) 끝에 일곱 번 찍힌 발신인의 붉은 서명(`네움 여호와`)과 불에서 건져낸 나무 조각(`무차르`)
* **Page 003 확정 컷 (`geonwoo_31_tent_of_meeting_reply`)**: 출애굽기 33장 11절 회막의 빛 아래 솔잎 두 바늘이 꽂힌 성경책과, 서른한 살 생일을 맞은 아들 건우를 축복하며 만년필로 적는 아버지의 늦은 답장 한 줄

---

## [4단계 & 5단계] `ican-evaluator` Gate 4 정밀 진단 및 Gate 5 3라운드(`초고 1 → v1 → v2 → v3`) 변증법적 퇴고 대조표

### 1. Gate 4 (`초고 1` 정밀 진단) & Gate 5 Round 1 역점검 (1차 퇴고안 `v1`에 새로 유입된 AI 상투어 적발)
* **Gate 4 진단**: `ican-drafter`의 `초고 1`(2,176자)에서 독자가 막연하게 느끼는 **`(독자)` 메모 3곳**(3문단 `행정 문서들/여러 사정으로`, 4문단 턱 근육 감각과 깨달음 사이의 징검다리 누락, 8문단 추상적 결말 동작)과 내 실제 마음보다 추상화·과장·보편화된 **`(내 마음)` 메모 3곳**(3문단 `숱한 신호들/우연이나 일상의 긴장`, 5문단 `내 삶의 모든 성취는`, 7문단 말미 `인생의 승패를 결정짓는 유일한 열쇠`라는 상투적 설교 클리셰)을 적시하여 1차 퇴고를 지시함.
* **Gate 5 - Round 1 역점검**: `ican-drafter`가 제출한 `1차 퇴고안(v1)`을 재심사한 결과, Gate 4 지적은 반영되었으나 **교정 과정에서 새로 끼어든 AI식 신파·교리 상투어·번역투 추상어 3곳**을 적발하여 2차 재수정을 지시함:
  1. **4문단(`v1`) 적발**: `하나님의 심정은 오죽하셨을까 하는 탄식이 절로 터져 나왔다` → 신파적 관용구 삭제, 절제된 내면의 울림으로 재수정 지시.
  2. **5문단(`v1`) 적발**: `하나님의 불가항력적인 은총이 남긴 기적의 흔적이었다` → 새로 유입된 교리적 상투어(`불가항력적인 은총`, `기적`) 삭제, 앞 문장의 나무 조각 비유와 직결되는 ‘뜨거운 불길 속으로 손을 뻗어 나를 건져 올리신 하나님의 손길’로 복원 지시.
  3. **7문단 말미(`v1`) 적발**: `부르실 때 언제든 돌아서서 마주 보는 그 진실한 실존의 시선 하나면 충분하기 때문이다` → 철학 번역투(`진실한 실존의 시선`) 삭제, 아버지의 육성인 **‘고개를 돌려 마주 보는 그 따뜻한 눈맞춤 하나면 충분하기 때문이다’**로 복원 지시.

### 2. 구절별 3단(`초고 1` → `1차 퇴고안 v1` → `최종 승인본 v2/v3`) 변증법적 퇴고 대조표

| 구간 | 4단계 `초고 1` (진단 전) | Gate 5 `1차 퇴고안(v1)` (1차 교정 및 역점검 대상) | Gate 5 `최종 승인 완성본(v2/v3)` (내 표현 완전 복원) |
| :--- | :--- | :--- | :--- |
| **3문단**<br>`(독자 #1)`<br>`(내 마음 #1)` | 과세 관청에서 소명 안내문을 여러 차례 보내도 수신인이 <u>여러 사정으로</u> 봉투를 열지 않으면 (...) 내 삶의 구비마다 찾아왔던 <u>숱한 신호들을 그저 우연이나 일상의 긴장으로 치부한 채</u> | 과세 관청에서 소명 안내 **등기 우편**을 여러 차례 보내도 수신인이 **당장 눈앞의 생업이 바쁘다는 이유로, 혹은 봉투 안의 무거운 질문을 마주하기가 두려워** 끝내 봉투를 열지 않으면 (...) **예기치 않게 찾아왔던 몸의 고단함이나 관계의 막막함, 계획대로 풀리지 않던 일터의 멈춤 신호들을 그저 지나가야 할 계절의 피로쯤으로 여긴 채** | *(v1의 구체적 성취 확정 유지)* **과세 관청에서 소명 안내 등기 우편을 여러 차례 보내도 수신인이 당장 눈앞의 생업이 바쁘다는 이유로, 혹은 봉투 안의 무거운 질문을 마주하기가 두려워 끝내 봉투를 열지 않으면** (...) **예기치 않게 찾아왔던 몸의 고단함이나 관계의 막막함, 계획대로 풀리지 않던 일터의 멈춤 신호들을 그저 지나가야 할 계절의 피로쯤으로 여긴 채** |
| **4문단**<br>`(독자 #2)`<br>`[Round 1 역점검]` | 이내 턱 근육이 뻐근해져 왔다. <u>*(징검다리 누락)*</u> 다섯 번의 침묵 뒤에 일곱 번 찍힌 ‘네움 여호와’는 위엄 있는 심판관의 냉정한 관인이 아니었다. | 이내 턱 근육이 뻐근해져 왔다. 단 한 번 말을 삼키며 버티는 내 턱 근육도 이토록 뻐근하고 진이 빠지는데, 다섯 번이나 거절당하면서도 끝내 파기 선고를 삼키신 <u>하나님의 심정은 오죽하셨을까 하는 탄식이 절로 터져 나왔다.</u> *(신파적 과잉)* | 이내 턱 근육이 뻐근해져 왔다. **잠시 말을 꾹 삼키며 버티는 일만으로도 내 턱이 이토록 쉽게 지치는데, 다섯 번의 외면 앞에서도 끝내 절교의 말을 삼키신 아버지의 침묵은 얼마나 묵직했을까.** 다섯 번의 침묵 뒤에 일곱 번 찍힌 ‘네움 여호와’는 위엄 있는 심판관의 냉정한 관인이 아니었다. |
| **5문단**<br>`(내 마음 #2)`<br>`[Round 1 역점검]` | 돌아보니 <u>내 삶의 모든 성취는</u> 내가 이룬 것이 아니라 불붙는 자리에서 나를 빼내신 하나님의 손길이 남긴 구원의 흔적이었다. | 돌아보니 내가 내 힘으로 버텨 내고 일구어 냈다고 믿었던 그 자리들조차, 실은 뜨거운 불길 속에서 나를 건져 올리신 <u>하나님의 불가항력적인 은총이 남긴 기적의 흔적이었다.</u> *(교리적 상투어 유입)* | 돌아보니 **내가 내 힘으로 버텨 내고 일구어 냈다고 믿었던 그 자리들조차, 실은 뜨거운 불길 속으로 손을 뻗어 나를 건져 올리신 하나님의 손길이 남긴 구원의 흔적이었다.** |
| **7문단 말미**<br>`(내 마음 #3)`<br>`[Round 1 역점검]` | <u>그렇게 하나님과 날마다 대면하는 습관만이 모든 인생의 승패를 결정짓는 유일한 열쇠이기 때문이다.</u> *(전형적 보편화·설교 클리셰)* | 우리가 하나님 앞에서 끝내 지켜야 할 것은 무결점의 성적표가 아니라, 부르실 때 언제든 돌아서서 마주 보는 <u>그 진실한 실존의 시선</u> 하나면 충분하기 때문이다. *(번역투 추상어 유입)* | **우리가 하나님 앞에서 끝내 지켜야 할 것은 무결점의 성적표가 아니라, 부르실 때 언제든 고개를 돌려 마주 보는 그 따뜻한 눈맞춤 하나면 충분하기 때문이다.** |
| **8문단 말미**<br>`(독자 #3)`<br>`[Round 2 호흡조율]` | 오랫동안 하얗게 비어 있던 <u>내 회신란에 오늘 아침 아버지가 먼저 늦은 답장 한 줄을 적어 올린다.</u> | 오랫동안 하얗게 비어 있던 내 회신란을 떠올리며, **성경책 옆에 펼쳐 둔 내 묵상 노트의 하얀 여백에 만년필을 들어 내 이름 석 자와 함께 늦은 답장 한 줄을 또박또박 적어 올린다.** | **오랫동안 하얗게 비어 있던 내 회신란을 대신하여, 성경책 옆에 펼쳐 둔 묵상 노트의 빈 여백에 만년필로 내 이름 석 자와 함께 늦은 답장 한 줄을 또박또박 적어 내려간다.** |

---

## [Gate 5 - Round 3] 김익한 5대 평가지표 최종 감리 총평
1. **수월성 (Pass)**: 청풍호 아침 산책의 갈색 솔잎 두 바늘에서 출발하여 세무 서류철의 빈 회신란, 책상을 누르며 말을 삼키는 턱 근육의 감각, 타다 남은 나무 조각을 거쳐 아들의 서른한 번째 생일 축복과 만년필 답장으로 이어지는 8문단 전체가 막힘없이 읽힘.
2. **주체성 (Pass)**: 마르틴 부버와 아브라함 헤셸, 히브리어 원어 구문 4종이 글쓴이를 압도하지 않고, 예순 해를 살아온 아버지이자 세무 실무가인 화자의 고유한 성찰 도구로 완벽히 체화됨.
3. **논리성 (Pass)**: `[솔잎의 두께 → 다섯 통의 미개봉 등기 우편(‘벨로-샤브템 아다이’ 5회) → 빈칸 뒤에 찍힌 아버지의 서명(‘네움 여호와’ 7회) → 건져내심의 수동태(‘무차르’) → 직권 처분 대신 대면으로 부르시는 ‘엘로헤이카’ → 서른한 살 여호수아의 회막과 아들 건우(‘하나님의 친구’)]`의 인과적·신학적 필연성이 빈틈없이 맞물림.
4. **선명성 (Pass)**: ‘밑동이 하나로 묶인 갈색 솔잎 두 바늘’, ‘하얗게 비어 있는 서류철의 회신란’, ‘오른손으로 책상을 도장 찍듯 누른 채 말을 삼킬 때 뻐근해지는 턱 근육’, ‘묵상 노트 여백에 만년필로 적어 내려가는 이름 석 자’ 등 구체적 사물과 신체 감각이 선명히 살아남.
5. **감응성 (Pass)**: 아모스 4장이라는 무거운 본문 속에서 끝내 관계를 포기하지 못하시는 아버지의 서명을 발견하고, 그 마음으로 서른한 살 아들의 생일을 축복하는 부자(父子)의 서사가 깊은 신앙적·인간적 울림을 전함.
"""
        gw_design_path = Path(workspace_root) / "20261109_답장란이_비어_있는_편지철_그_끝에_찍힌_일곱_번의_서명_건우의_서른한_번째_생일_ican_write_설계기록.md"
        gw_design_path.write_text(gw_design_md, encoding="utf-8")

        for target_md in (gw_final_path, gw_draft1_path, gw_design_path):
            out, title, date_str = process_file(str(target_md), template_html, args.suffix, args.cuts)
            print(f"Created: {out}")
            processed_items.append((str(target_md), out, title, date_str))

        gw_top_cards = """        <h2 class="section-title">철학 · 신학 성찰 에세이</h2>
        <div class="list-group">
            <a href="./20261109_답장란이_비어_있는_편지철_그_끝에_찍힌_일곱_번의_서명_건우의_서른한_번째_생일_깊은사고_에세이.html" class="list-item" target="_blank">
                <div class="item-info">
                    <h3>답장란이 비어 있는 편지철, 그 끝에 찍힌 일곱 번의 서명 — 아들 건우의 서른한 번째 생일을 축복하며 (ican-write 다회차 완성본 · A4/모바일 반응형)</h3>
                    <p>청풍호의 갈색 솔잎 두 바늘, 아모스 4장의 다섯 번 빈칸과 일곱 번의 ‘네움 여호와’ 서명, 출애굽기 33:11 ‘하나님의 친구’ 건우에게 건네는 아버지의 축복</p>
                </div>
                <div class="arrow">→</div>
            </a>
            <a href="./20261109_답장란이_비어_있는_편지철_그_끝에_찍힌_일곱_번의_서명_건우의_서른한_번째_생일_깊은사고_에세이.md" class="list-item" target="_blank" download>
                <div class="item-info">
                    <h3>답장란이 비어 있는 편지철, 그 끝에 찍힌 일곱 번의 서명 — 건우의 31번째 생일 (5단계 완성본 MD 다운로드)</h3>
                    <p>옵시디언 및 마크다운 에디터용 원본 문서 (ican-drafter ⇄ ican-evaluator 3라운드 정밀 퇴고 완성본)</p>
                </div>
                <div class="arrow">↓</div>
            </a>
            <a href="./20261109_답장란이_비어_있는_편지철_그_끝에_찍힌_일곱_번의_서명_건우의_서른한_번째_생일_초고1.html" class="list-item" target="_blank">
                <div class="item-info">
                    <h3>답장란이 비어 있는 편지철, 그 끝에 찍힌 일곱 번의 서명 — 건우의 31번째 생일 (4단계 초고 1 · A4/모바일 반응형)</h3>
                    <p>ican-drafter가 3단계 최종 상세설계도(v3)를 바탕으로 집필한 4단계 초고 1 원문 및 본문 연동 3컷 지면</p>
                </div>
                <div class="arrow">→</div>
            </a>
            <a href="./20261109_답장란이_비어_있는_편지철_그_끝에_찍힌_일곱_번의_서명_건우의_서른한_번째_생일_ican_write_설계기록.html" class="list-item" target="_blank">
                <div class="item-info">
                    <h3>[ican-write 이원화·다회차(Round 1~3) 설계·평가 기록] 답장란이 비어 있는 편지철 (A4/모바일 반응형)</h3>
                    <p>ican-drafter ⇄ ican-evaluator의 2단계·3단계·5단계 각 3라운드(v1→v2→v3) 반복 비평·조율 및 구절별 3단 퇴고 대조표</p>
                </div>
                <div class="arrow">→</div>
            </a>
            <a href="./20261109_답장란이_비어_있는_편지철_그_끝에_찍힌_일곱_번의_서명_건우의_서른한_번째_생일_ican_write_설계기록.md" class="list-item" target="_blank" download>
                <div class="item-info">
                    <h3>[ican-write 이원화·다회차(Round 1~3) 설계·평가 기록] 건우의 31번째 생일 에세이 (MD 다운로드)</h3>
                    <p>옵시디언 및 마크다운 에디터용 이원화·다회차 에이전트 설계·평가·퇴고 기록 원본 문서 (.md)</p>
                </div>
                <div class="arrow">↓</div>
            </a>
            <a href="./20261108_복음은_고강도_열정만으로_유지되지_않는다_제천_청풍호반에서_깊은사고_에세이.html\""""

        for repo_name in ("bible-thought", "sparkofbible"):
            idx_p = Path(workspace_root) / repo_name / "index.html"
            if idx_p.exists():
                raw = idx_p.read_text(encoding="utf-8")
                m = re.search(
                    r'\s*<h2 class="section-title">철학 · 신학 성찰 에세이</h2>\s*<div class="list-group">.*?<a href="\./20261108_복음은_고강도_열정만으로_유지되지_않는다_제천_청풍호반에서_깊은사고_에세이\.html"',
                    raw,
                    flags=re.DOTALL,
                )
                if m:
                    raw = raw[: m.start()] + "\n" + gw_top_cards + raw[m.end() :]
                    idx_p.write_text(raw, encoding="utf-8")

    if args.cheongpungho_ican:
        cp_draft1_md = """---
title: "복음은 고강도 열정만으로 유지되지 않는다 — 제천 청풍호반에서 마주한 상처 치유와 평강의 좌표 (초고 1)"
date: 2026-11-08
tags: [제천, 청풍호반, 평강의좌표, 고강도열정, 피로사회, 세미한음성, 초고1]
---

# 복음은 고강도 열정만으로 유지되지 않는다 — 제천 청풍호반에서 마주한 상처 치유와 평강의 좌표

충북 제천의 산자락을 따라 굽이치는 길을 돌아서자, 겹겹이 포개진 능선 사이로 내륙의 바다라 불리는 청풍호가 시야 가득 펼쳐졌다. 바람조차 숨을 고른 듯 잔잔한 수면은 하늘과 산의 그림자를 소리 없이 받아안고 있었다. 늘 시간을 분 단위로 쪼개어 쓰며 처리해야 할 숫자와 서류, 그리고 마주해야 할 사람들의 사연 속에서 앞만 보고 달려오던 걸음이 물가에서 저절로 느려졌다. 호수를 마주하고 서는 것만으로도 그동안 내 안을 가득 채우고 있던 조급한 말들과 분주한 생각들이 물 밑의 모래알처럼 서서히 가라앉기 시작했다.

철학자 한병철은 현대인이 외적 강제가 아니라 스스로를 끊임없이 채찍질하는 과잉활동과 과잉각성 속에서 깊은 피로에 잠식되어 간다고 진단했다(Han, 2010). 멈추어 바라보는 사색적 삶의 능력을 잃어버린 채, 무엇인가를 계속 해내야만 안도하는 시대의 공기가 내 삶에도 예외 없이 스며들어 있었던 것이다. 그러나 눈앞에 펼쳐진 청풍호의 푸른 수면은 감각을 자극하는 화려한 볼거리를 내세우는 대신, 시선을 아득한 수평선 너머로 놓아주며 마음의 긴장을 풀어주었다. 그 깊고 넓은 물결은 지친 어깨를 가볍게 두드리는 일시적인 위로를 넘어, 삶의 무게중심을 다시 세우는 진중하고 평강한 삶으로 들어오라고 나를 조용히 초청하는 것만 같았다.

호숫가의 고요 속에 오래 머물수록, 그동안 바쁘다는 핑계로 외면해 두었던 내면의 생채기들이 하나둘 수면 위로 모습을 드러냈다. 일터에서 마주하는 냉정한 현실의 책임과 강단에서 감당해야 하는 목양의 무게 사이에서, 내 마음에도 어느덧 날카롭게 긁힌 상처와 설명하기 어려운 피로가 쌓여 있었다. 소란한 일상 속에서는 미처 알아채지 못했던 마음의 바닥이, 호수처럼 내면이 잔잔해지고 나서야 비로소 또렷하게 들여다보였다. 상처는 소음 속에서 덮어둔다고 사라지는 것이 아니라, 고요한 성찰의 빛 아래에서 정직하게 마주할 때 비로소 치유의 자리를 찾아간다는 사실을 새삼 깨닫게 되었다.

청풍호가 저토록 맑고 잔잔한 수면을 유지하는 비결은 상류에서 흘러드는 거친 물줄기를 거부하는 데 있지 않다. 비가 내린 뒤 사방의 계곡에서 쏟아져 들어오는 흙탕물과 부유물까지도 마다하지 않고 깊은 수심으로 넉넉히 받아안아, 시간을 들여 침전시키고 정화해 내는 데 있다. 그 넉넉한 품을 바라보며 나는 우리의 내면 또한 삶의 상처를 치유할 평강의 좌표를 본래 보유하고 있음을 생각했다. 상처받지 않는 단단한 껍질을 두르는 것이 성숙이 아니라, 아픔의 파도를 흡수하고 다시 잔잔한 수면으로 되돌아갈 수 있는 내면의 담수량과 기준점을 간직하는 것이 진정한 회복의 힘이기 때문이다.

이 고요한 물가의 성찰은 자연스레 내가 붙들고 살아온 신앙의 결을 돌아보게 했다. 우리는 흔히 신앙의 생명력을 뜨거움의 강도로 측정하곤 한다. 늘 가슴이 벅차오르고, 쉼 없이 사역의 현장을 누비며, 고강도의 열정을 불태워야만 복음에 합당한 삶을 살고 있다고 믿기 쉽다. 열정이 조금이라도 잦아들면 믿음 전체가 식어버린 것처럼 불안해하며 스스로를 몰아세우는 것이다. 그러나 청풍호의 깊고 서늘한 물빛 앞에서 나는 조용히 고백하지 않을 수 없었다. 복음은 결코 고강도 열정만으로 유지되는 것이 아니라는 사실을 말이다.

성경 속 엘리야 선지자의 걸음도 그러했다. 갈멜산에서 하늘의 불을 내리며 바알의 선지자들과 맞섰던 그 뜨거운 열정의 사람도, 극심한 탈진과 두려움 끝에 로뎀나무 아래에 쓰러져 죽기를 구했다. 그때 호렙산에서 그를 다시 일으켜 세운 하나님의 현존은 산을 가르고 바위를 부수는 강한 바람이나 지진이나 타오르는 불 가운데 있지 않았다. 모든 소란이 지나간 뒤 찾아온 세미한 음성, 히브리어 원문의 표현대로라면 부서질 듯 얇은 침묵의 소리(콜 드마마 다카) 가운데 하나님이 계셨다(왕상 19:11-12). 월터 브루그만이 안식을 가리켜 끊임없는 성취와 열정을 강요하는 세상 체제에 맞서는 신앙적 저항이라 불렀듯(Brueggemann, 2014), 하나님 앞에서 잠잠히 멈추어 서는 고요는 열정의 부재가 아니라 복음의 가장 깊은 신뢰가 작동하는 방식이다.

이사야 선지자는 돌이켜 조용히 있어야 구원을 얻을 것이요 잠잠하고 신뢰하여야 힘을 얻을 것이라 증언했다(사 30:15). 빠르게 타오르는 불꽃은 당장은 눈부시지만 금세 재를 남기고 사그라들기 마련이다. 반면 낮고 깊은 곳에 고여 일정한 온도를 지키는 호수의 물은 소리 없이 주변의 숲을 적시고 생명을 길러낸다. 복음이 우리 삶을 끝까지 지탱하는 힘 또한 자극적인 열기의 반복에 있는 것이 아니라, 세상이 줄 수 없는 하나님의 평강이라는 깊은 수심 속에 뿌리를 내리는 데 있다. 열정이 우리를 출발선에서 뛰게 하는 동력이라면, 고요하고 진중한 평강은 그 긴 여정을 중도에 쓰러지지 않고 완주하게 하는 영적 호흡이다.

해 질 녘이 되자 청풍호의 수면 위로 잔잔한 금빛 윤슬이 번져 나갔다. 이제 산자락을 내려가면 다시 숫자와 문장, 사람과 책임이 교차하는 분주한 일상이 나를 기다리고 있을 것이다. 그러나 호숫가를 떠나는 발걸음은 처음 도착했을 때보다 한결 차분하고 단단해졌다. 삶의 파도가 일렁이고 관계의 생채기가 쓰라려 올 때마다, 나는 억지로 열정을 쥐어짜는 대신 내 안에 새겨진 평강의 좌표로 조용히 마음을 돌이킬 것이다. 제천 청풍호반이 건넨 그 무언의 초청처럼, 고강도 열정의 강박을 내려놓고 깊고 고요한 평강의 사람으로 오늘의 자리를 진중하게 살아내고 싶다.
"""
        cp_draft1_path = Path(workspace_root) / "20261108_복음은_고강도_열정만으로_유지되지_않는다_제천_청풍호반에서_초고1.md"
        cp_draft1_path.write_text(cp_draft1_md, encoding="utf-8")

        cp_final_md = """---
title: "복음은 고강도 열정만으로 유지되지 않는다 — 제천 청풍호반에서 마주한 상처 치유와 평강의 좌표 (ican-write 5단계 완성본)"
date: 2026-11-08
tags: [제천, 청풍호반, 평강의좌표, 고강도열정, 피로사회, 세미한음성, ican-write, 성찰에세이]
---

# 복음은 고강도 열정만으로 유지되지 않는다 — 제천 청풍호반에서 마주한 상처 치유와 평강의 좌표

충북 제천의 산자락을 따라 굽이치는 길을 돌아서자, 사방의 봉우리들을 품에 안은 채 거대한 거울처럼 펼쳐진 청풍호반이 시야에 들어왔다. 내륙의 바다라 불릴 만큼 깊고 넉넉한 물결 위로 옥순봉과 구담봉의 기암절벽이 그림자를 드리우고, 호수 건너편 산능선은 수묵화의 담담한 먹선처럼 잔잔하게 이어져 있었다. 물가 나무 데크 난간에 두 손을 얹고 서늘한 물안개를 깊이 들이마시자, 늘 시간을 분 단위로 쪼개어 쓰며 달려오던 걸음이 비로소 그 자리에 멈추어 섰다. 바람 한 줄기에도 호들갑스럽게 일렁이지 않는 그 묵직한 수면 앞에서, 내 안을 채우고 있던 일상의 소음들이 하나둘 물 밑으로 가라앉기 시작했다.

잠시 걸음을 멈추었을 뿐인데도 마음 한구석이 불안해지는 것을 보며, 내가 얼마나 오랜 시간 쉼을 잃어버린 채 살아왔는지를 새삼 깨달았다. 철학자 한병철이 『피로사회』에서 진단했듯, 외적 강제가 아니라 스스로를 끊임없이 채찍질하는 과잉활동과 과잉각성 속에서 나 또한 깊은 피로에 잠식되어 있었던 것이다(Han, 2010). 무언가를 끊임없이 해내고 증명해야 한다는 무언의 압박 속에서, 우리는 멈추어 서서 관조하는 ‘사색적 삶(vita contemplativa)’의 자리를 잃어버린 지 오래다. 그러나 제천 청풍호반이 보여준 고요는 아무것도 하지 않는 무기력한 정지가 아니었다. 그 깊고 넓은 물결은 지친 어깨를 가볍게 두드리는 일시적인 위로를 넘어, 흔들리는 삶의 무게중심을 다시 세우는 진중하고 평강한 삶으로 들어오라고 나를 조용히 초청하고 있었다.

호숫가의 고요 속에 오래 머물수록, 그동안 바쁘다는 핑계로 외면해 두었던 내면의 생채기들이 하나둘 수면 위로 모습을 드러냈다. 오차 없는 숫자와 법리로 시비를 가려야 하는 세무의 책상과, 상한 영혼들의 눈물 섞인 기도제목을 품어야 하는 목양의 강단 사이를 오가며, 내 마음에도 어느덧 작고 깊은 긁힘들이 쌓여 있었다. 사람과의 관계에서 겪은 말 못 할 서운함, 최선을 다했음에도 채워지지 않던 빈자리, 그리고 나 자신의 연약함 때문에 밤늦도록 뒤척이던 자책감까지. 소란스러운 일상 속에서는 미처 돌볼 겨를이 없던 그 상처들이, 아무런 판단 없이 나를 비추어 주는 청풍호의 맑은 물빛 앞에서 비로소 제 아픔의 이름을 되찾고 있었다.

청풍호가 저토록 맑고 잔잔한 수면을 유지하는 비결은 상류에서 흘러드는 거친 물줄기를 거부하는 데 있지 않다. 비가 내린 뒤 사방의 계곡에서 쏟아져 들어오는 흙탕물과 부유물까지도 마다하지 않고 깊은 수심으로 넉넉히 받아안아, 오랜 시간을 들여 침전시키고 정화해 내는 데 있다. 그 넉넉한 수심을 들여다보며 나는 비로소 안도할 수 있었다. 내 안에 남은 상처와 아픔을 조급하게 털어내려 애쓰지 않아도, 하나님이 주신 내면의 깊은 호수 아래로 조용히 가라앉힐 때 다시 맑은 눈으로 삶을 바라볼 ‘평강의 좌표’가 내 안에도 자리하고 있음을 발견했기 때문이다. 상처가 사라져서 평안한 것이 아니라, 상처를 품어 가라앉힐 만큼 내면의 수심이 깊어질 때 비로소 흔들리지 않는 평강이 시작되는 것이었다.

이 고요한 물가의 성찰은 자연스레 내가 붙들고 살아온 신앙의 결을 돌아보게 했다. 우리는 흔히 신앙의 생명력을 뜨거움의 강도로 측정하곤 한다. 쉼 없이 타오르는 사역의 열기, 목소리를 높여 부르짖는 격정적인 간구, 눈에 보이는 가시적인 성취가 있어야만 믿음이 살아 있다고 안심하는 것이다. 그러나 청풍호의 깊고 서늘한 물빛 앞에서 나는 조용히 고백하지 않을 수 없었다. 복음은 결코 고강도 열정만으로 유지되는 것이 아니라는 사실을 말이다. 물론 주님을 향한 뜨거운 헌신은 귀한 은혜이지만, 고요히 머무는 자리를 잃어버린 채 열정의 강도만을 신앙의 척도로 삼을 때 영혼은 머지않아 바닥을 드러내고 만다.

성경 속 엘리야 선지자의 걸음이 이를 여실히 보여준다. 그는 갈멜산에서 하늘의 불을 내리는 최고조의 영적 열정을 경험했지만, 그 직후 찾아온 두려움과 탈진 속에서 광야로 도망쳐 죽기를 구했다. 지쳐 쓰러진 그를 다시 일으켜 세우신 하나님은 호렙산의 크고 강한 바람이나 지진, 타오르는 불길 속에 계시지 않았다. 모든 소란이 지나간 뒤 찾아온 ‘세미한 음성’, 히브리어 원문의 표현대로라면 ‘부서질 듯 얇은 침묵의 소리(콜 드마마 다카)’ 가운데 하나님이 계셨다(왕상 19:11-12). 구약학자 월터 브루그만이 안식을 가리켜 끊임없는 성취와 열정을 강요하는 세상 체제에 맞서는 신앙적 저항이라 불렀듯(Brueggemann, 2014), 내 힘으로 불꽃을 피워 올리려는 조급함을 멈추고 주님의 세미한 음성 앞에 잠잠히 머무는 것이야말로 복음이 우리에게 허락한 참된 능력의 원천이다.

이사야 선지자 또한 조급하게 말을 타고 달려가려는 이들을 향해 “너희가 돌이켜 조용히 있어야 구원을 얻을 것이요 잠잠하고 신뢰하여야 힘을 얻을 것이라”고 증언했다(사 30:15). 빠르게 타오르는 불꽃은 당장은 눈부시지만 금세 재를 남기고 사그라들기 마련이다. 반면 수면 아래로 깊은 물줄기를 간직한 호수는 가뭄의 계절에도 쉬이 마르지 않는다. 복음의 생명력도 이와 같아서, 감정의 고양이나 일시적인 열광이 아니라 삶의 굴곡과 상처를 통과하면서도 주님의 주권을 잠잠히 신뢰하는 평강의 바탕 위에서 비로소 오래도록 지속된다. 열정이 우리를 출발선에서 뛰게 하는 동력이라면, 고요하고 진중한 평강은 그 긴 여정을 중도에 쓰러지지 않고 완주하게 하는 영적 호흡이다.

해 질 녘이 되자 청풍호의 수면 위로 잔잔한 금빛 윤슬이 번져 나갔다. 호수를 뒤로하고 다시 숫자와 서류, 그리고 사람들의 사연이 기다리는 일상의 자리로 돌아가야 할 시간이었지만, 발걸음은 처음 이곳을 찾았을 때보다 한결 가볍고 단단해져 있었다. 내 삶에 다시 거친 비바람이 불고 예기치 못한 생채기가 남는다 해도, 나는 이제 내 안에 심겨진 이 고요한 호수의 수심을 기억할 것이다. 제천 청풍호반이 건넨 그 무언의 초청처럼, 고강도 열정의 강박을 내려놓고 상처를 품어 정화하는 깊고 고요한 평강의 사람으로 오늘의 자리를 진중하게 살아내고 싶다.
"""
        cp_final_path = Path(workspace_root) / "20261108_복음은_고강도_열정만으로_유지되지_않는다_제천_청풍호반에서_깊은사고_에세이.md"
        cp_final_path.write_text(cp_final_md, encoding="utf-8")

        cp_design_md = """---
title: "[ican-write 이원화 에이전트 설계·평가 기록] 복음은 고강도 열정만으로 유지되지 않는다 — 제천 청풍호반에서"
date: 2026-11-08
tags: [ican-write, ican-drafter, ican-evaluator, 청풍호반, 평강의좌표, 고강도열정, 5단계설계기록]
---

# [ican-write 이원화 에이전트 설계·평가 기록] 복음은 고강도 열정만으로 유지되지 않는다 — 제천 청풍호반에서

본 문서는 진행·집필 전담 에이전트(**`ican-drafter`**)가 생성한 단계별 복수 선택안(A/B/C안) 및 초고 1과, 분리된 독립 평가·결정 전담 에이전트(**`ican-evaluator`**)가 수행한 **Gate 1 ~ Gate 5 비교 심사 및 최종 선택 결정** 전 과정을 기록한 문서입니다.

---

## [1단계] 글감 발견과 생각 확장 (`ican-drafter` 후보 도출 ⇄ `ican-evaluator` Gate 1 결정)

### 1-1. `ican-drafter` 글감 후보 3안 및 학술·신학 자료 후보 4종 제출
* **글감 후보 A안 (관찰·성찰 중심)**: "충북 제천 청풍호반의 흔들림 없는 수면을 마주하며, 소란한 일상을 잠시 멈추고 진중하고 고요한 평강의 삶으로 건너가는 내면의 시간을 성찰한다."
* **글감 후보 B안 (고강도 열정과 복음의 지속성 질문 중심)**: "청풍호의 깊고 고요한 물결 앞에서, 쉼 없이 타오르는 고강도 열정만으로 신앙과 삶을 지탱하려 했던 조급함을 내려놓고 복음이 지닌 고요한 지속성과 평강의 좌표를 성찰한다."
* **글감 후보 C안 (상처 치유와 평강의 좌표 중심)**: "삶의 생채기와 피로를 안고 찾은 제천 청풍호반에서, 상처 입은 마음을 다독이고 다시 살아갈 힘을 회복하게 하는 내면의 평강 좌표를 탐색한다."
* **학술·신학 자료 후보 4종**:
  1. **한병철, 『피로사회』(2010)**: 자기 착취적 과잉활동(Hyperactivity)과 사색적 삶(vita contemplativa)의 상실
  2. **월터 브루그만, 『안식일은 저항이다』(2014)**: 끊임없는 성취·열정 강박 체제에 맞서는 신앙적 저항으로서의 안식
  3. **월리스 니콜스, 『블루 마인드』(2014) & 카플란 주의회복이론(1989)**: 블루 스페이스가 뇌의 통제된 주의력 피로를 낮추는 효과
  4. **열왕기상 19:11-12 & 이사야 30:15**: 갈멜산의 불길 뒤 탈진한 엘리야에게 임한 호렙산의 ‘세미한 음성(콜 드마마 다카)’과 잠잠한 신뢰

### 1-2. `ican-evaluator` [Gate 1] 비교 심사 및 최종 선택 결정
* **글감 심사 판정**:
  * **A안 기각**: 풍경의 서정성은 좋으나 일반 기행 수필에서도 흔히 볼 수 있는 구도여서 통념을 깨뜨리는 날카로운 질문이 부족함.
  * **C안 기각**: 심리적 치유에만 머물 경우 ‘복음은 고강도 열정만으로 유지되지 않는다’는 독창적 신학 성찰까지 끌고 가기에는 추동력이 약함.
  * **최종 채택 (B안 + C안의 ‘상처 치유’ 결합)**:
    > **"충북 제천 청풍호의 깊고 고요한 물결 앞에서, 쉼 없이 타오르는 고강도 열정만으로 신앙과 삶을 지탱하려 했던 조급함을 내려놓고 상처를 품어 정화하는 복음의 고요한 지속성과 평강의 좌표를 성찰한다."**
* **학술·신학 자료 채택 결정 (3종 채택 / 1종 본문 제외)**:
  * **채택**: ① 한병철 『피로사회』(2010), ② 열왕기상 19:11-12(콜 드마마 다카) & 이사야 30:15, ③ 월터 브루그만 『안식일은 저항이다』(2014).
  * **본문 실명 인용 제외**: 월리스 니콜스 『블루 마인드』 & 카플란 주의회복이론 — 짧은 에세이에 뇌과학·환경심리학 용어까지 실명으로 나열하면 현학적으로 변질되므로, 이론 명칭 없이 1·4문단의 호수 묘사 감각으로만 녹여내도록 결정.

---

## [2단계] 핵심 메시지 정립과 독자 중심 목차 설계 (`ican-drafter` 대안 설계 ⇄ `ican-evaluator` Gate 2 결정)

### 2-1. `ican-drafter` 핵심 메시지 3안 · 제목 3안 · 목차 2안 제출
* **핵심 메시지 후보**: A안(성찰·초청형) / B안(고강도 열정을 넘어 평강의 좌표 위에서 지속되는 복음과 삶) / C안(상처 치유와 회복형)
* **제목 후보**:
  * A안: `청풍호반에서 마주한 고요의 깊이 — 분주한 일상을 멈추고 진중한 평강의 삶으로 건너가는 시간`
  * B안: `복음은 고강도 열정만으로 유지되지 않는다 — 제천 청풍호반에서 마주한 상처 치유와 평강의 좌표`
  * C안: `내 안에 고요한 호수 하나를 품는 일 — 뜨거운 열정의 시대를 건너는 이들을 위한 평강의 좌표`
* **목차 후보**: 목차 A안(경험·성찰형 4장 8절) vs 목차 B안(경험·성찰 + 철학·신학 해석 결합형 4장 12절)

### 2-2. `ican-evaluator` [Gate 2] 비교 심사 및 최종 선택 결정
* **핵심 메시지 확정 (B안 + C안 결합)**:
  > **"참된 삶과 복음의 생명력은 쉼 없이 타오르는 고강도 열정만으로 유지되는 것이 아니라, 삶의 상처를 넉넉히 품어 침전시키고 고요한 신뢰 속에서 자리를 지키는 내면의 ‘평강 좌표’ 위에서 비로소 지속된다."**
* **최종 제목 확정 (B안 채택)**:
  > **`복음은 고강도 열정만으로 유지되지 않는다 — 제천 청풍호반에서 마주한 상처 치유와 평강의 좌표`**
* **2단 목차 확정 (목차 B안 4장 12절 채택)**:
  * 린다 플라워의 독자 중심 원칙 및 목차 3대 속성(연결성·논리성·설득성) 심사 결과, 단순 감상 나열인 목차 A안보다 **경험(청풍호 수면) → 진단(피로사회) → 전환(수심의 침전과 평강 좌표) → 신학적 논증(엘리야의 세미한 음성과 안식의 저항) → 일상의 귀환**으로 이어지는 목차 B안의 인과 구조가 월등히 설득력 있으므로 최종 채택.

---

## [3단계] A4 상세설계도 및 본문 연동 컷 설계 (`ican-drafter` 작성 ⇄ `ican-evaluator` Gate 3 승인)

* **제1장. 청풍호반의 초청: 과잉각성의 시간을 멈추고 마주한 고요** (1-1절 제천 산세와 청풍호 수면 / 1-2절 피로사회의 과잉활동과 사색적 삶 / 1-3절 진중하고 평강한 삶으로 부르는 초청장)
  * **Page 001 확정 컷 (`cheongpungho_mirror_invitation`)**: 옥순봉·구담봉 능선과 거울처럼 잔잔한 청풍호 수면, 물가 데크에 멈추어 선 고요한 뒷모습
* **제2장. 평강의 좌표: 삶의 상처를 삼키고 정화하는 내면의 담수량** (2-1절 세무의 책상과 목양의 강단 사이에서 긁힌 상처 직면 / 2-2절 거친 물줄기와 부유물을 깊은 수심으로 침전시키는 호수의 치유 원리 / 2-3절 영혼의 영점을 조율하는 평강의 좌표)
  * **Page 002 확정 컷 (`cheongpungho_shalom_coordinates`)**: 거친 물줄기를 깊은 수심으로 침전시키는 청풍호와 동심원 수면 위에 겹쳐진 평강의 좌표
* **제3장. 열정의 역설: 복음은 고강도 열정만으로 유지되지 않는다** (3-1절 뜨거움의 강도로 믿음을 증명하려던 피로 / 3-2절 갈멜산의 불길 뒤편 호렙산의 ‘세미한 음성(콜 드마마 다카)’ / 3-3절 안식의 저항과 잠잠한 신뢰)
* **제4장. 일상의 귀환: 진중한 평강을 삶의 체질로 새기며** (4-1절 불꽃의 열기에서 깊은 물의 영성으로 / 4-2절 삶의 파도 앞에서 내면의 청풍호반으로 돌아가는 멈춤 / 4-3절 해 질 녘 금빛 윤슬과 평강의 다짐)
  * **Page 003 확정 컷 (`cheongpungho_whisper_golden_ripples`)**: 호렙산의 세미한 음성처럼 해 질 녘 청풍호의 잔잔한 수면 위로 번져 나가는 금빛 윤슬

---

## [4단계 & 5단계] `ican-evaluator` Gate 4 정밀 진단 및 Gate 5 변증법적 퇴고 대조표

| 구간 | `ican-drafter` 4단계 초고 1 (교정 전) | `ican-evaluator` [Gate 4] `(독자)` / `(내 마음)` 진단 및 지시 | [Gate 5] 최종 승인 완성 원고 (교정 후) |
| :--- | :--- | :--- | :--- |
| **1·3문단** | 늘 시간을 분 단위로 쪼개어 쓰며 처리해야 할 <u>숫자와 서류</u>... / <u>일터에서 마주하는 냉정한 현실의 책임</u>과 강단에서 감당해야 하는 목양의 무게 사이에서 | **(내 마음 #1 · 구체적 동작 및 경험 복원)** 호숫가에 도착했을 때의 첫 신체 동작과 촉각을 보완하고, ‘숫자와 서류’, ‘냉정한 현실의 책임’이라는 추상 명사를 글쓴이 고유의 구체적 삶의 자리(세무의 책상과 목양의 강단)로 복원할 것. | **물가 나무 데크 난간에 두 손을 얹고 서늘한 물안개를 깊이 들이마시자**, 늘 시간을 분 단위로 쪼개어 쓰며 달려오던 걸음이 비로소 그 자리에 멈추어 섰다. / **오차 없는 숫자와 법리로 시비를 가려야 하는 세무의 책상과, 상한 영혼들의 눈물 섞인 기도제목을 품어야 하는 목양의 강단 사이를 오가며**... |
| **2문단** | <u>철학자 한병철은 현대인이 외적 강제가 아니라 스스로를 끊임없이 채찍질하는 과잉활동과 과잉각성 속에서 깊은 피로에 잠식되어 간다고 진단했다(Han, 2010).</u> | **(독자 #1 · 학술 인용 돌출 방지 징검다리)** 1문단의 서정적 몰입 직후 2문단 첫머리에 학술 인용이 불쑥 나오면 거리감이 생김. 먼저 걸음을 멈추었을 때 밀려오는 내면의 불안을 자각하는 징검다리 문장을 앞에 둘 것. | **잠시 걸음을 멈추었을 뿐인데도 마음 한구석이 불안해지는 것을 보며, 내가 얼마나 오랜 시간 쉼을 잃어버린 채 살아왔는지를 새삼 깨달았다.** 철학자 한병철이 『피로사회』에서 진단했듯, 외적 강제가 아니라 스스로를 끊임없이 채찍질하는 과잉활동과 과잉각성 속에서 나 또한 깊은 피로에 잠식되어 있었던 것이다(Han, 2010). |
| **4문단** | 그 넉넉한 품을 바라보며 <u>나는 우리의 내면 또한 삶의 상처를 치유할 평강의 좌표를 본래 보유하고 있음을 생각했다.</u> | **(내 마음 #2 · 보편 명제의 1인칭 실존화)** ‘우리의 내면 또한 ~ 보유하고 있음을 생각했다’는 제3자적 해설문 어투를 걷어내고, 상처를 조급히 털어내려 애쓰지 않아도 된다는 1인칭 실존의 안도와 발견으로 벼려 낼 것. | 그 넉넉한 수심을 들여다보며 나는 비로소 안도할 수 있었다. **내 안에 남은 상처와 아픔을 조급하게 털어내려 애쓰지 않아도, 하나님이 주신 내면의 깊은 호수 아래로 조용히 가라앉힐 때 다시 맑은 눈으로 삶을 바라볼 ‘평강의 좌표’가 내 안에도 자리하고 있음을 발견했기 때문이다.** |
| **5·6문단** | 복음은 결코 고강도 열정만으로 유지되는 것이 아니라는 사실을 말이다. / 성경 속 엘리야 선지자의 걸음도 그러했다. | **(독자 #2 · 예상 반문 해소)** 성실히 헌신해 온 독자가 ‘열정 자체를 부정하는가?’라고 오해하지 않도록, 뜨거운 헌신의 가치를 인정하되 ‘고요히 머무는 자리를 잃고 열정의 강도만을 척도로 삼을 때의 탈진’을 경계하는 문장을 보완할 것. | 복음은 결코 고강도 열정만으로 유지되는 것이 아니라는 사실을 말이다. **물론 주님을 향한 뜨거운 헌신은 귀한 은혜이지만, 고요히 머무는 자리를 잃어버린 채 열정의 강도만을 신앙의 척도로 삼을 때 영혼은 머지않아 바닥을 드러내고 만다.** / 성경 속 엘리야 선지자의 걸음이 이를 여실히 보여준다. |
"""
        cp_design_path = Path(workspace_root) / "20261108_복음은_고강도_열정만으로_유지되지_않는다_제천_청풍호반에서_ican_write_설계기록.md"
        cp_design_path.write_text(cp_design_md, encoding="utf-8")

        for target_md in (cp_final_path, cp_draft1_path, cp_design_path):
            out, title, date_str = process_file(str(target_md), template_html, args.suffix, args.cuts)
            print(f"Created: {out}")
            processed_items.append((str(target_md), out, title, date_str))

        cp_top_cards = """        <h2 class="section-title">철학 · 신학 성찰 에세이</h2>
        <div class="list-group">
            <a href="./20261108_복음은_고강도_열정만으로_유지되지_않는다_제천_청풍호반에서_깊은사고_에세이.html" class="list-item" target="_blank">
                <div class="item-info">
                    <h3>복음은 고강도 열정만으로 유지되지 않는다 — 제천 청풍호반에서 마주한 상처 치유와 평강의 좌표 (ican-write 5단계 완성본 · A4 1단 지면)</h3>
                    <p>제천 청풍호반의 고요와 내면의 담수량, 피로사회(Han, 2010)와 호렙산의 세미한 음성(왕상 19:12), 안식의 저항(Brueggemann, 2014)을 담은 성찰 에세이</p>
                </div>
                <div class="arrow">→</div>
            </a>
            <a href="./20261108_복음은_고강도_열정만으로_유지되지_않는다_제천_청풍호반에서_깊은사고_에세이.md" class="list-item" target="_blank" download>
                <div class="item-info">
                    <h3>복음은 고강도 열정만으로 유지되지 않는다 — 제천 청풍호반에서 (5단계 완성본 MD 다운로드)</h3>
                    <p>옵시디언 및 마크다운 에디터용 원본 문서 (ican-drafter ⇄ ican-evaluator Gate 5 최종 탈고본)</p>
                </div>
                <div class="arrow">↓</div>
            </a>
            <a href="./20261108_복음은_고강도_열정만으로_유지되지_않는다_제천_청풍호반에서_초고1.html" class="list-item" target="_blank">
                <div class="item-info">
                    <h3>복음은 고강도 열정만으로 유지되지 않는다 — 제천 청풍호반에서 (4단계 초고 1 · A4 1단 지면)</h3>
                    <p>ican-drafter가 3단계 상세설계도(4장 12절)를 바탕으로 집필한 4단계 초고 1 원문 및 본문 연동 3컷 지면</p>
                </div>
                <div class="arrow">→</div>
            </a>
            <a href="./20261108_복음은_고강도_열정만으로_유지되지_않는다_제천_청풍호반에서_ican_write_설계기록.html" class="list-item" target="_blank">
                <div class="item-info">
                    <h3>[ican-write 이원화 에이전트 설계·평가 기록] 복음은 고강도 열정만으로 유지되지 않는다 (A4 1단 지면)</h3>
                    <p>ican-drafter 단계별 복수 후보안(A/B/C안) 도출 ⇄ ican-evaluator Gate 1~5 비교 심사·선택 결정 및 퇴고 대조표</p>
                </div>
                <div class="arrow">→</div>
            </a>
            <a href="./20261108_복음은_고강도_열정만으로_유지되지_않는다_제천_청풍호반에서_ican_write_설계기록.md" class="list-item" target="_blank" download>
                <div class="item-info">
                    <h3>[ican-write 이원화 에이전트 설계·평가 기록] 제천 청풍호반 에세이 (MD 다운로드)</h3>
                    <p>옵시디언 및 마크다운 에디터용 이원화 에이전트 설계·평가·결정 기록 원본 문서 (.md)</p>
                </div>
                <div class="arrow">↓</div>
            </a>
            <a href="./20261107_한_알의_밀알_궁멀에_묻힌_사랑_군산_선교사_묘역에서_깊은사고_에세이.html\""""

        for repo_name in ("bible-thought", "sparkofbible"):
            idx_p = Path(workspace_root) / repo_name / "index.html"
            if idx_p.exists():
                raw = idx_p.read_text(encoding="utf-8")
                m = re.search(
                    r'\s*<h2 class="section-title">철학 · 신학 성찰 에세이</h2>\s*<div class="list-group">.*?<a href="\./20261107_한_알의_밀알_궁멀에_묻힌_사랑_군산_선교사_묘역에서_깊은사고_에세이\.html"',
                    raw,
                    flags=re.DOTALL,
                )
                if m:
                    raw = raw[: m.start()] + "\n" + cp_top_cards + raw[m.end() :]
                    idx_p.write_text(raw, encoding="utf-8")

    if args.gunsan_ican:
        gunsan_draft1_md = """---
title: "한 알의 밀알, 궁멀에 묻힌 사랑 — 군산 선교사 묘역에서 (초고 1)"
date: 2026-11-07
tags: [군산선교역사관, 구암동산, 전킨선교사, 궁멀, 한알의밀알, 초고1]
---

# 한 알의 밀알, 궁멀에 묻힌 사랑 — 군산 선교사 묘역에서

군산선교역사관 뒤편으로 난 완만한 오르막을 따라 걸음을 옮기면 늦가을의 고요가 내려앉은 구암동산 묘역이 나타난다. 옛 구암교회 터전 위에 복원된 이곳에는 구한말 호남 땅에 복음의 첫 씨앗을 뿌린 네 가문의 선교사 부부들이 나란히 잠들어 있다. 투박한 회색 화강암 비석 앞에는 누군가 다녀가며 놓고 간 흰 국화 한 송이가 묵묵히 놓여 있었고, 서늘한 가을바람이 불 때마다 노란 은행잎들이 소리 없이 잔디밭 위로 흩날렸다.

발걸음을 멈추고 전킨(William M. Junkin, 한국명 전위렴) 선교사 부부의 비석 앞에 섰을 때, 시선은 자연스레 큰 비석 아래 발치로 향했다. 그곳 잔디밭 위에는 조지, 시드니, 프랜시스라는 이름이 새겨진 세 개의 작은 평면 묘석이 나란히 누워 있었다. 1893년에 태어나 이듬해 숨진 첫째 조지는 생후 8개월, 1899년의 둘째 시드니는 생후 2개월, 그리고 1903년의 셋째 프랜시스는 태어난 지 불과 스무 날 만에 세상을 떠났다. 전기도 제대로 된 약도 없던 시절, 거친 갯벌 바람과 풍토병 속에서 차례로 품 안의 핏줄을 차가운 이국의 흙에 묻어야 했던 부모의 피눈물이 짧은 숫자들 너머로 먹먹하게 전해졌다.

세 개의 작은 돌 앞에서 한동안 자리를 뜨지 못한 채 스스로에게 물었다. 왜 그들은 고향으로 돌아가지 않았을까. 첫째 아기가 숨을 거두었을 때만 해도 짐을 쌀 이유는 충분했고, 둘째를 잃었을 때는 누구도 그들의 귀국을 탓할 수 없었을 것이다. 그러나 그들은 셋째 아기마저 스무 날 만에 땅에 묻고도 끝내 조선 땅 궁멀을 떠나지 않았다. 세상 사람들의 눈에는 자식을 셋이나 사지로 몰아넣고 방치한 ‘비정한 부모’처럼 보였을지도 모른다. “너희가 믿는 신이 과연 자식을 이렇게 빼앗아 가느냐”는 안팎의 냉소 속에서 그들이 견뎌야 했을 영적 고독은 가늠하기조차 어렵다.

그러나 그 자리는 비정함의 자리가 아니라, 십자가 앞에 드린 온전한 항복의 자리였다. 독일의 신학자 디트리히 본회퍼는 그리스도를 따르는 길을 값싼 감상이 아닌, 자신의 가장 소중한 것까지 제단에 올려놓는 ‘값비싼 제자도(Costly Discipleship)’라 불렀다(Bonhoeffer, 1937). 전킨 선교사 부부가 조선을 떠나지 못한 까닭은 자식에 대한 사랑이 모자라서가 아니었다. 억장이 무너지는 단장(斷腸)의 슬픔 한복판에서도, 주권자이신 하나님 앞에 무릎을 꿇고 자신들의 삶과 아픔까지 통째로 내어맡긴 절대적인 사랑과 항복이 그들을 붙들고 있었던 것이다.

그 항복의 깊이는 전킨 선교사가 마흔셋의 젊은 나이로 생을 마감하며 남긴 마지막 유언에서 더욱 선명히 드러난다. 1908년 1월, 과로와 장티푸스로 전주에서 숨을 거두며 그는 “나는 궁멀 전씨다. 내가 죽으면 군산 궁멀에 묻어달라”는 말을 남겼다. 유언에 따라 전주에서 군산까지 운구된 아버지의 시신은 먼저 묻힌 세 아들의 곁에 나란히 누웠다. 남아프리카의 선교학자 데이비드 보쉬가 말했듯, 참된 선교란 높은 자리에서 시혜를 베푸는 것이 아니라 언어와 문화, 질병과 죽음의 장벽을 뛰어넘어 그 땅의 사람과 하나가 되는 ‘성육신적 선교(Incarnational Mission)’이다(Bosch, 1991). 미국 버지니아 고향의 흙과 군산 궁멀의 흙을 함께 담아 안장한 오늘날의 묘비는, 이방인으로 왔으나 조선의 흙이 되기를 자처했던 그 큰 사랑을 증언하고 있다.

묘역 한가운데 서 있는 기념비에는 요한복음 12장 24절 말씀이 깊이 새겨져 있다. “내가 진실로 진실로 너희에게 이르노니 한 알의 밀이 땅에 떨어져 죽지 아니하면 한 알 그대로 있고 죽으면 많은 열매를 맺느니라.” 궁멀의 차가운 땅속에 떨어져 죽은 네 부자의 밀알은 결코 헛되지 않았다. 그들이 흘린 눈물과 땀방울 위에서 구암교회가 세워졌고, 영명학교와 멜볼딘여학교를 통해 인재들이 자라났으며, 병든 이들을 고치는 치유의 역사가 시작되었다. 그리고 마침내 그 생명의 씨앗은 한강 이남 최초의 3·5 만세운동이라는 거대한 함성으로 피어났다.

2026년 늦가을, 함께 구암동산을 찾은 온비아 BEE 찻사찻 일행과 ‘군산선교역사관’ 표지석이 놓인 계단에 둘러서서 한 장의 사진을 남겼다. 따스한 가을 햇살 아래 환하게 미소 짓는 우리들의 모습 뒤편으로, 130년 전 선교사들의 무덤이 말없이 우리 발밑을 떠받치고 있었다. 오늘 우리가 당연하게 누리는 신앙의 자유와 배움의 기회, 그리고 풍요로운 삶의 터전이 실은 누군가의 자식들이 흘린 피눈물 위에 세워졌다는 사실 앞에서 거룩한 부끄러움이 밀려왔다.

비장한 순교의 시대는 지났을지라도, 빚진 자로서 그 역사를 기억하며 살아내는 일은 오늘 우리의 몫으로 남아 있다. 거창한 구호를 외치는 대신, 내가 서 있는 일터와 가정에서 나를 부인하고 내 곁의 사람을 묵묵히 섬기는 것이야말로 이 시대의 밀알로 사는 길일 것이다. 은행잎이 흩날리는 구암동산을 내려오며 마음속으로 나직한 기도를 올렸다. 주님 앞에 내 고집과 욕심을 항복하고, 그들이 남긴 밀알의 생명을 오늘 내 일상에서 가치 있게 살아내게 하소서.
"""
        gunsan_draft1_path = Path(workspace_root) / "20261107_한_알의_밀알_궁멀에_묻힌_사랑_군산_선교사_묘역에서_초고1.md"
        gunsan_draft1_path.write_text(gunsan_draft1_md, encoding="utf-8")

        gunsan_final_md = """---
title: "한 알의 밀알, 궁멀에 묻힌 사랑 — 군산 선교사 묘역에서 (ican-write 5단계 완성본)"
date: 2026-11-07
tags: [군산선교역사관, 구암동산, 전킨선교사, 궁멀, 한알의밀알, ican-write, 성찰에세이]
---

# 한 알의 밀알, 궁멀에 묻힌 사랑 — 군산 선교사 묘역에서

군산선교역사관 뒤편으로 난 완만한 오르막을 따라 걸음을 옮기면 늦가을의 고요가 내려앉은 구암동산 묘역이 나타난다. 옛 구암교회 3·1운동 역사명상관 뒤편 언덕에 복원된 이곳에는, 구한말 호남 땅에 복음의 첫 씨앗을 뿌린 네 가문의 선교사 부부들이 나란히 잠들어 있다. 투박한 회색 화강암 비석 앞에는 누군가 다녀가며 놓고 간 흰 국화 한 송이가 묵묵히 놓여 있었고, 서늘한 가을바람이 스칠 때마다 노란 은행잎들이 소리 없이 잔디밭 위로 내려앉았다.

발걸음을 멈추고 전킨(William M. Junkin, 한국명 전위렴) 선교사 부부의 비석 앞에 섰을 때, 시선은 자연스레 큰 비석 발치로 향했다. 그곳 잔디밭에는 땅바닥과 거의 같은 높이로 누운 세 개의 작은 평면 묘석이 나란히 박혀 있었다. 무릎을 굽히고 허리를 숙여야만 비로소 조지, 시드니, 프랜시스라는 세 아기의 이름이 눈에 들어왔다. 1893년에 태어나 이듬해 숨진 첫째 조지는 생후 8개월, 1899년의 둘째 시드니는 생후 2개월, 그리고 1903년의 셋째 프랜시스는 태어난 지 불과 스무 날 만에 세상을 떠났다. 전기도, 변변한 약 한 첩도 없던 구한말 군산 앞바다의 거친 갯벌 바람 속에서 차례로 품 안의 핏줄을 식혀 보내야 했던 부모의 피눈물이, 채 돌도 넘기지 못하고 멈추어버린 숫자들 너머로 먹먹하게 전해졌다.

세 개의 작은 돌 앞에서 한동안 몸을 일으키지 못한 채 스스로에게 물었다. 왜 그들은 고향으로 돌아가지 않았을까. 첫째 아기가 숨을 거두었을 때만 해도 짐을 쌀 명분은 충분했고, 둘째를 잃었을 때는 그 누구도 그들의 귀국을 탓할 수 없었을 것이다. 그러나 그들은 셋째 아기마저 스무 날 만에 낯선 흙에 묻고도 끝내 조선 땅을 떠나지 않았다. 세상 사람들의 눈에는 자식을 셋이나 사지로 몰아넣고도 고집스레 자리를 지킨 ‘비정한 부모’처럼 보였을지 모른다. “너희가 믿는 신이 과연 자식을 이렇게 빼앗아 가느냐”는 안팎의 냉소 속에서, 그들 자신도 밤마다 가슴을 치며 무너져 내렸을 것이다.

부모에게 어찌 단장(斷腸)의 고통이 없었겠는가. 그러나 그 자리는 비정함의 자리가 아니라, 십자가 앞에 드린 온전한 항복의 자리였다. 독일의 신학자 디트리히 본회퍼는 그리스도를 따르는 길을 값싼 감상이 아닌, 자신의 가장 소중한 것까지 제단에 올려놓는 ‘값비싼 제자도(Costly Discipleship)’라 불렀다(Bonhoeffer, 1937). 전킨 선교사 부부가 조선을 떠나지 못한 까닭은 자식에 대한 사랑이 모자라서가 아니라, 억장이 무너지는 슬픔 한복판에서도 주권자이신 하나님 앞에 무릎을 꿇고 자신들의 아픔까지 통째로 내어맡긴 더 큰 사랑과 항복이 그들을 붙들고 있었기 때문이다.

그 항복의 깊이는 전킨 선교사가 마흔셋의 나이로 생을 마감하며 남긴 마지막 유언에서 더욱 선명히 드러난다. 풍토병과 과로에 시달리다 1908년 1월 전주에서 장티푸스로 숨을 거두며 그는 “나는 궁멀 전씨다. 내가 죽으면 군산 궁멀에 묻어달라”는 말을 남겼다. 구암동의 옛 이름인 ‘궁멀’을 자신의 본관으로 삼아 조선 사람으로 죽기를 자처한 것이다. 유언을 따라 전주에서 군산까지 모셔온 아버지의 시신은 먼저 묻어두었던 세 아들의 작은 무덤 곁에 나란히 누웠다. 선교학자 데이비드 보쉬가 규명했듯, 참된 선교란 높은 곳에서 시혜를 베푸는 것이 아니라 언어와 문화, 질병과 죽음의 공포라는 모든 장벽을 뛰어넘어 그 땅의 사람과 하나가 되는 ‘성육신적 선교(Incarnational Mission)’이다(Bosch, 1991). 미국 버지니아 고향의 흙과 군산 궁멀의 흙을 함께 유골함에 담아 안장한 오늘날의 묘비는, 이방인으로 왔으나 마침내 조선의 흙이 된 성육신적 사랑을 조용히 증언하고 있다.

묘역 한가운데 서 있는 기념비에는 요한복음 12장 24절 말씀이 깊이 새겨져 있다. “내가 진실로 진실로 너희에게 이르노니 한 알의 밀이 땅에 떨어져 죽지 아니하면 한 알 그대로 있고 죽으면 많은 열매를 맺느니라.” 궁멀의 차가운 흙 속에 떨어져 죽은 아버지와 세 아들의 밀알은 결코 땅속에 묻힌 채 끝나지 않았다. 그들이 쏟은 눈물과 피땀 위에서 구암교회가 일어섰고, 영명학교(현 군산제일고)와 멜볼딘여학교(현 군산영광여고)의 교실마다 조선의 다음 세대가 자라났으며, 병든 이들을 돌보는 예수병원의 치유 사역이 뻗어 나갔다. 그리고 마침내 그 생명의 뿌리는 1919년 한강 이남 최초의 군산 3·5 만세운동이라는 뜨거운 함성으로 피어났다.

2026년 늦가을, 함께 구암동산을 찾은 온비아 BEE 찻사찻 일행과 ‘군산선교역사관’ 표지석이 놓인 계단에 둘러서서 한 장의 사진을 남겼다. 따스한 가을 햇살 아래 환하게 미소 짓는 우리들의 얼굴 뒤편으로, 130년 전 선교사들의 무덤이 말없이 우리 발밑을 떠받치고 있었다. 오늘 우리가 공기처럼 당연하게 누리는 예배의 자유와 배움의 기회, 그리고 일상의 평안이 실은 스무 날 남짓 숨 쉬다 떠난 아기들과 젊은 선교사 부부의 피눈물 위에 세워졌다는 사실 앞에서 숙연한 부끄러움이 밀려왔다.

비장한 순교의 시대는 지났을지라도, 거저 받은 사랑에 빚진 자로서 그 역사를 기억하고 살아내는 일은 오늘 내 몫으로 남아 있다. 거창한 구호를 외치지 않더라도, 내게 맡겨진 일터와 가정에서 내 몫의 손해를 기꺼이 감수하며 곁에 있는 한 사람을 품어내는 것이 오늘 내가 감당할 작은 밀알의 걸음일 것이다. 은행잎이 흩날리는 구암동산 계단을 내려오며 마음속으로 나직한 기도를 올렸다. 주님, 비정해 보일 만큼 아픈 자리에서도 끝내 사랑으로 항복했던 저들의 믿음을 잊지 않게 하시고, 내 안의 고집과 욕심을 내려놓아 오늘 내 일상에서 그들이 남긴 밀알의 생명을 살아내게 하소서.
"""
        gunsan_final_path = Path(workspace_root) / "20261107_한_알의_밀알_궁멀에_묻힌_사랑_군산_선교사_묘역에서_깊은사고_에세이.md"
        gunsan_final_path.write_text(gunsan_final_md, encoding="utf-8")

        gunsan_design_md = """---
title: "[ican-write 1~5단계 설계기록] 한 알의 밀알, 궁멀에 묻힌 사랑 — 군산 선교사 묘역에서"
date: 2026-11-07
tags: [ican-write, 어나더레벨글쓰기, 군산선교역사관, 구암동산, 전킨선교사, 5단계설계기록]
---

# [ican-write 1~5단계 설계기록] 한 알의 밀알, 궁멀에 묻힌 사랑 — 군산 선교사 묘역에서

---

## [1단계] 글감 발견과 생각 확장 (1강 STEP 1~2)

### 1-1. 주체적 글감 확정 메모
* **구체적 글감 1문장**: 2026년 늦가을 온비아 BEE 찻사찻 일행과 찾은 군산 구암동산 선교사 묘역에서 전킨(전위렴) 선교사 발치에 나란히 누운 세 아기(생후 8개월·2개월·20일)의 작은 묘석을 마주하며, 세상 눈에는 비정한 부모처럼 보였을 자리에서 주님께 드린 온전한 사랑과 항복, 그리고 오늘 내 일상의 삶을 돌아본 경험.
* **출발점**: `현장 답사 관찰 + 신앙적 고백 + 성찰`
* **지금 하고 싶은 말 3가지**:
  1. 구암동산 묘역의 큰 화강암 비석 발치에 누운 조지·시드니·프랜시스의 짧은 생몰 연대(8개월, 2개월, 20일) 앞에서 부모의 단장(斷腸)의 아픔이 먹먹하게 다가왔다.
  2. 세 아기를 잃고도 고향으로 돌아가지 않은 것은 세상이 오해하듯 ‘비정한 부모’여서가 아니라, 주권자 하나님 앞에 가장 소중한 것까지 내려놓은 ‘사랑과 항복’이자 모든 장벽을 넘어 조선의 흙이 된 ‘성육신적 사랑’이었다.
  3. 온비아 BEE 찻사찻 일행과 선교역사관 계단에서 찍은 밝은 미소 뒤편에는 130년 전 밀알들의 희생이 놓여 있으며, 오늘 내 일터와 가정에서 내 고집을 내려놓고 곁의 사람을 섬김으로 그 생명을 이어가야 한다.

### 1-2. 신학·선교학 학술 재료 및 성경 본문 연결
| 구분 | 참고 자료 (저자·연도 / 성경) | 핵심 개념 및 발견 | 내 글감과의 연결 및 발전한 생각 |
| :--- | :--- | :--- | :--- |
| **신학적 렌즈** | 디트리히 본회퍼 (Dietrich Bonhoeffer, 1937), *The Cost of Discipleship (나를 따르라)* | **값비싼 제자도 (Costly Discipleship)와 자기 비움(Kenosis)**: 은혜를 값싼 위안으로 소비하지 않고, 십자가 앞에서 가장 소중한 것까지 주님의 주권에 내어맡기는 복종 | 세 아이를 묻고도 궁멀을 떠나지 않은 전킨 부부의 선택이 ‘비정함’이 아니라 주님 앞에 드린 처절한 ‘사랑과 항복’임을 밝혀 주는 신학적 렌즈 |
| **선교학적 렌즈** | 데이비드 보쉬 (David J. Bosch, 1991), *Transforming Mission (변화하고 있는 선교)* | **성육신적 선교 (Incarnational Mission)**: 우월한 위치에서 베푸는 시혜가 아니라 언어·문화·질병·죽음의 장벽을 넘어 그 땅의 사람과 흙이 되는 선교 | “나는 궁멀 전씨다. 군산 궁멀에 묻어달라”는 유언과 버지니아 고향 흙·군산 흙의 합장을 ‘장애를 뛰어넘은 성육신적 사랑’으로 해석 |
| **성경적 렌즈** | 요한복음 12장 24절 (묘역 기념비 말씀) | **한 알의 밀알**: 땅에 떨어져 죽지 아니하면 한 알 그대로 있고, 죽으면 많은 열매를 맺음 | 구암교회, 영명학교(제일고), 멜볼딘여학교(영광여고), 예수병원, 군산 3·5 만세운동으로 이어진 생명의 역사와 오늘 우리의 빚진 자 의식을 하나로 묶는 중심 성구 |

---

## [2단계] 핵심 메시지 정립과 독자 중심 목차 설계

### 2-1. 핵심 메시지 한 문장
> **"세 아이를 이국땅에 묻고도 ‘궁멀 전씨’로 죽기를 자처했던 전킨 선교사 부부의 선택은 비정함이 아니라 주님 앞에 드린 온전한 사랑과 항복이었으며, 그 땅에 떨어져 죽은 한 알의 밀알을 기억하는 우리는 오늘 일상의 자리에서 나를 부인하는 사랑으로 그 생명을 살아내야 한다."**

### 2-2. 확정 제목 및 4장 12절 목차 (상세설계도 기준)
* **최종 제목**: **한 알의 밀알, 궁멀에 묻힌 사랑 — 군산 선교사 묘역에서**
* **1장. 잔디밭 위에 누운 세 개의 작은 돌** (1절 군산선교역사관 뒤편 언덕 / 2절 전킨 발치의 세 묘석 조지·시드니·프랜시스 / 3절 낯선 조선 땅에 자식을 묻은 단장지애)
* **2장. 비정한 부모인가, 주님 앞의 온전한 항복인가** (1절 왜 고향으로 돌아가지 않았는가 / 2절 세상이 던지는 날카로운 시선 / 3절 십자가 앞에 드린 완전한 항복 `[Bonhoeffer, 1937]`)
* **3장. “나는 궁멀 전씨다” — 장애를 뛰어넘은 더 큰 사랑** (1절 마흔셋에 남긴 마지막 유언 / 2절 모든 장애를 뛰어넘은 성육신적 사랑 `[Bosch, 1991]` / 3절 한 알의 밀알이 맺은 무수한 열매 `[요 12:24]`)
* **4장. 빚진 자의 일상, 기억함으로 이어가는 삶** (1절 2026년 늦가을 군산선교역사관 계단에서 온비아 BEE 찻사찻 일행과 남긴 사진 / 2절 거저 받은 복음과 자유의 무게 / 3절 일상에서 그 역사를 살아내는 가치 있는 삶)

---

## [3단계] 초고용 상세설계도 및 지면별 본문 연동 컷 설계
* **Page 001 (`gunsan_junkin_three_stones`)**: 늦가을 구암동산 묘역의 큰 화강암 비석 앞 흰 국화 한 송이와 발치 잔디밭에 나란히 누운 조지·시드니·프랜시스의 작은 평면 묘석 3기
* **Page 002 (`junkin_wheat_grain_incarnation`)**: 십자가 아래 버지니아와 궁멀의 흙 속에 떨어져 죽은 한 알의 밀알과 그 위에서 솟아오른 무수한 황금빛 밀 이삭들(구암교회·영명학교·예수병원·3·5 만세운동)
* **Page 003 (`gunsan_memorial_steps_prayer`)**: 가을 햇살이 내려앉은 군산선교역사관 붉은 벽돌 예배당과 표지석 계단

---

## [4단계] 초고 1 집필 및 [5단계] `(독자)`·`(내 마음)` 이중 점검 및 5대 지표 변증법적 퇴고

### 5-1. 초고 1에 남긴 `(독자)`와 `(내 마음)` 메모 및 전후 교정 대조표

| 문단 | 초고 1 원문 (교정 전) | `(독자)` / `(내 마음)` 점검 메모 | 5단계 최종 탈고 문장 (교정 후) |
| :--- | :--- | :--- | :--- |
| **2문단** | 그곳 잔디밭 위에는 조지, 시드니, 프랜시스라는 이름이 새겨진 세 개의 작은 평면 묘석이 나란히 누워 있었다. | **(내 마음 · 구체적 동작 복원)** 서서 내려다본 것처럼 적으면 그날의 먹먹함이 덜 전해집니다. 땅바닥과 거의 같은 높이로 누운 평면 묘석이라 무릎을 굽히고 허리를 숙여야만 세 아기의 이름과 짧은 날짜를 읽을 수 있었던 몸의 동작을 복원했습니다. | 그곳 잔디밭에는 땅바닥과 거의 같은 높이로 누운 세 개의 작은 평면 묘석이 나란히 박혀 있었다. 무릎을 굽히고 허리를 숙여야만 비로소 조지, 시드니, 프랜시스라는 세 아기의 이름이 눈에 들어왔다. |
| **3~4문단** | 세상 사람들의 눈에는 자식을 셋이나 사지로 몰아넣고 방치한 ‘비정한 부모’처럼 보였을지도 모른다... 그러나 그 자리는 비정함의 자리가 아니라, 십자가 앞에 드린 온전한 항복의 자리였다. | **(독자 · 징검다리 보완)** ‘비정한 부모’라는 세상의 시선에서 곧바로 ‘십자가 앞의 항복’으로 넘어가면 독자가 감정의 간극을 느낄 수 있습니다. 부모로서 어찌 밤마다 가슴을 치는 단장(斷腸)의 고통이 없었겠느냐는 인간적 슬픔을 먼저 짚어 준 뒤 항복으로 이어지도록 징검다리를 놓았습니다. | “너희가 믿는 신이 과연 자식을 이렇게 빼앗아 가느냐”는 안팎의 냉소 속에서, 그들 자신도 밤마다 가슴을 치며 무너져 내렸을 것이다. 부모에게 어찌 단장(斷腸)의 고통이 없었겠는가. 그러나 그 자리는 비정함의 자리가 아니라, 십자가 앞에 드린 온전한 항복의 자리였다. |
| **5~6문단** | 그는 “나는 궁멀 전씨다. 내가 죽으면 군산 궁멀에 묻어달라”는 말을 남겼다... 영명학교와 멜볼딘여학교를 통해 인재들이 자라났으며 | **(독자 · 지명 및 역사 맥락 보완)** 오늘날 독자에게 생소할 수 있는 ‘궁멀’이 구암동의 옛 이름이며 이를 자신의 본관(궁멀 전씨)으로 삼았다는 설명을 보태고, 영명학교(현 군산제일고)·멜볼딘여학교(현 군산영광여고)·예수병원의 현재적 연결을 명시했습니다. | 구암동의 옛 이름인 ‘궁멀’을 자신의 본관으로 삼아 조선 사람으로 죽기를 자처한 것이다... 구암교회가 일어섰고, 영명학교(현 군산제일고)와 멜볼딘여학교(현 군산영광여고)의 교실마다 조선의 다음 세대가 자라났으며, 병든 이들을 돌보는 예수병원의 치유 사역이 뻗어 나갔다. |
| **8문단** | 거창한 구호를 외치는 대신, 내가 서 있는 일터와 가정에서 나를 부인하고 내 곁의 사람을 묵묵히 섬기는 것이야말로 이 시대의 밀알로 사는 길일 것이다. | **(내 마음 · 추상화·보편화 제거)** ‘이 시대의 밀알로 사는 길’이라는 일반론적 서술을, 내 일터와 가정에서 ‘내 몫의 손해를 기꺼이 감수하며 곁에 있는 한 사람을 품어내는 것’이라는 구체적 삶의 태도와 1인칭 기도로 여운 있게 갈무리했습니다. | 거창한 구호를 외치지 않더라도, 내게 맡겨진 일터와 가정에서 내 몫의 손해를 기꺼이 감수하며 곁에 있는 한 사람을 품어내는 것이 오늘 내가 감당할 작은 밀알의 걸음일 것이다. |
"""
        gunsan_design_path = Path(workspace_root) / "20261107_한_알의_밀알_궁멀에_묻힌_사랑_군산_선교사_묘역에서_ican_write_설계기록.md"
        gunsan_design_path.write_text(gunsan_design_md, encoding="utf-8")

        for target_md in (gunsan_final_path, gunsan_draft1_path, gunsan_design_path):
            out, title, date_str = process_file(str(target_md), template_html, args.suffix, args.cuts)
            print(f"Created: {out}")
            processed_items.append((str(target_md), out, title, date_str))

        gunsan_top_cards = """        <h2 class="section-title">철학 · 신학 성찰 에세이</h2>
        <div class="list-group">
            <a href="./20261107_한_알의_밀알_궁멀에_묻힌_사랑_군산_선교사_묘역에서_깊은사고_에세이.html" class="list-item" target="_blank">
                <div class="item-info">
                    <h3>한 알의 밀알, 궁멀에 묻힌 사랑 — 군산 선교사 묘역에서 (ican-write 5단계 완성본 · A4 1단 지면)</h3>
                    <p>구암동산 전킨 선교사 발치의 세 아기 묘석, 값비싼 제자도(Bonhoeffer, 1937)와 성육신적 선교(Bosch, 1991), 빚진 자의 일상을 담은 성찰 에세이</p>
                </div>
                <div class="arrow">→</div>
            </a>
            <a href="./20261107_한_알의_밀알_궁멀에_묻힌_사랑_군산_선교사_묘역에서_깊은사고_에세이.md" class="list-item" target="_blank" download>
                <div class="item-info">
                    <h3>한 알의 밀알, 궁멀에 묻힌 사랑 — 군산 선교사 묘역에서 (5단계 완성본 MD 다운로드)</h3>
                    <p>옵시디언 및 마크다운 에디터용 원본 문서 (ican-write 5단계 최종 탈고본)</p>
                </div>
                <div class="arrow">↓</div>
            </a>
            <a href="./20261107_한_알의_밀알_궁멀에_묻힌_사랑_군산_선교사_묘역에서_초고1.html" class="list-item" target="_blank">
                <div class="item-info">
                    <h3>한 알의 밀알, 궁멀에 묻힌 사랑 — 군산 선교사 묘역에서 (4단계 초고 1 · A4 1단 지면)</h3>
                    <p>초고용 상세설계도(4장 12절)를 바탕으로 집필한 4단계 초고 1 원문 및 본문 연동 3컷 일러스트 지면</p>
                </div>
                <div class="arrow">→</div>
            </a>
            <a href="./20261107_한_알의_밀알_궁멀에_묻힌_사랑_군산_선교사_묘역에서_ican_write_설계기록.html" class="list-item" target="_blank">
                <div class="item-info">
                    <h3>[ican-write 1~5단계 설계기록] 한 알의 밀알, 궁멀에 묻힌 사랑 — 군산 선교사 묘역에서 (A4 1단 지면)</h3>
                    <p>상세설계도(4장 12절) → 4단계 초고 1 → 5단계 (독자)·(내 마음) 및 5대 지표 변증법적 퇴고 대조표</p>
                </div>
                <div class="arrow">→</div>
            </a>
            <a href="./20261107_한_알의_밀알_궁멀에_묻힌_사랑_군산_선교사_묘역에서_ican_write_설계기록.md" class="list-item" target="_blank" download>
                <div class="item-info">
                    <h3>[ican-write 1~5단계 설계기록] 한 알의 밀알, 궁멀에 묻힌 사랑 (MD 다운로드)</h3>
                    <p>옵시디언 및 마크다운 에디터용 1~5단계 설계·퇴고 기록 원본 문서 (.md)</p>
                </div>
                <div class="arrow">↓</div>
            </a>
            <a href="./20261107_숙성된_옹기들의_합창_익산_고스락_산책길에서_깊은사고_에세이.html\""""

        for repo_name in ("bible-thought", "sparkofbible"):
            idx_p = Path(workspace_root) / repo_name / "index.html"
            if idx_p.exists():
                raw = idx_p.read_text(encoding="utf-8")
                m = re.search(
                    r'\s*<h2 class="section-title">철학 · 신학 성찰 에세이</h2>\s*<div class="list-group">.*?<a href="\./20261107_숙성된_옹기들의_합창_익산_고스락_산책길에서_깊은사고_에세이\.html"',
                    raw,
                    flags=re.DOTALL,
                )
                if m and "20261107_한_알의_밀알_궁멀에_묻힌_사랑_군산_선교사_묘역에서_깊은사고_에세이.html" not in raw:
                    raw = raw[: m.start()] + "\n" + gunsan_top_cards + raw[m.end() :]
                    idx_p.write_text(raw, encoding="utf-8")

    if args.gosrak_ican:
        ican_design_md = """---
title: "[ican-write 1~5단계 설계기록] 숙성된 옹기들의 합창 — 익산 고스락 산책길에서"
date: 2026-11-07
tags: [ican-write, 어나더레벨글쓰기, 고스락, 옹기, 첨성대, 5단계설계기록]
---

# [ican-write 1~5단계 설계기록] 숙성된 옹기들의 합창 — 익산 고스락 산책길에서

---

## [1단계] 글감 발견과 생각 확장 (1강 STEP 1~2)

### 1-1. 주체적 글감 확정 메모
* **구체적 글감 1문장**: 익산 이화동산(고스락) 산책길에서 마주한 오천여 개의 전통 옹기 군락과 축소 첨성대, 그리고 한국전쟁 총탄 자국을 품은 채 세월을 익혀가는 항아리들 앞에서 내 삶의 조급함과 마음의 밀폐를 돌아본 경험.
* **출발점**: `관찰 + 경험 + 성찰` (홀로 찾은 고스락 정원의 풍경 관찰에서 출발해 내면의 숙성이라는 성찰로 심화)
* **지금 하고 싶은 말 3가지**:
  1. ‘으뜸(고스락)’이라는 이름과 달리 낮고 고요한 잔디밭과 솔바람 속에서 책상 앞의 긴장이 풀리고 내면을 들여다보는 여백이 열렸다.
  2. 하늘의 때를 읽는 첨성대(과거)와 미세 숨구멍으로 바람을 호흡하며 장을 익히는 옹기(현재)는 ‘밀폐가 아닌 호흡이 숙성을 만든다’는 진리를 보여준다.
  3. 총탄 자국과 모진 풍파를 견뎌낸 옹기들의 무언의 합창 앞에서, 결과를 재촉하며 유리병처럼 마음을 걸어 잠갔던 나를 돌아보고 세월의 바람을 호흡하는 삶을 소망하게 되었다.

### 1-2. 4대 렌즈와 3대 학술 자료를 통한 생각 확장
| 구분 | 참고 학술 자료 (저자·연도) | 핵심 개념 및 발견 | 내 글감과의 연결 및 발전한 생각 |
| :--- | :--- | :--- | :--- |
| **심리·환경 렌즈** | 스티븐 캐플런 (Stephen Kaplan, 1995), *The Restorative Benefits of Nature* | **부드러운 매혹 (Soft Fascination)**: 억지 집중으로 피로해진 주의력이 자연의 잔잔한 자극(풀빛, 바람결)을 만날 때 소음이 가라앉고 성찰의 여유가 회복됨 | 서재에서 원고와 일정을 붙들고 씨름하던 긴장이 고스락의 잔디밭과 솔바람 앞에서 왜 자연스럽게 풀렸는지 설명해 주는 첫 징검다리 |
| **과학·발효 렌즈** | 김수환·데이비드 후 (Soohwan Kim & David L. Hu, 2023), *Onggi's Permeability to Carbon Dioxide* | **미세 숨구멍의 호흡**: 유리·플라스틱처럼 안팎을 완전히 차단하면 부패하지만, 옹기 벽면의 미세 기공이 공기와 이산화탄소를 호흡할 때 유익균이 자라 깊은 장맛을 빚어냄 | 상처받지 않으려 마음의 문을 유리병처럼 걸어 잠그면 내면이 고여 상한다는 깨달음과 직결됨 |
| **고통·성장 렌즈** | 리처드 테데스키·로런스 칼훈 (Tedeschi & Calhoun, 2004), *Posttraumatic Growth* | **시련 후 성장 (Posttraumatic Growth)**: 삶의 거센 풍파와 상흔을 통과하며 이전보다 훨씬 깊고 단단한 내면을 형성함 | 한국전쟁 총탄 자국을 몸통에 품은 채 살아남아 깊은 장을 익히는 옹기들의 행렬을 ‘시련을 견뎌낸 사람들의 합창’으로 읽게 해 주는 핵심 렌즈 |

---

## [2단계] 핵심 메시지 정립과 독자 중심 목차 설계 (1강 STEP 3~4 + 2강 STEP 1)

### 2-1. 독자 프로파일링
* **연령 및 생활상황**: 일상의 책임과 성취 압박 속에서 쉼 없이 달려오며 내면의 소진을 겪는 40~60대 독자 및 성찰적 글쓰기·묵상을 추구하는 독자.
* **주제에 관한 지식·경험**: 장독대와 첨성대는 익숙하지만, 두 대상이 한 정원에서 만나는 의미나 옹기의 미세 기공 과학(Kim & Hu, 2023)을 삶의 태도와 연결해 본 경험은 낯설다.
* **현재의 관심과 고민**: "왜 나는 늘 조급할까? 시련과 상처를 겪으면서도 마음이 썩지 않고 깊어지려면 어떻게 해야 할까?"
* **읽고 얻고 싶은 것**: 추상적인 위로가 아니라, 눈앞에 그려지는 산책길의 풍경 속에서 내 삶을 돌아볼 구체적인 은유(유리병 vs 숨구멍 옹기)와 잔잔한 여운.

### 2-2. 핵심 메시지 한 문장
> **"유리병처럼 마음을 걸어 잠그고 결과를 재촉하는 삶을 넘어, 옹기의 미세 숨구멍처럼 내게 주어진 세월의 바람과 시련을 기꺼이 호흡할 때 우리의 내면도 깊고 그윽한 화음으로 숙성된다."**

### 2-3. 확정 제목 및 독자 중심 2단 목차 (린다 플라워 원칙 적용)
* **최종 제목**: **숙성된 옹기들의 합창 — 익산 고스락 산책길에서**
* **확정 2단 목차 (경험·성찰형 + 설명·분석형 결합)**:
  * **1장. 낮은 바람이 여는 성찰의 자리 — 고스락 잔디밭과 ‘부드러운 매혹’**
    * 동행 없이 나선 익산 이화동산(고스락)의 낮고 고요한 잔디밭 풍경
    * 책상 앞의 긴장을 풀어주는 자연의 ‘부드러운 매혹(Soft Fascination)’과 수천 개 옹기 군락의 출현
  * **2장. 하늘의 시간과 땅의 호흡이 만나는 마당 — 첨성대와 옹기의 미세 숨구멍**
    * 장독대 정원 끝자락에서 마주친 사분의 일 크기 첨성대와 낯선 조우
    * 별자리를 읽던 과거의 시간(첨성대)과 햇살·바람을 받아 장을 익히는 현재의 시간(옹기)의 호흡과 미세 숨구멍의 비밀(Kim & Hu, 2023)
  * **3장. 상흔을 품고 익어가는 사람들의 행렬 — 총탄 자국 옹기와 ‘시련 후 성장’**
    * 전국에서 모여든 각양각색의 단지와 한국전쟁 총탄 자국을 몸에 품은 항아리의 촉감
    * ‘시련 후 성장(Posttraumatic Growth)’으로 읽는 옹기들의 침묵과 독 사이 골목을 울리는 낮은 합창
  * **4장. 유리병의 밀폐를 넘어 숨구멍으로 호흡하는 삶 — 서재의 창을 여는 소망**
    * 글과 성취의 결과를 서둘러 재촉하며 유리병처럼 마음을 걸어 잠갔던 지난날의 성찰
    * 세월의 비바람을 온몸의 숨구멍으로 받아들이며 화음 한 줄을 보태고 싶은 작은 다짐

---

## [3단계] A4 한 장 상세설계도와 본문 연동 컷 설계 (2강 STEP 2~3)

* **1장 (A4 Page 001 전반)**
  * `핵심`: 위세를 부리지 않는 고스락의 푸른 잔디밭과 솔바람이 굳어 있던 어깨를 풀고 성찰의 시선을 열어준다.
  * `ㅇ` 익산 이화동산 ‘고스락(으뜸·꼭대기)’이라는 이름과 대조되는 낮은 잔디밭의 고요함 `[내 경험]`
  * `ㅇ` 스티븐 캐플런(Kaplan, 1995)의 ‘부드러운 매혹(Soft Fascination)’ — 억지 집중의 피로를 가라앉히는 풀빛과 바람결 `[이론]`
  * `ㅇ` 솔숲 너머 시야가 트이며 펼쳐진 수천 개 검붉은 항아리와 축소 첨성대의 조우 `[장면]`
  * **Page 001 본문 연동 컷 설계 (`gosrak_garden_cheomseongdae`)**: 푸른 잔디밭과 솔숲 너머 수천 개의 검붉은 옹기 군락과 나란히 선 첨성대 와이드 일러스트
* **2장~3장 (A4 Page 002 중반)**
  * `핵심`: 미세 숨구멍으로 바람을 호흡하는 옹기의 과학과 총탄 자국을 견뎌낸 항아리들의 ‘시련 후 성장’이 무언의 합창으로 울려 퍼진다.
  * `ㅇ` 첨성대 꼭대기가 우러르는 하늘과 오천여 개 옹기 뚜껑이 마주한 하늘의 연결 `[관찰]`
  * `ㅇ` 김수환·데이비드 후(Kim & Hu, 2023)의 전통 옹기 미세 숨구멍 연구 — 유리병 밀폐(부패)와 기공 호흡(발효)의 대비 `[이론]`
  * `ㅇ` 한국전쟁 총탄 자국을 품은 항아리의 거친 패임과 테데스키·칼훈(Tedeschi & Calhoun, 2004)의 ‘시련 후 성장(Posttraumatic Growth)’ `[내 경험 + 이론]`
  * **Page 002 본문 연동 컷 설계 (`onggi_breathing_chorus`)**: 총탄 상흔을 품은 옹기들의 둥근 어깨와 미세 숨구멍을 스치는 바람의 합창 일러스트
* **4장 (A4 Page 003 후반)**
  * `핵심`: 결과를 재촉하며 유리병처럼 닫아두었던 마음을 돌아보고, 세월의 바람을 호흡하며 익어가는 삶을 소망한다.
  * `ㅇ` 한 편의 글과 묵상의 결과를 재촉하며 조급해하던 내 일상의 솔직한 반성 `[내 마음]`
  * `ㅇ` 상처받지 않겠다며 유리병처럼 걸어 잠갔던 마음의 창을 조금 열어두겠다는 구체적 다짐 `[실천 여운]`
  * **Page 003 본문 연동 컷 설계 (`sunset_walk_onggi_harmony`)**: 노을빛 내려앉는 장독대 산책길과 세월의 바람을 호흡하며 걸어가는 발걸음 일러스트

---

## [4단계] 초고 1 집필 및 [5단계] `(독자)`·`(내 마음)` 이중 점검 및 5대 지표 변증법적 퇴고

### 5-1. 초고 1에 남긴 `(독자)`와 `(내 마음)` 메모 및 전후 교정 대조표

| 문단 | 초고 1 원문 (교정 전) | `(독자)` / `(내 마음)` 점검 메모 | 5단계 최종 탈고 문장 (교정 후) |
| :--- | :--- | :--- | :--- |
| **2문단** | 잔디를 밟는 발걸음이 가벼워지자 <u>일상의 팽팽하던 긴장이 조금씩 풀렸다.</u> | **(내 마음 / 추상화 제거)** ‘일상의 팽팽하던 긴장’은 너무 넓은 범주어야. 산책에 나서기 전 서재 책상 앞에서 원고와 일정을 붙들고 씨름하느라 굳어 있던 어깨와 구두 밑창에 닿는 잔디의 감각을 구체적인 첫 장면으로 살리고 싶어. | 구두 밑창 너머로 잔디의 폭신한 탄력이 전해지자, 아침 내내 서재 책상 앞에서 원고와 밀린 일들을 헤아리느라 굳어 있던 어깨가 조금씩 내려앉았다. |
| **3문단** | 처음에는 장독대 정원에 왜 신라의 천문대가 서 있을까 의아했다. 그러나 걸음을 멈추고 두 모습을 나란히 바라보자 <u>고개가 끄덕여졌다. 거기에는 과거의 역사와 현재의 숙성이 이루는 조화가 있었다.</u> | **(독자 / 징검다리 보완)** 나란히 바라봤다고 해서 왜 곧바로 ‘역사와 숙성의 조화’라며 고개가 끄덕여졌는지 시선의 연결고리가 빠져 있어. 첨성대 꼭대기가 우러르는 하늘과 옹기 뚜껑들이 마주한 하늘이 같은 하늘이라는 시각적 장면을 넣어주자. | 처음에는 장독대 정원에 웬 신라의 천문대인가 싶어 낯설었다. 그러나 걸음을 멈추고 첨성대 꼭대기 우물 정(井)자 돌이 우러르는 하늘과, 그 아래 오천여 개 옹기 뚜껑들이 일제히 이고 있는 하늘을 번갈아 바라보자 비로소 고개가 끄덕여졌다. 별의 길을 읽던 옛 돌탑과 햇살을 받아 장을 익히는 오늘의 독들이 한 하늘 아래서 시간을 나누어 맡고 있었던 것이다. |
| **5~6문단** | 그중에는 한국전쟁 당시 날아든 총탄 자국을 몸에 그대로 품은 채 살아남은 항아리도 있었다... 잘 숙성된 옹기들이 <u>일제히 낮고 웅장한 합창을 들려주는 듯했다.</u> | **(내 마음 / 감각 구체화)** 총탄 자국이 패인 자리 앞에 멈춰 서서 거친 흙결을 가만히 들여다본 순간을 보태고 싶어. 또 ‘웅장한 합창’이라는 수식어보다, 독 사이 좁은 골목을 스치는 바람이 ‘우웅—’ 하고 울리는 낮은 공명음으로 들렸다고 내 감각의 범위 안에서 적고 싶어. | 그중에는 한국전쟁 당시 날아든 총탄 자국을 몸통에 그대로 품은 채 살아남은 항아리도 있었다. 파인 자리에 손끝을 가까이 대어보니 불길과 총성을 견뎌낸 흙결이 거칠게 살아 있었다... 솔바람이 독과 독 사이의 좁은 골목을 빠져나가며 둥근 어깨들을 스칠 때마다, 낮게 ‘우웅—’ 하고 울리는 공명음이 번져 나왔다. 큰 소리를 내세우지 않아도, 세월의 무게를 견뎌낸 존재들이 서로의 곁을 지키며 빚어내는 낮고 깊은 합창처럼 들렸다. |
| **7~8문단** | <u>당장 눈에 보이는 숫자와 성취에 매달리느라</u>, 내 안의 생각과 인격이 서서히 익어갈 시간을 견디지 못했다... 깊고 그윽한 화음 한 줄을 보탤 수 있기를 조용히 소망해 본다. | **(내 마음 / 보편화 제거)** ‘숫자와 성취에 매달리느라’는 누구에게나 쓰는 상투적 표현이야. 한 편의 글을 쓰고 말씀을 묵상하면서도 익어갈 시간을 못 견뎌 뚜껑을 열어보던 내 실제 일상을 적고, 결말도 서재 창문을 조금 열어두겠다는 작은 실천과 결합하고 싶어. | 한 편의 글을 쓰고 한 줄의 문장을 묵상하면서도, 내 안에서 생각이 묵묵히 삭아들 시간을 견디지 못해 서둘러 독 뚜껑을 열어보듯 결과를 재촉하곤 했다... 오늘 산책을 마치고 서재로 돌아가면, 유리병처럼 닫아두었던 마음의 창을 조금쯤 열어두어야겠다. 서두르지 않고 내게 주어진 세월의 바람을 기꺼이 호흡하며 익어가다 보면, 언젠가 내 삶도 저 숙성된 옹기들의 행렬 한구석에서 깊고 그윽한 화음 한 줄을 보탤 수 있으리라 조용히 소망해 본다. |

### 5-2. 김익한의 5대 평가지표 최종 검증
1. **수월성 (우수)**: 문단당 4~6문장의 안정된 호흡을 유지하며, 3개의 학술 개념(Soft Fascination, 옹기 미세 기공 투과성, Posttraumatic Growth)이 산책길의 시선 이동에 따라 막힘없이 읽힌다.
2. **주체성 (우수)**: 추상적인 ‘일상의 긴장’이나 ‘숫자와 성취’를 걷어내고, 서재 책상 앞의 굳은 어깨·총탄 자국의 거친 흙결·독 뚜껑을 서둘러 열어보던 조급함 등 글쓴이 고유의 체험과 입말을 회복했다.
3. **논리성 (우수)**: 첨성대(하늘의 때를 읽는 시간) → 옹기 미세 숨구멍(바람을 호흡하는 발효) → 유리병 밀폐(부패)와 시련의 호흡(성숙)으로 이어지는 은유와 학술 근거의 범위가 정확히 맞물린다.
4. **선명성 (우수)**: *"유리병처럼 걸어 잠그면 안에서 부패하고, 보이지 않는 숨구멍으로 바깥의 바람을 받아들여야 깊은 장맛을 빚어낸다"*는 중심 문장이 선명하게 각인된다.
5. **감응성 (우수)**: 한국전쟁 총탄 자국을 품은 항아리 골목에서 울리는 ‘우웅—’ 하는 낮은 공명음과, 산책 후 서재의 창을 조금 열어두겠다는 결미가 독자 자신의 닫힌 창을 돌아보게 하는 깊은 여운을 남긴다.
"""
        ican_design_path = Path(workspace_root) / "20261107_숙성된_옹기들의_합창_익산_고스락_산책길에서_ican_write_설계기록.md"
        ican_design_path.write_text(ican_design_md, encoding="utf-8")

        refined_essay_md = """---
title: "숙성된 옹기들의 합창 — 익산 고스락 산책길에서 (ican-write 5단계 완성본)"
date: 2026-11-07
tags: [고스락, 익산, 옹기, 첨성대, ican-write, 성찰에세이]
---

# 숙성된 옹기들의 합창 — 익산 고스락 산책길에서

익산 이화동산의 문을 나서자 너른 정원이 눈앞에 열렸다. 오늘 산책에는 동행을 두지 않았다. 온전히 혼자만의 사색에 잠기고 싶어 천천히 걸음을 옮겼다. 이곳의 또 다른 이름은 ‘고스락’이다. 으뜸이나 꼭대기를 뜻하는 순우리말이라지만, 정작 마당에 들어서면 무엇 하나 높은 체하며 위세를 부리는 것이 없다. 잘 가꾸어진 푸른 잔디밭 위로 낮은 바람이 소리 없이 지나갈 뿐이다.

구두 밑창 너머로 잔디의 폭신한 탄력이 전해지자, 아침 내내 서재 책상 앞에서 원고와 밀린 일들을 헤아리느라 굳어 있던 어깨가 조금씩 내려앉았다. 환경심리학자 스티븐 캐플런은 자연이 건네는 이러한 잔잔한 자극을 ‘부드러운 매혹(Soft Fascination)’이라 불렀다(Kaplan, 1995). 억지로 무언가에 집중하느라 지친 마음이 풀빛과 바람결에 시선을 맡길 때, 비로소 머릿속의 소음이 가라앉고 자기 안을 들여다보는 성찰의 자리가 열린다는 뜻이다. 솔숲 사이로 불어오는 바람에 호흡을 맞추며 걷는 사이, 시야가 탁 트이면서 수천 개의 검붉은 항아리들이 대지를 가득 메운 장관이 나타났다.

산책로를 따라 걸어가다 잔디밭 끝자락에서 뜻밖의 풍경과 마주쳤다. 수천 개의 옹기 군락 너머에 실물의 사분의 일 크기로 축소해 놓은 첨성대가 서 있었다. 처음에는 장독대 정원에 웬 신라의 천문대인가 싶어 낯설었다. 그러나 걸음을 멈추고 첨성대 꼭대기 우물 정(井)자 돌이 우러르는 하늘과, 그 아래 오천여 개 옹기 뚜껑들이 일제히 이고 있는 하늘을 번갈아 바라보자 비로소 고개가 끄덕여졌다. 별의 길을 읽던 옛 돌탑과 햇살을 받아 장을 익히는 오늘의 독들이 한 하늘 아래서 시간을 나누어 맡고 있었던 것이다.

첨성대는 하늘의 별자리를 살피고 사계절의 흐름을 읽어내던 과거의 시간이다. 그 곁에 늘어선 오천여 개의 옹기들은 하늘이 내려준 그 햇살과 바람을 받아 지금 이 순간에도 묵묵히 장을 익혀내는 현재의 시간이다. 유구한 역사는 박물관의 유리관 속에 멈춰 있지 않고, 오늘도 살아 움직이는 발효의 시간과 한 마당에서 숨을 나누고 있었다. 김수환과 데이비드 후 연구팀이 규명했듯, 전통 옹기가 음식을 썩지 않게 하고 깊은 맛으로 숙성시키는 비밀은 벽면에 뚫린 무수한 미세 숨구멍에 있다(Kim & Hu, 2023). 유리나 플라스틱처럼 안팎을 완전히 걸어 잠그면 내용물은 안에서 부패한다. 오직 보이지 않는 숨구멍으로 바깥의 공기와 바람을 받아들이고 내쉬어야만 유익한 미생물이 자라나 깊은 장맛을 빚어낸다. 하늘의 때를 읽는 지혜와 땅의 바람을 호흡하는 그릇이 잔디밭 위에서 하나로 이어지고 있었다.

항아리들이 줄지어 선 사잇길로 깊숙이 걸어 들어갔다. 지난 수십 년 동안 전국 각지에서 하나둘 모여든 항아리들은 생김새도 빛깔도 저마다 달랐다. 배가 넉넉하게 부른 항아리 옆에 허리가 잘록한 단지가 서 있고, 짙은 갈색 옹기 곁에 세월의 더께가 내려앉은 거친 독이 어깨를 나란히 하고 있었다. 그중에는 한국전쟁 당시 날아든 총탄 자국을 몸통에 그대로 품은 채 살아남은 항아리도 있었다. 파인 자리에 손끝을 가까이 대어보니 불길과 총성을 견뎌낸 흙결이 거칠게 살아 있었다. 모진 땡볕과 눈보라, 시대의 상흔까지 맨몸으로 받아내며 깨지지 않고 버텨온 그릇들이었다.

가만히 서서 그 행렬을 바라보노라니, 그것들은 더 이상 흙으로 구운 그릇으로 보이지 않았다. 모진 세월을 말없이 견뎌낸 사람들의 모습이었다. 심리학자 리처드 테데스키와 로런스 칼훈은 인간이 삶의 거센 풍파와 고통을 통과하며 이전보다 훨씬 더 깊고 단단한 내면을 갖게 되는 과정을 ‘시련 후 성장(Posttraumatic Growth)’이라 설명했다(Tedeschi & Calhoun, 2004). 상처 입은 자리마다 깊어진 속내를 간직한 사람들처럼, 수천 개의 옹기들은 각자의 자리에서 침묵으로 속을 익히고 있었다. 솔바람이 독과 독 사이의 좁은 골목을 빠져나가며 둥근 어깨들을 스칠 때마다, 낮게 ‘우웅—’ 하고 울리는 공명음이 번져 나왔다. 화려한 소리를 내세우지 않아도, 세월의 무게를 견뎌낸 존재들이 서로의 곁을 지키며 빚어내는 무언의 화음이었다.

합창이 울려 퍼지는 산책로 한가운데서 문득 내 삶의 시간을 돌아보았다. 나는 그동안 얼마나 조급하게 결과를 재촉하며 살아왔던가. 한 편의 글을 쓰고 한 줄의 문장을 묵상하면서도, 내 안에서 생각과 인격이 묵묵히 삭아들 시간을 견디지 못해 서둘러 독 뚜껑을 열어보듯 조바심을 내곤 했다. 때로는 상처받지 않겠다며 마음의 문을 유리병처럼 단단히 걸어 잠근 채, 밖에서 불어오는 시련의 바람을 원망하기만 했다.

고스락의 옹기들은 온몸의 숨구멍으로 비바람을 받아들이며 오늘도 조금씩 깊어지고 있다. 잔디밭을 가로질러 불어오는 바람을 맞으며 다시 천천히 정문 쪽으로 걸음을 옮겼다. 오늘 산책을 마치고 서재로 돌아가면, 유리병처럼 닫아두었던 마음의 창을 조금쯤 열어두어야겠다. 서두르지 않고 내게 주어진 세월의 바람을 기꺼이 호흡하며 익어가다 보면, 언젠가 내 삶도 저 숙성된 옹기들의 행렬 한구석에서 깊고 그윽한 화음 한 줄을 보탤 수 있으리라 조용히 소망해 본다.
"""
        refined_essay_path = Path(workspace_root) / "20261107_숙성된_옹기들의_합창_익산_고스락_산책길에서_깊은사고_에세이.md"
        refined_essay_path.write_text(refined_essay_md, encoding="utf-8")

        for target_md in (refined_essay_path, ican_design_path):
            out, title, date_str = process_file(str(target_md), template_html, args.suffix, args.cuts)
            print(f"Created: {out}")
            processed_items.append((str(target_md), out, title, date_str))

        clean_gosrak_cards = """        <h2 class="section-title">철학 · 신학 성찰 에세이</h2>
        <div class="list-group">
            <a href="./20261107_숙성된_옹기들의_합창_익산_고스락_산책길에서_깊은사고_에세이.html" class="list-item" target="_blank">
                <div class="item-info">
                    <h3>숙성된 옹기들의 합창 — 익산 고스락 산책길에서 (ican-write 5단계 완성본 · A4 1단 지면)</h3>
                    <p>익산 고스락 오천여 개 옹기 군락과 축소 첨성대, 미세 숨구멍의 호흡(Kim &amp; Hu, 2023)과 시련 후 성장(Tedeschi &amp; Calhoun, 2004)을 담은 성찰 에세이</p>
                </div>
                <div class="arrow">→</div>
            </a>
            <a href="./20261107_숙성된_옹기들의_합창_익산_고스락_산책길에서_깊은사고_에세이.md" class="list-item" target="_blank" download>
                <div class="item-info">
                    <h3>숙성된 옹기들의 합창 — 익산 고스락 산책길에서 (5단계 완성본 MD 다운로드)</h3>
                    <p>옵시디언 및 마크다운 에디터용 원본 문서 (ican-write 5단계 최종 탈고본)</p>
                </div>
                <div class="arrow">↓</div>
            </a>
            <a href="./20261107_숙성된_옹기들의_합창_익산_고스락_산책길에서_ican_write_설계기록.html" class="list-item" target="_blank">
                <div class="item-info">
                    <h3>[ican-write 1~5단계 설계기록] 숙성된 옹기들의 합창 — 익산 고스락 산책길에서 (A4 1단 지면)</h3>
                    <p>1단계 글감·3대 학술자료 연결 → 2단계 독자 중심 목차 → 3단계 상세설계도 → 5단계 (독자)·(내 마음) 및 5대 지표 퇴고 대조표</p>
                </div>
                <div class="arrow">→</div>
            </a>
            <a href="./20261107_숙성된_옹기들의_합창_익산_고스락_산책길에서_ican_write_설계기록.md" class="list-item" target="_blank" download>
                <div class="item-info">
                    <h3>[ican-write 1~5단계 설계기록] 숙성된 옹기들의 합창 (MD 다운로드)</h3>
                    <p>옵시디언 및 마크다운 에디터용 1~5단계 설계·퇴고 기록 원본 문서 (.md)</p>
                </div>
                <div class="arrow">↓</div>
            </a>
            <a href="./20261107_숙성된_옹기들의_합창_익산_고스락_산책길에서.html" class="list-item" target="_blank">
                <div class="item-info">
                    <h3>숙성된 옹기들의 합창 — 익산 고스락 산책길에서 (초고 1 원문 · A4 1단 지면)</h3>
                    <p>초고 1 원문(1,695자) 100% 보존본 및 페이지별 고스락·옹기·첨성대 3컷 일러스트 지면</p>
                </div>
                <div class="arrow">→</div>
            </a>
            <a href="./20261107_숙성된_옹기들의_합창_익산_고스락_산책길에서.md" class="list-item" target="_blank" download>
                <div class="item-info">
                    <h3>숙성된 옹기들의 합창 — 익산 고스락 산책길에서 (초고 1 원문 MD 다운로드)</h3>
                    <p>옵시디언 및 마크다운 에디터용 초고 1 원문 (.md)</p>
                </div>
                <div class="arrow">↓</div>
            </a>
            <a href="./20261106_일상의깊은사고_아모스_2_9-16_깊은사고_에세이.html\""""

        for repo_name in ("bible-thought", "sparkofbible"):
            idx_p = Path(workspace_root) / repo_name / "index.html"
            if idx_p.exists():
                raw = idx_p.read_text(encoding="utf-8")
                m = re.search(
                    r'\s*<h2 class="section-title">철학 · 신학 성찰 에세이</h2>\s*<div class="list-group">.*?<a href="\./20261106_일상의깊은사고_아모스_2_9-16_깊은사고_에세이\.html"',
                    raw,
                    flags=re.DOTALL,
                )
                if m and "20261107_숙성된_옹기들의_합창_익산_고스락_산책길에서_깊은사고_에세이.html" not in raw:
                    raw = raw[: m.start()] + "\n" + clean_gosrak_cards + raw[m.end() :]
                    idx_p.write_text(raw, encoding="utf-8")

    if args.gosrak:
        gosrak_md = """---
title: "숙성된 옹기들의 합창 — 익산 고스락 산책길에서"
date: 2026-11-07
tags: [고스락, 익산, 옹기, 첨성대, 성찰에세이]
---

# 숙성된 옹기들의 합창 — 익산 고스락 산책길에서

익산 이화동산의 문을 나서자 너른 정원이 눈앞에 열렸다. 오늘 산책에는 동행을 두지 않았다. 온전히 혼자만의 사색에 잠기고 싶어 천천히 걸음을 옮겼다. 이곳의 또 다른 이름은 ‘고스락’이다. 으뜸이나 꼭대기를 뜻하는 순우리말이라지만, 정작 마당에 들어서면 무엇 하나 높은 체하며 위세를 부리는 것이 없다. 잘 가꾸어진 푸른 잔디밭 위로 낮은 바람이 소리 없이 지나갈 뿐이다.

잔디를 밟는 발걸음이 가벼워지자 일상의 팽팽하던 긴장이 조금씩 풀렸다. 환경심리학자 스티븐 캐플런은 자연이 건네는 이러한 잔잔한 자극을 ‘부드러운 매혹(Soft Fascination)’이라 불렀다(Kaplan, 1995). 억지로 무언가에 집중하느라 지친 마음이 풀빛과 바람결에 시선을 맡길 때, 비로소 머릿속의 소음이 가라앉고 자기 안을 들여다보는 성찰의 자리가 열린다는 뜻이다. 솔숲 사이로 불어오는 바람에 호흡을 맞추며 걷는 사이, 시야가 탁 트이면서 수천 개의 검붉은 항아리들이 대지를 가득 메운 장관이 나타났다.

산책로를 따라 걸어가다 잔디밭 끝자락에서 뜻밖의 풍경과 마주쳤다. 수천 개의 옹기 군락 너머에 실물의 사분의 일 크기로 축소해 놓은 첨성대가 서 있었다. 처음에는 장독대 정원에 왜 신라의 천문대가 서 있을까 의아했다. 그러나 걸음을 멈추고 두 모습을 나란히 바라보자 고개가 끄덕여졌다. 거기에는 과거의 역사와 현재의 숙성이 이루는 조화가 있었다.

첨성대는 하늘의 별자리를 살피고 사계절의 흐름을 읽어내던 과거의 시간이다. 그 곁에 늘어선 오천여 개의 옹기들은 하늘이 내려준 그 햇살과 바람을 받아 지금 이 순간에도 묵묵히 장을 익혀내는 현재의 시간이다. 유구한 역사는 박물관의 유리관 속에 멈춰 있지 않고, 오늘도 살아 움직이는 발효의 시간과 한 마당에서 숨을 나누고 있었다. 김수환과 데이비드 후 연구팀이 규명했듯, 전통 옹기가 음식을 썩지 않게 하고 깊은 맛으로 숙성시키는 비밀은 벽면에 뚫린 무수한 미세 숨구멍에 있다(Kim & Hu, 2023). 유리나 플라스틱처럼 안팎을 완전히 걸어 잠그면 내용물은 안에서 부패한다. 오직 보이지 않는 숨구멍으로 바깥의 공기와 바람을 받아들이고 내쉬어야만 유익한 미생물이 자라나 깊은 장맛을 빚어낸다. 하늘의 때를 읽는 지혜와 땅의 바람을 호흡하는 그릇이 잔디밭 위에서 하나로 이어지고 있었다.

항아리들이 줄지어 선 사잇길로 깊숙이 걸어 들어갔다. 지난 수십 년 동안 전국 각지에서 하나둘 모여든 항아리들은 생김새도 빛깔도 저마다 달랐다. 배가 넉넉하게 부른 항아리 옆에 허리가 잘록한 단지가 서 있고, 짙은 갈색 옹기 곁에 세월의 더께가 내려앉은 거친 독이 어깨를 나란히 하고 있었다. 그중에는 한국전쟁 당시 날아든 총탄 자국을 몸에 그대로 품은 채 살아남은 항아리도 있었다. 모진 땡볕과 눈보라, 시대의 상흔까지 맨몸으로 받아내며 깨지지 않고 버텨온 그릇들이었다.

가만히 서서 그 행렬을 바라보노라니, 그것들은 더 이상 흙으로 구운 그릇으로 보이지 않았다. 모진 세월을 말없이 견뎌낸 사람들의 모습이었다. 심리학자 리처드 테데스키와 로런스 칼훈은 인간이 삶의 거센 풍파와 고통을 통과하며 이전보다 훨씬 더 깊고 단단한 내면을 갖게 되는 과정을 ‘시련 후 성장(Posttraumatic Growth)’이라 설명했다(Tedeschi & Calhoun, 2004). 상처 입은 자리마다 깊어진 속내를 간직한 사람들처럼, 수천 개의 옹기들은 각자의 자리에서 침묵으로 속을 익히고 있었다. 그리고 바람이 항아리들의 둥근 어깨를 스치고 지나갈 때마다, 잘 숙성된 옹기들이 일제히 낮고 웅장한 합창을 들려주는 듯했다. 화려한 소리를 내세우지 않아도, 세월의 무게를 견뎌낸 존재들이 함께 모여 빚어내는 무언의 화음이었다.

합창이 울려 퍼지는 산책로 한가운데서 문득 내 삶의 시간을 돌아보았다. 나는 그동안 얼마나 조급하게 결과를 재촉하며 살아왔던가. 당장 눈에 보이는 숫자와 성취에 매달리느라, 내 안의 생각과 인격이 서서히 익어갈 시간을 견디지 못했다. 때로는 상처받지 않겠다며 마음의 문을 유리병처럼 단단히 걸어 잠근 채, 밖에서 불어오는 시련의 바람을 원망하기만 했다.

고스락의 옹기들은 온몸의 숨구멍으로 비바람을 받아들이며 오늘도 조금씩 깊어지고 있다. 잔디밭을 가로질러 불어오는 바람을 맞으며 다시 천천히 걸음을 옮겼다. 서두르지 않고 내게 주어진 세월의 바람을 기꺼이 호흡하며 익어가는 삶. 언젠가 내 삶도 저 숙성된 옹기들처럼 세월을 견딘 사람들의 대열에 나란히 서서, 깊고 그윽한 화음 한 줄을 보탤 수 있기를 조용히 소망해 본다.
"""
        gosrak_path = Path(workspace_root) / "20261107_숙성된_옹기들의_합창_익산_고스락_산책길에서.md"
        gosrak_path.write_text(gosrak_md, encoding="utf-8")
        args.file = str(gosrak_path)

    if args.file:
        out, title, date_str = process_file(args.file, template_html, args.suffix, args.cuts)
        print(f"Created: {out}")
        processed_items.append((args.file, out, title, date_str))
    elif args.dir:
        for root, _, files in os.walk(args.dir):
            for file in sorted(files):
                if file.endswith(".md") and pattern_re.search(file):
                    filepath = os.path.join(root, file)
                    out, title, date_str = process_file(filepath, template_html, args.suffix, args.cuts)
                    print(f"Created: {out}")
                    processed_items.append((filepath, out, title, date_str))
    elif not processed_items:
        print("Please provide --file or --dir argument.")
        return

    if args.deploy and processed_items:
        deploy_to_repos(processed_items, workspace_root)


if __name__ == "__main__":
    main()
