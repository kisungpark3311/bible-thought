---
name: ait-html
description: "원본 마크다운 문서를 100% 그대로 보존하면서, A4 1단 편집 지면 디자인과 모바일 반응형 뷰 자동/수동 전환(📱 모바일뷰 ↔ 📄 A4뷰), 3개 내외의 중간제목(Ⅰ·Ⅱ·Ⅲ) 자동 추출·표시, 페이지 상단 가로 전폭 세밀화 컷 일러스트(674×160px 배너), 핵심 구절 형광펜+볼드체 강조(<mark class=\"hl\"><strong>...</strong></mark>), 우측 상단 컨트롤 바 및 AI-HTML 서체(KoPub 바탕 18px)를 하나로 융합하여 HTML로 변환 및 배포하는 스킬입니다."
---

# ait-html 스킬 (A4 1단 지면 · 모바일 반응형 · 3개 내외 중간제목 · 상단 전폭 컷 일러스트 · 핵심 형광+볼드 강조 변환기)

이 스킬은 사용자가 **원본 마크다운의 문장을 글자 하나 바꾸지 않고 100% 보존**하면서, **A4 1단 편집 지면과 모바일 반응형 레이아웃이 자동으로(또는 상단 버튼으로) 작동**하고, **본문 흐름에 맞춘 3개 내외의 중간제목(`Ⅰ · Ⅱ · Ⅲ`)을 추출하여 표시**하며, **페이지 상단에 가로 전폭(`674×160px`, `width: 100%`) 크기의 정교한 세밀화풍 본문 연동 SVG 컷 일러스트를 배치**하고, **단락별 핵심 명제절과 핵심 개념 인용구를 형광펜 + 볼드체(`<mark class="hl"><strong>...</strong></mark>`)로 선명하게 강조**하며, **우측 상단 컨트롤 바**(`가-` / `100%` / `가+`, `📱 모바일뷰`↔`📄 A4뷰`, `🌓` 음영변화, `📋 복사`, `🔗 공유`)와 **`AI-HTML` 본문 서체**(`KoPub Batang` 18px)를 결합한 고급 HTML 문서로 변환할 때 사용합니다.

## 핵심 디자인 및 기능 사양
1. **원본 100% 보존 (Zero-Rewriting) 및 클립보드 순수 원문 복사**
   - 요약이나 윤문 없이 마크다운 원문의 모든 문단을 100% 그대로 유지합니다.
   - YAML Frontmatter(`---`)와 본문 첫 줄의 `# 제목`을 자동 분리하여 본문 내 제목 중복 출력을 방지합니다.
   - 화면에는 중간제목(`<h2 class="subhead">`)과 형광펜+볼드체 태그가 입혀지더라도 `📋 복사`(`copySermon()`) 클릭 시에는 태그 없는 100% 순수 원문 문단(`.essay-p`)만 클립보드에 복사됩니다.
2. **3개 내외의 중간제목 (`<h2 class="subhead">`) 추출 및 표시**
   - 문서 전체의 논리적 전환점(도입·발견 → 심화·성찰 → 적용·결단)에 맞추어 **3개 내외의 중간제목(`Ⅰ.`, `Ⅱ.`, `Ⅲ.`)**을 추출하여 각 지면/섹션 서두에 표시합니다.
   - 원문에 명시적 마크다운 소제목(`##`, `###`)이나 `.cuts.json`의 `"subhead"`가 있으면 이를 우선 반영하고, 평문 에세이일 경우 각 섹션의 핵심 명제절과 중심 모티프를 분석하여 문학적이고 정갈한 중간제목을 자동 생성합니다.
   - 좌측 보더(`border-left: 3.5px solid var(--rust)`)와 포인트 컬러(`var(--rust)`)가 적용되어 지면 도입부를 선명하게 이끌어 줍니다.
3. **페이지 상단 가로 전폭 세밀화 컷 일러스트 (`figure`)**
   - **상단 가로 전폭 배너 레이아웃 (`width: 100%; height: 160px`)**:
     - 각 페이지(`.page`) 상단 제목/소제목 아래에 본문 전폭(`674px`, 모바일 반응형 폭)으로 컷 일러스트를 배치(`margin: 18px 0 26px`)합니다.
     - 하단에는 세련된 캡션(`cut-caption`)이 좌측(그림 설명 `▲ ...`)과 우측(핵심 구절 인용 `‘...’`)으로 정갈하게 양끝 정렬됩니다.
   - **정교한 다중 레이어·인그레이빙 SVG 컷 (`enhance_svg_precision` & `SCENE_LIBRARY`)**:
     - 각 지면(`001`, `002`, `003`...)의 핵심 어휘·메타포·성경 구절을 분석하여 본문 내용에 부합하는 SVG 컷을 생성·배치합니다.
     - 세밀한 에칭/해칭 질감 패턴, 다중 그라데이션 조명, 전경·중경·원경의 입체적 디테일을 결합하여 밀도 높고 정교한 시각적 완성도를 제공합니다.
4. **A4 1단 지면 양식 (`794×1123px`) & 모바일 반응형 자동/수동 작동**
   - **자동 반응형 전환 (`@media (max-width: 840px)` / `480px`)**:
     - 데스크톱/태블릿 가로(`> 840px`)에서는 A4 1단 편집 지면(`794×1123px`, 여백 `44px 60px 28px`, 하단 플로팅 배율 컨트롤 `.zoom`)으로 렌더링됩니다.
     - 모바일 및 작은 화면(`<= 840px`, `<= 480px`)에서는 가로 스크롤이나 글자 깨짐 없이 화면 폭에 맞춘 **모바일 반응형 카드 뷰**로 자동 전환되며, 상단 전폭 컷과 중간제목이 화면 비율에 맞추어 유연하게 유지됩니다.
   - **수동 뷰 전환 버튼 (`#viewModeBtn` · `toggleViewMode()`)**:
     - 상단 툴바의 `📱 모바일뷰` / `📄 A4뷰` 버튼을 눌러 데스크톱에서도 모바일 반응형 폭으로 읽거나, 모바일에서도 A4 원본 지면 비율(`body[data-view="a4"]`)로 즉시 전환할 수 있습니다.
   - **인쇄 전용 `@media print`**: 어떤 뷰 모드에서든 인쇄 시에는 항상 정밀한 A4 페이지 규격(`794×1123px`, `break-after: page`)과 상단 컷으로 출력됩니다.
5. **핵심 부분 형광펜 + 볼드체 강조 (`<mark class="hl"><strong>...</strong></mark>`)**
   - **라이트 모드 & 다크 모드 맞춤형 형광펜 스타일**:
     - 라이트 모드: 은은한 웜 골드 하이라이터(`linear-gradient(to top, rgba(250, 204, 21, 0.24) 46%, transparent 46%)`) + 굵은 글씨(`font-weight: 700`).
     - 다크 모드: 눈부심 없는 부드러운 앰버 하이라이터(`linear-gradient(to top, rgba(234, 179, 8, 0.22) 46%, transparent 46%)`) + 크림 골드 텍스트(`#fef3c7`) + 굵은 글씨(`font-weight: 700`).
   - **명시적 마크다운 강조 및 자동 핵심 구절 추출 (`format_paragraph_with_highlights`)**:
     - 원문에 `==...==`, `**...**`, `==**...**==` 표기가 있으면 해당 구절을 `<mark class="hl"><strong>...</strong></mark>`로 변환합니다.
     - 별도 마크다운 기호가 없는 평문 에세이 단락에서도 단락별 **핵심 명제 문장(또는 중심 결론절)**과 **핵심 개념/말씀 인용구(`‘...’`, `“...”`)**를 자동으로 판별하여 형광펜 + 볼드체로 강조합니다(첫 문단 드롭캡 `p.dc::first-letter`는 깨지지 않도록 보호).
6. **우측 상단 고정 툴바 (`#top-toolbar`) & AI-HTML 타이포그래피**
   - 좌측에는 문서 제목(`#currentSectionTitle`), 우측에는 `가-`, `100%`(`78%`~`144%` 실시간 백분율 표시), `가+`, `📱 모바일뷰`(`📄 A4뷰`), `🌓`(다크/라이트 음영 전환), `📋 복사`, `🔗 공유` 버튼을 배치합니다.
   - 본문 서체는 `'KoPub Batang', 'KoPubWorldBatang', serif` 기본 `18px`, 줄간격 `1.8`을 적용하며 `-webkit-font-smoothing: antialiased`를 배제해 선명한 ClearType 획 굵기를 유지합니다.

## 무승인 원스톱 자동 수행 원칙 (최우선 규칙)

> **[중요] `uv run` 등 터미널 명령어 다중 승인 창 원천 방지**
> 1. **`tmp/*.py` 임시 배포 스크립트 작성이나 2~3회에 걸친 분할 명령어(`uv run` → `Copy-Item` → `git push`) 실행을 절대 금지합니다.**
> 2. **로컬 HTML 변환 및 저장소 파일/인덱스 반영 시 (무승인 0회 프롬프트 모드)**:
>    - 단일 파일을 변환할 때는 `run_command`(`uv run`)를 호출하지 말고, `read_file`로 원본 `.md`와 `D:\code\.agents\skills\ait-html\templates\ait_template.html`을 읽은 뒤 지면별 본문 내용에 연동된 SVG 컷 일러스트를 결합하여 **`write_file` 도구로 `.html` 파일(원본 위치 및 `bible-thought/`, `sparkofbible/` 사본)을 직접 생성**하고, **`edit_file` 도구로 `index.html`을 직접 수정**하십시오. (`read_file` / `write_file` / `edit_file`은 터미널 승인 창을 띄우지 않습니다.)
> 3. **GitHub 원격 배포(`git push`) 또는 폴더 배치 변환 시 (단 1회 원스톱 실행 모드)**:
>    - 원격 `git push`까지 한 번에 수행해야 할 때는 HTML 생성, `bible-thought` 및 `sparkofbible` 복사, 두 저장소의 `index.html` 상단 카드 자동 등록, `git add / commit / push`가 모두 하나로 내장된 `--deploy` 플래그를 사용하여 **단 1회만** 실행하십시오:
>      ```powershell
>      uv run python "D:\code\.agents\skills\ait-html\scripts\ait_html.py" --file "D:\code\변환할파일.md" --deploy
>      ```

## 옵션 레퍼런스 (`ait_html.py`)

- **단일 파일 변환 + GitHub 원스톱 자동 배포 (`--deploy`):**
  ```powershell
  uv run python "D:\code\.agents\skills\ait-html\scripts\ait_html.py" --file "D:\code\변환할파일.md" --deploy
  ```
- **파일명 뒤에 접미사(예: `_1`)를 붙여 생성 + 배포 시:**
  ```powershell
  uv run python "D:\code\.agents\skills\ait-html\scripts\ait_html.py" --file "D:\code\변환할파일.md" --suffix "_1" --deploy
  ```
- **특정 폴더 내 모든 마크다운 파일 일괄 변환 + 배포 시:**
  ```powershell
  uv run python "D:\code\.agents\skills\ait-html\scripts\ait_html.py" --dir "D:\code\변환할폴더" --deploy
  ```
