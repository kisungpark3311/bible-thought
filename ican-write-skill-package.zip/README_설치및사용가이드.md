# /ican-write & /ican-writeb 스킬 설치 및 사용 가이드

## 1. 구성 폴더
- `.agents/skills/ican-write/` : 김익한의 어나더레벨 AI 글쓰기 5단계 이원화(ican-drafter & ican-evaluator) 및 다회차(Round 1~3) 정밀 제련 스킬
- `.agents/skills/ican-writeb/` : 3단 논리 중간제목(Ⅰ·Ⅱ·Ⅲ) 자동 추출·배치 특화 버전
- `.agents/skills/ait-html/` : A4 1단 편집 지면 · 모바일 반응형 · 본문 연동 3컷 SVG · 형광펜+볼드 강조 HTML 변환기

## 2. 설치 방법 (Antigravity / Gemini)
1. 본 압축파일(`ican-write-skill-package.zip`)의 압축을 풀어 작업 폴더 내 `.agents/skills/` (또는 `C:\Users\<사용자명>\.gemini\skills\`) 경로에 복사합니다.
2. Antigravity 채팅창에서 아래와 같이 실행합니다:
   - `/ican-write <글감 메모 또는 대상 파일 경로>`
   - `/ican-writeb <글감 메모 또는 초안>` (3단 중간제목 Ⅰ·Ⅱ·Ⅲ 포함)
